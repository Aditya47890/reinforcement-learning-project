#!/bin/bash
# =============================================================================
# RLVER — Ablation Study Runner
# File   : scripts/05_run_ablations.sh
# Author : Dushyant (u23ai085)
#
# Runs all RLVER ablation experiments in dependency order.
# Produces result JSONs, plots, LaTeX tables, and a markdown report.
#
# Usage:
#   bash scripts/05_run_ablations.sh              # run all groups
#   bash scripts/05_run_ablations.sh A            # run only Group A
#   bash scripts/05_run_ablations.sh B7           # run single experiment
#   bash scripts/05_run_ablations.sh --analysis   # analysis only (skip training)
#
# Group order chosen to minimise GPU idle time:
#   Zero-shot baselines → Algorithm ablation → All other groups
# =============================================================================

set -e

PROJECT_ROOT="$HOME/Dushyant_u23ai085_9256777500"
PYTHON="conda run -n rlver_env python"
ABLATION_RUNNER="$PROJECT_ROOT/ablation/ablation_runner.py"
ABLATION_ANALYSIS="$PROJECT_ROOT/ablation/ablation_analysis.py"
RESULTS_DIR="$PROJECT_ROOT/results/ablation"
LOG_DIR="$PROJECT_ROOT/logs/ablation"
PLOTS_DIR="$RESULTS_DIR/plots"

TARGET="${1:-all}"

mkdir -p "$RESULTS_DIR" "$LOG_DIR" "$PLOTS_DIR"

# ─────────────────────────────────────────────────────────────────────────────
# Helper: run one experiment
# ─────────────────────────────────────────────────────────────────────────────

run_exp() {
    local exp_id="$1"
    local log_file="$LOG_DIR/ablation_${exp_id}.log"
    echo ""
    echo "  ─── Experiment $exp_id  [$(date +%H:%M:%S)] ───"
    $PYTHON "$ABLATION_RUNNER" "$exp_id" \
        --results_dir "$RESULTS_DIR" \
        2>&1 | tee "$log_file"
    local rc=${PIPESTATUS[0]}
    if [ $rc -ne 0 ]; then
        echo "  [ERROR] Experiment $exp_id failed (exit $rc). See $log_file"
    else
        echo "  [OK] $exp_id complete."
    fi
}

# ─────────────────────────────────────────────────────────────────────────────
# Helper: run all experiments in a group
# ─────────────────────────────────────────────────────────────────────────────

run_group() {
    local group_id="$1"
    echo ""
    echo "=================================================================="
    echo "  GROUP $group_id — $(date)"
    echo "=================================================================="

    # Get exp_ids for this group using Python
    exp_ids=$($PYTHON - << PYEOF
import sys
sys.path.insert(0, "$PROJECT_ROOT/ablation")
from ablation_config import ALL_ABLATION_GROUPS
for g in ALL_ABLATION_GROUPS:
    if g.group_id == "$group_id":
        print(" ".join(e.exp_id for e in g.experiments))
        break
PYEOF
    )

    for exp_id in $exp_ids; do
        run_exp "$exp_id"
    done
    echo ""
    echo "  Group $group_id complete."
}

# ─────────────────────────────────────────────────────────────────────────────
# Analysis-only mode
# ─────────────────────────────────────────────────────────────────────────────

run_analysis() {
    echo ""
    echo "=================================================================="
    echo "  RLVER Ablation Analysis  [$(date)]"
    echo "=================================================================="
    $PYTHON "$ABLATION_ANALYSIS" \
        --results_dir "$RESULTS_DIR" \
        --out_dir     "$PLOTS_DIR" \
        2>&1 | tee "$LOG_DIR/ablation_analysis.log"
    echo ""
    echo "  Analysis complete. Outputs in: $PLOTS_DIR"
}

# ─────────────────────────────────────────────────────────────────────────────
# Print experiment table
# ─────────────────────────────────────────────────────────────────────────────

print_plan() {
    $PYTHON - << 'PYEOF'
import sys
sys.path.insert(0, "$HOME/Dushyant_u23ai085_9256777500/ablation")
from ablation_config import ALL_ABLATION_GROUPS, list_all_experiments
exps = list_all_experiments()
print(f"\nTotal experiments: {len(exps)}")
for g in ALL_ABLATION_GROUPS:
    print(f"  Group {g.group_id}: {g.title} ({len(g.experiments)} experiments)")
PYEOF
}

# ─────────────────────────────────────────────────────────────────────────────
# Main dispatch
# ─────────────────────────────────────────────────────────────────────────────

echo ""
echo "=================================================================="
echo "  RLVER Ablation Study"
echo "  Target   : $TARGET"
echo "  Started  : $(date)"
echo "  Results  : $RESULTS_DIR"
echo "=================================================================="

if [ "$TARGET" = "--analysis" ]; then
    run_analysis
    exit 0
fi

if [ "$TARGET" = "--plan" ]; then
    print_plan
    exit 0
fi

# Single experiment (e.g. "B7")
if echo "$TARGET" | grep -qE '^[A-I][0-9]+$'; then
    run_exp "$TARGET"
    run_analysis
    exit 0
fi

# Single group (e.g. "A" or "B")
if echo "$TARGET" | grep -qE '^[A-I]$'; then
    run_group "$TARGET"
    run_analysis
    exit 0
fi

# ── ALL groups ─────────────────────────────────────────────────────────────
if [ "$TARGET" = "all" ]; then
    echo ""
    echo "  Running all ablation groups."
    echo "  Estimated time: 8–16 hours (GPU-dependent)"
    echo ""

    # Phase 1: Zero-shot baselines first (cheap, no training)
    echo ">>> PHASE 1: Zero-shot baselines"
    run_exp "B1"   # ZeroShot 7B
    run_exp "B2"   # ZeroShot 1.5B
    run_exp "D1"   # 1.5B ZeroShot
    run_exp "D3"   # 7B ZeroShot

    # Phase 2: Algorithm group (includes PPO and GRPO variants)
    echo ""
    echo ">>> PHASE 2: Algorithm ablation (Group B)"
    run_group "B"

    # Phase 3: Reward components (Group A) — fastest GPU runs
    echo ""
    echo ">>> PHASE 3: Reward component ablation (Group A)"
    run_group "A"

    # Phase 4: Thinking modes (Group C)
    echo ""
    echo ">>> PHASE 4: Thinking mode ablation (Group C)"
    run_group "C"

    # Phase 5: GRPO hyperparameters (E, H)
    echo ""
    echo ">>> PHASE 5: GRPO Group Size (Group E)"
    run_group "E"

    echo ""
    echo ">>> PHASE 5b: KL Penalty β (Group H)"
    run_group "H"

    # Phase 6: Data/model ablations (D, F, G)
    echo ""
    echo ">>> PHASE 6: Model scale (Group D)"
    run_group "D"

    echo ""
    echo ">>> PHASE 6b: LoRA Rank (Group F)"
    run_group "F"

    echo ""
    echo ">>> PHASE 6c: Adversarial Ratio (Group G)"
    run_group "G"

    # Phase 7: Convergence study (Group I — re-uses existing checkpoints)
    echo ""
    echo ">>> PHASE 7: Convergence / Training Steps (Group I)"
    run_group "I"

    echo ""
    echo "=================================================================="
    echo "  ALL ABLATION EXPERIMENTS COMPLETE"
    echo "  Finished: $(date)"
    echo "=================================================================="
fi

# ── Final analysis for all modes ────────────────────────────────────────────
run_analysis

echo ""
echo "=================================================================="
echo "  RLVER Ablation Study DONE"
echo "  Results : $RESULTS_DIR"
echo "  Plots   : $PLOTS_DIR"
echo "  Logs    : $LOG_DIR"
echo ""
echo "  Key output files:"
echo "    $PLOTS_DIR/ablation_summary_heatmap.png"
echo "    $PLOTS_DIR/comparison_vs_prior_work.png"
echo "    $PLOTS_DIR/ablation_latex_table.tex"
echo "    $PLOTS_DIR/ablation_results.csv"
echo "    $PLOTS_DIR/ablation_report.md"
echo "=================================================================="
