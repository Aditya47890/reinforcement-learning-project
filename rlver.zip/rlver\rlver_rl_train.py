"""
=============================================================================
RLVER — RL Training Entry Point  (PPO + GRPO)
File  : rl_training/rlver_rl_train.py
Author: Dushyant (u23ai085)

Trains Qwen2.5-7B-Instruct on the RLVER verification task.
Uses custom trainers (ppo_trainer_custom, grpo_trainer_custom) — NOT
TRL's PPOTrainer / GRPOTrainer — to avoid API incompatibilities.

Four training variants:
  1. PPO  + thinking  (--algorithm ppo  --thinking)
  2. PPO  + no-think  (--algorithm ppo)
  3. GRPO + thinking  (--algorithm grpo --thinking)
  4. GRPO + no-think  (--algorithm grpo)

Usage:
  conda activate rlver_env
  cd ~/Dushyant_u23ai085_9256777500

  python rl_training/rlver_rl_train.py --algorithm grpo --thinking
  python rl_training/rlver_rl_train.py --algorithm ppo
=============================================================================
"""

from __future__ import annotations

import os
import sys
import json
import time
import random
import logging
import argparse
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, List

import yaml
import torch
import numpy as np
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, get_peft_model, TaskType

# ── Path setup ────────────────────────────────────────────────────────────────
PROJECT_ROOT = os.path.expanduser("~/Dushyant_u23ai085_9256777500")
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rlver_adversarial"))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rl_training"))

# Local imports (no circular dependencies)
from dataset_builder import RLVERDatasetBuilder, to_hf_dataset
from reward_model import RewardConfig

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# TrainConfig
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TrainConfig:
    # Identity
    algorithm: str = "grpo"           # "ppo" | "grpo"
    thinking_enabled: bool = True
    run_name: str = ""
    seed: int = 42

    # Model
    model_name_or_path: str = "Qwen/Qwen2.5-7B-Instruct"
    local_model_dir: str = os.path.join(PROJECT_ROOT, "models")
    torch_dtype: str = "bfloat16"
    use_lora: bool = True
    lora_r: int = 64
    lora_alpha: int = 128
    lora_dropout: float = 0.05
    lora_target_modules: List[str] = field(default_factory=lambda: [
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
    ])

    # Data
    max_train_samples: Optional[int] = 7473
    max_eval_samples:  Optional[int] = 500
    adversarial_ratio: float = 0.4
    cache_dir: str = os.path.join(PROJECT_ROOT, "cache", "hf")

    # Training
    output_dir: str = os.path.join(PROJECT_ROOT, "rl_training", "checkpoints")
    max_steps:   int = 10000
    save_steps:  int = 500
    eval_steps:  int = 250
    logging_steps: int = 10
    warmup_steps:  int = 100

    # PPO-specific
    ppo_learning_rate:             float = 1.0e-5
    ppo_batch_size:                int   = 8
    ppo_mini_batch_size:           int   = 4
    ppo_gradient_accumulation_steps: int = 4
    ppo_num_epochs:                int   = 4
    ppo_cliprange:                 float = 0.2
    ppo_cliprange_value:           float = 0.2
    ppo_vf_coef:                   float = 0.1
    ppo_ent_coef:                  float = 0.01
    ppo_max_grad_norm:             float = 1.0
    ppo_init_kl_coef:              float = 0.05
    ppo_target_kl:                 float = 6.0
    ppo_gamma:                     float = 0.99
    ppo_lam:                       float = 0.95

    # GRPO-specific
    grpo_learning_rate:            float = 5.0e-6
    grpo_batch_size:               int   = 4
    grpo_gradient_accumulation_steps: int = 8
    grpo_num_generations:          int   = 8
    grpo_beta:                     float = 0.04
    grpo_epsilon:                  float = 0.2
    grpo_max_grad_norm:            float = 1.0

    # Generation
    max_new_tokens: int   = 256
    temperature:    float = 0.9
    top_p:          float = 0.95

    # Reward
    reward_correct:        float = 1.0
    reward_wrong:          float = -1.0
    reward_partial:        float = 0.3
    reward_format:         float = 0.1
    reward_length_penalty: float = 0.001
    reward_max_length:     int   = 200

    # WandB
    wandb_enabled: bool = True
    wandb_project: str  = "RLVER"

    def auto_run_name(self) -> str:
        think_tag  = "thinking" if self.thinking_enabled else "non_thinking"
        model_tag  = (
            "qwen7b"   if ("7B" in self.model_name_or_path or "7b" in self.model_name_or_path)
            else "qwen1p5b"
        )
        return f"{self.algorithm}_{think_tag}_{model_tag}"


# ─────────────────────────────────────────────────────────────────────────────
# YAML config loading
# ─────────────────────────────────────────────────────────────────────────────

def load_yaml(path: str) -> Dict:
    with open(path) as f:
        return yaml.safe_load(f)


def _merge_yaml(cfg: TrainConfig, raw: Dict) -> None:
    """Flatten nested YAML sections onto TrainConfig fields."""
    # PPO
    for k, attr in [
        ("learning_rate",              "ppo_learning_rate"),
        ("batch_size",                 "ppo_batch_size"),
        ("mini_batch_size",            "ppo_mini_batch_size"),
        ("gradient_accumulation_steps","ppo_gradient_accumulation_steps"),
        ("num_ppo_epochs",             "ppo_num_epochs"),
        ("cliprange",                  "ppo_cliprange"),
        ("cliprange_value",            "ppo_cliprange_value"),
        ("vf_coef",                    "ppo_vf_coef"),
        ("ent_coef",                   "ppo_ent_coef"),
        ("max_grad_norm",              "ppo_max_grad_norm"),
        ("init_kl_coef",               "ppo_init_kl_coef"),
        ("target_kl",                  "ppo_target_kl"),
        ("max_new_tokens",             "max_new_tokens"),
        ("temperature",                "temperature"),
    ]:
        if "ppo" in raw and k in raw["ppo"]:
            setattr(cfg, attr, raw["ppo"][k])

    # GRPO
    for k, attr in [
        ("learning_rate",              "grpo_learning_rate"),
        ("batch_size",                 "grpo_batch_size"),
        ("gradient_accumulation_steps","grpo_gradient_accumulation_steps"),
        ("num_generations",            "grpo_num_generations"),
        ("beta",                       "grpo_beta"),
        ("epsilon",                    "grpo_epsilon"),
        ("max_grad_norm",              "grpo_max_grad_norm"),
        ("max_new_tokens",             "max_new_tokens"),
        ("temperature",                "temperature"),
    ]:
        if "grpo" in raw and k in raw["grpo"]:
            setattr(cfg, attr, raw["grpo"][k])

    # Model
    if "model" in raw:
        m = raw["model"]
        for k, attr in [
            ("policy_model",   "model_name_or_path"),
            ("use_lora",       "use_lora"),
            ("lora_r",         "lora_r"),
            ("lora_alpha",     "lora_alpha"),
            ("lora_dropout",   "lora_dropout"),
        ]:
            if k in m:
                setattr(cfg, attr, m[k])

    # Data
    if "data" in raw:
        d = raw["data"]
        for k, attr in [
            ("max_train_samples", "max_train_samples"),
            ("max_eval_samples",  "max_eval_samples"),
            ("adversarial_ratio", "adversarial_ratio"),
        ]:
            if k in d:
                setattr(cfg, attr, d[k])

    # Training
    if "training" in raw:
        t = raw["training"]
        for k, attr in [
            ("max_steps",    "max_steps"),
            ("save_steps",   "save_steps"),
            ("eval_steps",   "eval_steps"),
            ("logging_steps","logging_steps"),
            ("warmup_steps", "warmup_steps"),
        ]:
            if k in t:
                setattr(cfg, attr, t[k])

    # Reward
    if "reward" in raw:
        r = raw["reward"]
        for k, attr in [
            ("correct_verification", "reward_correct"),
            ("wrong_verification",   "reward_wrong"),
            ("partial_reasoning",    "reward_partial"),
            ("format_bonus",         "reward_format"),
            ("length_penalty_coef",  "reward_length_penalty"),
            ("max_length_no_penalty","reward_max_length"),
        ]:
            if k in r:
                setattr(cfg, attr, r[k])

    # WandB
    if "wandb" in raw:
        w = raw["wandb"]
        if "enabled"  in w: cfg.wandb_enabled = w["enabled"]
        if "project"  in w: cfg.wandb_project  = w["project"]
        if "run_name" in w: cfg.run_name        = w["run_name"]


def build_train_config(args: argparse.Namespace) -> TrainConfig:
    cfg = TrainConfig()

    if args.config and os.path.isfile(args.config):
        _merge_yaml(cfg, load_yaml(args.config))

    cfg.algorithm       = args.algorithm
    cfg.thinking_enabled = args.thinking
    cfg.seed            = args.seed

    if args.output_dir:
        cfg.output_dir = args.output_dir
    if args.max_steps:
        cfg.max_steps = args.max_steps
    if args.model_path:
        cfg.model_name_or_path = args.model_path

    if not cfg.run_name:
        cfg.run_name = cfg.auto_run_name()

    # Append algorithm/thinking sub-directory
    think_tag = "thinking" if cfg.thinking_enabled else "non_thinking"
    cfg.output_dir = os.path.join(cfg.output_dir, cfg.algorithm, think_tag)

    return cfg


# ─────────────────────────────────────────────────────────────────────────────
# Shared utilities
# ─────────────────────────────────────────────────────────────────────────────

def resolve_model_path(model_id: str, local_dir: str) -> str:
    """Try local cache first, then return as-is (HF hub ID or abs path)."""
    alias_map = {
        "Qwen/Qwen2.5-1.5B-Instruct": "qwen_1p5b",
        "Qwen/Qwen2.5-7B-Instruct":   "qwen_7b",
        "mistralai/Mistral-7B-Instruct-v0.3": "mistral_7b_sim",
    }
    if model_id in alias_map:
        local_path = os.path.join(local_dir, alias_map[model_id])
        if os.path.isdir(local_path):
            return local_path
    expanded = os.path.expanduser(model_id)
    if os.path.isdir(expanded):
        return expanded
    return model_id


def load_tokenizer(model_path: str) -> AutoTokenizer:
    tok = AutoTokenizer.from_pretrained(
        model_path, trust_remote_code=True, padding_side="left"
    )
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    return tok


def load_model_with_lora(
    model_path: str,
    cfg: TrainConfig,
    dtype: torch.dtype,
) -> AutoModelForCausalLM:
    """Load CausalLM and wrap with LoRA (if cfg.use_lora)."""
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
    )
    if cfg.use_lora:
        lora_cfg = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=cfg.lora_r,
            lora_alpha=cfg.lora_alpha,
            lora_dropout=cfg.lora_dropout,
            target_modules=cfg.lora_target_modules,
            bias="none",
        )
        model = get_peft_model(model, lora_cfg)
        model.print_trainable_parameters()
    return model


def load_ref_model(
    model_path: str,
    dtype: torch.dtype,
) -> AutoModelForCausalLM:
    """Load frozen reference model (no LoRA)."""
    ref = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=dtype,
        device_map="auto",
        trust_remote_code=True,
    )
    for p in ref.parameters():
        p.requires_grad_(False)
    ref.eval()
    return ref


def build_reward_cfg(cfg: TrainConfig) -> RewardConfig:
    return RewardConfig(
        correct_verification=cfg.reward_correct,
        wrong_verification=cfg.reward_wrong,
        partial_reasoning=cfg.reward_partial,
        format_bonus=cfg.reward_format,
        length_penalty_coef=cfg.reward_length_penalty,
        max_length_no_penalty=cfg.reward_max_length,
        thinking_reward_enabled=cfg.thinking_enabled,
    )


def build_dataloader(
    cfg: TrainConfig,
    split: str,
    thinking_enabled: bool,
    batch_size: int,
    max_samples: Optional[int] = None,
    shuffle: bool = True,
) -> tuple:
    """
    Build HuggingFace Dataset → DataLoader + raw samples.
    Returns (dataloader, raw_samples_list).
    """
    datasets_dir = os.path.join(PROJECT_ROOT, "cache", "datasets")
    os.makedirs(datasets_dir, exist_ok=True)

    fname = "rlver_train.jsonl" if split == "train" else "rlver_eval.jsonl"
    cache_path = os.path.join(datasets_dir, fname)

    builder = RLVERDatasetBuilder(
        adversarial_ratio=cfg.adversarial_ratio,
        cache_dir=cfg.cache_dir,
        seed=cfg.seed,
    )

    if os.path.isfile(cache_path):
        logger.info(f"Loading cached dataset: {cache_path}")
        samples = builder.load_jsonl(cache_path)
    else:
        samples = builder.build(
            split=split,
            max_samples=max_samples,
            save_path=cache_path,
        )

    if max_samples and len(samples) > max_samples:
        samples = samples[:max_samples]

    hf_ds = to_hf_dataset(samples, thinking_enabled=thinking_enabled)

    dl = DataLoader(
        hf_ds,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=0,         # 0 workers avoids CUDA multiprocessing issues
        pin_memory=False,
        collate_fn=_collate_fn,
    )
    return dl, samples


def _collate_fn(batch: List[Dict]) -> Dict:
    """
    Simple collate: keeps all fields as lists (no tokenization here).
    Tokenization happens per-sample inside the trainer's rollout loop.
    """
    keys = batch[0].keys()
    result = {}
    for k in keys:
        result[k] = [item[k] for item in batch]
    return result


# ─────────────────────────────────────────────────────────────────────────────
# PPO training function
# ─────────────────────────────────────────────────────────────────────────────

def run_ppo_training(cfg: TrainConfig) -> None:
    """
    Build actor-critic + reference model, then run custom PPO training loop.
    """
    from ppo_trainer_custom import ActorCriticModel, RLVERPPOTrainer

    logger.info("=== PPO Training ===")
    dtype       = torch.bfloat16 if cfg.torch_dtype == "bfloat16" else torch.float16
    model_path  = resolve_model_path(cfg.model_name_or_path, cfg.local_model_dir)

    # Load models
    tokenizer   = load_tokenizer(model_path)
    base_model  = load_model_with_lora(model_path, cfg, dtype)
    ref_model   = load_ref_model(model_path, dtype)

    # Wrap base_model with value head
    hidden_size = base_model.config.hidden_size
    actor_critic = ActorCriticModel(base_model, hidden_size=hidden_size)

    # Build dataset → DataLoader
    train_dl, _            = build_dataloader(
        cfg, "train", cfg.thinking_enabled, cfg.ppo_batch_size, cfg.max_train_samples
    )
    _, eval_samples        = build_dataloader(
        cfg, "test",  cfg.thinking_enabled, 1, cfg.max_eval_samples, shuffle=False
    )

    # Build reward config
    reward_cfg = build_reward_cfg(cfg)

    # Build trainer
    trainer = RLVERPPOTrainer(
        actor_critic=actor_critic,
        ref_model=ref_model,
        tokenizer=tokenizer,
        reward_cfg=reward_cfg,
        thinking_enabled=cfg.thinking_enabled,
        learning_rate=cfg.ppo_learning_rate,
        batch_size=cfg.ppo_batch_size,
        mini_batch_size=cfg.ppo_mini_batch_size,
        gradient_accumulation_steps=cfg.ppo_gradient_accumulation_steps,
        num_ppo_epochs=cfg.ppo_num_epochs,
        cliprange=cfg.ppo_cliprange,
        cliprange_value=cfg.ppo_cliprange_value,
        vf_coef=cfg.ppo_vf_coef,
        ent_coef=cfg.ppo_ent_coef,
        max_grad_norm=cfg.ppo_max_grad_norm,
        gamma=cfg.ppo_gamma,
        lam=cfg.ppo_lam,
        init_kl_coef=cfg.ppo_init_kl_coef,
        target_kl=cfg.ppo_target_kl,
        max_new_tokens=cfg.max_new_tokens,
        temperature=cfg.temperature,
        top_p=cfg.top_p,
        max_steps=cfg.max_steps,
        save_steps=cfg.save_steps,
        eval_steps=cfg.eval_steps,
        logging_steps=cfg.logging_steps,
        warmup_steps=cfg.warmup_steps,
        output_dir=cfg.output_dir,
        wandb_enabled=cfg.wandb_enabled,
    )

    trainer.train(train_dl, eval_samples)


# ─────────────────────────────────────────────────────────────────────────────
# GRPO training function
# ─────────────────────────────────────────────────────────────────────────────

def run_grpo_training(cfg: TrainConfig) -> None:
    """
    Build policy + reference model, then run custom GRPO training loop.
    """
    from grpo_trainer_custom import RLVERGRPOTrainer

    logger.info("=== GRPO Training ===")
    dtype      = torch.bfloat16 if cfg.torch_dtype == "bfloat16" else torch.float16
    model_path = resolve_model_path(cfg.model_name_or_path, cfg.local_model_dir)

    # Load models
    tokenizer  = load_tokenizer(model_path)
    model      = load_model_with_lora(model_path, cfg, dtype)
    ref_model  = load_ref_model(model_path, dtype)

    # Build dataset → DataLoader
    train_dl, _     = build_dataloader(
        cfg, "train", cfg.thinking_enabled, cfg.grpo_batch_size, cfg.max_train_samples
    )
    _, eval_samples = build_dataloader(
        cfg, "test",  cfg.thinking_enabled, 1, cfg.max_eval_samples, shuffle=False
    )

    # Build reward config
    reward_cfg = build_reward_cfg(cfg)

    # Build trainer
    trainer = RLVERGRPOTrainer(
        model=model,
        ref_model=ref_model,
        tokenizer=tokenizer,
        reward_cfg=reward_cfg,
        thinking_enabled=cfg.thinking_enabled,
        learning_rate=cfg.grpo_learning_rate,
        batch_size=cfg.grpo_batch_size,
        gradient_accumulation_steps=cfg.grpo_gradient_accumulation_steps,
        num_generations=cfg.grpo_num_generations,
        beta=cfg.grpo_beta,
        epsilon=cfg.grpo_epsilon,
        max_grad_norm=cfg.grpo_max_grad_norm,
        max_new_tokens=cfg.max_new_tokens,
        temperature=cfg.temperature,
        top_p=cfg.top_p,
        max_steps=cfg.max_steps,
        save_steps=cfg.save_steps,
        eval_steps=cfg.eval_steps,
        logging_steps=cfg.logging_steps,
        warmup_steps=cfg.warmup_steps,
        output_dir=cfg.output_dir,
        wandb_enabled=cfg.wandb_enabled,
    )

    trainer.train(train_dl, eval_samples)


# ─────────────────────────────────────────────────────────────────────────────
# WandB
# ─────────────────────────────────────────────────────────────────────────────

def setup_wandb(cfg: TrainConfig) -> None:
    if not cfg.wandb_enabled:
        os.environ["WANDB_DISABLED"] = "true"
        return
    try:
        import wandb
        wandb.init(
            project=cfg.wandb_project,
            name=cfg.run_name,
            config=asdict(cfg),
            tags=[cfg.algorithm, "thinking" if cfg.thinking_enabled else "no_thinking"],
        )
        logger.info(f"WandB run: {wandb.run.url}")
    except Exception as e:
        logger.warning(f"WandB init failed: {e}. Disabling WandB.")
        os.environ["WANDB_DISABLED"] = "true"
        cfg.wandb_enabled = False


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="RLVER RL Training — PPO or GRPO",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--algorithm", choices=["ppo", "grpo"], default="grpo")
    parser.add_argument("--thinking",  action="store_true",
                        help="Enable chain-of-thought thinking mode")
    parser.add_argument(
        "--config", type=str,
        default=os.path.join(PROJECT_ROOT, "configs", "grpo_config.yaml"),
        help="Path to YAML config file",
    )
    parser.add_argument("--model_path",  type=str, default=None,
                        help="Override model path (local dir or HF ID)")
    parser.add_argument(
        "--output_dir", type=str,
        default=os.path.join(PROJECT_ROOT, "rl_training", "checkpoints"),
    )
    parser.add_argument("--max_steps", type=int, default=None)
    parser.add_argument("--seed",      type=int, default=42)
    parser.add_argument("--no_wandb",  action="store_true",
                        help="Disable Weights & Biases logging")
    return parser


def main():
    os.makedirs(os.path.join(PROJECT_ROOT, "logs"), exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(
                os.path.join(PROJECT_ROOT, "logs", "training.log"), mode="a"
            ),
        ],
    )

    args = build_parser().parse_args()
    cfg  = build_train_config(args)
    if args.no_wandb:
        cfg.wandb_enabled = False

    # Seed everything
    random.seed(cfg.seed)
    np.random.seed(cfg.seed)
    torch.manual_seed(cfg.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(cfg.seed)

    # Hardware info
    logger.info(f"PyTorch {torch.__version__}")
    if torch.cuda.is_available():
        p = torch.cuda.get_device_properties(0)
        logger.info(f"GPU: {p.name}  VRAM: {p.total_memory/1e9:.1f} GB")
    else:
        logger.warning("CUDA not available — training will be very slow on CPU!")

    # Print config summary
    logger.info(
        f"\n  algorithm  : {cfg.algorithm}\n"
        f"  thinking   : {cfg.thinking_enabled}\n"
        f"  model      : {cfg.model_name_or_path}\n"
        f"  output_dir : {cfg.output_dir}\n"
        f"  max_steps  : {cfg.max_steps}\n"
        f"  run_name   : {cfg.run_name}"
    )

    # WandB
    setup_wandb(cfg)

    # Save config
    os.makedirs(cfg.output_dir, exist_ok=True)
    with open(os.path.join(cfg.output_dir, "train_config.json"), "w") as f:
        json.dump(asdict(cfg), f, indent=2)

    # Run
    t0 = time.time()
    if cfg.algorithm == "ppo":
        run_ppo_training(cfg)
    elif cfg.algorithm == "grpo":
        run_grpo_training(cfg)
    else:
        raise ValueError(f"Unknown algorithm: {cfg.algorithm}")

    logger.info(f"Training finished in {(time.time()-t0)/3600:.2f} hours.")


if __name__ == "__main__":
    main()
