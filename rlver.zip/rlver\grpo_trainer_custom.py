"""
=============================================================================
RLVER — Custom GRPO Trainer
File  : rl_training/grpo_trainer_custom.py
Author: Dushyant (u23ai085)

Self-contained GRPO trainer for RLVER. Does NOT depend on TRL GRPOTrainer.

Implements Group Relative Policy Optimization (Shao et al. 2024):
  arXiv:2402.03300 "DeepSeekMath: Pushing the Limits of Mathematical Reasoning"

Algorithm per step:
  1. For each prompt q, sample G completions {o_1..o_G} from π_θ_old
  2. Score each: r_1..r_G via reward_fn
  3. Group-normalize: A_i = (r_i - μ_r) / (σ_r + ε)
  4. Compute GRPO loss (token-level, with importance ratios π_θ/π_θ_old)
  5. Gradient step on π_θ

Key fix vs previous version:
  - old_lp (rollout-time log probs) are captured with torch.no_grad() FIRST,
    then new_lp is computed with grad enabled. This ensures the importance
    ratio ρ = π_θ_new / π_θ_old is correct even within a multi-step update.

Note on single vs multi-step GRPO:
  Standard GRPO is typically single-epoch (no re-use of rollouts). The
  importance ratio ρ starts at 1.0 on step 0 and diverges as θ updates.
  The epsilon clip limits how far θ can drift before the rollout buffer
  must be refreshed.

Mathematical formulation:
  For each prompt q, group {o_i}_{i=1}^G:
    A_i = (r_i - μ_r) / (σ_r + ε)

  Token-level GRPO loss:
    L = -(1/G) Σ_i (1/|o_i|) Σ_t
          min( ρ_{i,t}·A_i, clip(ρ_{i,t}, 1-ε, 1+ε)·A_i )
        + β · KL(π_θ(·|q) ‖ π_ref(·|q))
=============================================================================
"""

from __future__ import annotations

import os
import sys
import json
import time
import logging
import random
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, get_cosine_schedule_with_warmup

PROJECT_ROOT = os.path.expanduser("~/Dushyant_u23ai085_9256777500")
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rlver_adversarial"))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rl_training"))

from reward_model import RewardConfig, compute_rewards_batch

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Group sample container
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class GroupSample:
    """
    G completions for one prompt, produced during the rollout phase.

    completion_ids: list of G tensors, each (1, Q+R_i) — full sequences
    prompt_len    : Q — number of prompt tokens (to slice off response)
    """
    prompt:          str
    completion_ids:  List[torch.Tensor]    # G × (1, Q+R_i)
    completions:     List[str]             # G decoded texts
    prompt_len:      int                   # Q
    rewards:         List[float]           # G scalar rewards
    advantages:      List[float] = field(default_factory=list)

    true_label: int = 1
    problem:    str = ""
    problem_id: str = ""

    def compute_advantages(self, eps: float = 1e-8) -> None:
        """
        Normalize rewards within the group to get advantages.
        If all rewards are identical, advantages are all 0.
        """
        r  = np.array(self.rewards, dtype=np.float32)
        mu = r.mean()
        sd = r.std()
        if sd < eps:
            self.advantages = [0.0] * len(self.rewards)
        else:
            self.advantages = ((r - mu) / (sd + eps)).tolist()

    @property
    def has_signal(self) -> bool:
        """True if the group has non-trivial reward variance (learning signal)."""
        return np.std(self.rewards) > 1e-6


# ─────────────────────────────────────────────────────────────────────────────
# Token-level log prob extraction
# ─────────────────────────────────────────────────────────────────────────────

@torch.no_grad()
def _get_response_log_probs(
    model: nn.Module,
    input_ids: torch.Tensor,      # (G, Q+R)
    attention_mask: torch.Tensor, # (G, Q+R)
    prompt_len: int,               # Q
) -> torch.Tensor:                 # (G, R)
    """
    Compute per-token log probs for the response tokens [Q:] of each completion.
    Uses teacher-forcing; called with no_grad for old-policy capture.
    """
    out = model(input_ids=input_ids, attention_mask=attention_mask, return_dict=True)
    logits = out.logits                                # (G, Q+R, V)

    # Shift: logits[t] predicts token[t+1]
    shift_logits = logits[:, :-1, :].contiguous()     # (G, Q+R-1, V)
    shift_ids    = input_ids[:, 1:].contiguous()      # (G, Q+R-1)

    log_probs    = F.log_softmax(shift_logits, dim=-1)  # (G, Q+R-1, V)
    tok_lps      = log_probs.gather(2, shift_ids.unsqueeze(-1)).squeeze(-1)  # (G, Q+R-1)

    # Response tokens in shifted view start at index Q-1
    resp_lps = tok_lps[:, prompt_len - 1:]            # (G, R)
    return resp_lps


def _get_response_log_probs_grad(
    model: nn.Module,
    input_ids: torch.Tensor,
    attention_mask: torch.Tensor,
    prompt_len: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Same as above but WITH gradients (for new policy forward pass).
    Returns (resp_lps, full_logits) so we can compute KL and entropy.
    """
    out = model(input_ids=input_ids, attention_mask=attention_mask, return_dict=True)
    logits = out.logits

    shift_logits = logits[:, :-1, :].contiguous()
    shift_ids    = input_ids[:, 1:].contiguous()

    log_probs = F.log_softmax(shift_logits, dim=-1)
    tok_lps   = log_probs.gather(2, shift_ids.unsqueeze(-1)).squeeze(-1)
    resp_lps  = tok_lps[:, prompt_len - 1:]

    return resp_lps, logits


# ─────────────────────────────────────────────────────────────────────────────
# GRPO loss (token-level)
# ─────────────────────────────────────────────────────────────────────────────

def compute_grpo_loss(
    new_resp_lps: torch.Tensor,    # (G, R) — new policy log probs
    old_resp_lps: torch.Tensor,    # (G, R) — old policy log probs (rollout)
    ref_resp_lps: torch.Tensor,    # (G, R) — reference policy log probs
    resp_mask:    torch.Tensor,    # (G, R) — 1 for real tokens
    advantages:   torch.Tensor,    # (G,)
    epsilon: float = 0.2,
    beta:    float = 0.04,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """
    Token-level GRPO objective.

    L = -(1/G) Σ_i (1/|o_i|) Σ_t min(ρ_{i,t}·A_i, clip(ρ_{i,t},1-ε,1+ε)·A_i)
        + β · KL(π_θ ‖ π_ref)
    """
    G, R = new_resp_lps.shape

    # Importance ratio per token: ρ_{i,t} = π_θ_new / π_θ_old
    log_ratio = new_resp_lps - old_resp_lps.detach()   # (G, R)
    ratio     = torch.exp(log_ratio)                    # (G, R)

    # Expand advantages: (G,) → (G, R)
    adv_exp = advantages.unsqueeze(1).expand_as(ratio) # (G, R)

    # Clipped surrogate loss per token
    pg_l1   = -adv_exp * ratio
    pg_l2   = -adv_exp * ratio.clamp(1.0 - epsilon, 1.0 + epsilon)
    pg_tok  = torch.max(pg_l1, pg_l2)                  # (G, R)

    # Token-level KL: log(π_θ/π_ref)
    kl_tok  = new_resp_lps - ref_resp_lps.detach()     # (G, R)

    # Total per-token loss
    total_tok = pg_tok + beta * kl_tok                  # (G, R)

    # Mask + average
    mask_f     = resp_mask.float()                      # (G, R)
    n_per_seq  = mask_f.sum(dim=1).clamp(min=1)         # (G,)
    per_seq    = (total_tok * mask_f).sum(1) / n_per_seq  # (G,)
    loss       = per_seq.mean()

    # Stats
    with torch.no_grad():
        valid  = mask_f.bool()
        mean_r = ratio[valid].mean().item()  if valid.any() else 1.0
        clip_f = ((ratio[valid] - 1.0).abs() > epsilon).float().mean().item() if valid.any() else 0.0
        mean_k = kl_tok[valid].mean().item() if valid.any() else 0.0

    stats = {
        "loss/total":       loss.item(),
        "loss/kl_penalty":  beta * mean_k,
        "ratio/mean":       mean_r,
        "ratio/clip_frac":  clip_f,
        "kl/mean":          mean_k,
        "adv/mean":         advantages.mean().item(),
        "adv/std":          advantages.std().item() if G > 1 else 0.0,
    }
    return loss, stats


# ─────────────────────────────────────────────────────────────────────────────
# GRPO Trainer
# ─────────────────────────────────────────────────────────────────────────────

class RLVERGRPOTrainer:
    """
    Custom GRPO trainer. Does NOT depend on TRL GRPOTrainer.

    Usage (from rlver_rl_train.py):
        trainer = RLVERGRPOTrainer(model, ref_model, tokenizer, ...)
        trainer.train(train_dataloader, eval_samples)
    """

    def __init__(
        self,
        model:     nn.Module,
        ref_model: nn.Module,
        tokenizer: AutoTokenizer,
        reward_cfg: RewardConfig,
        thinking_enabled: bool = True,
        learning_rate: float = 5e-6,
        batch_size: int = 4,
        gradient_accumulation_steps: int = 8,
        num_generations: int = 8,
        beta: float = 0.04,
        epsilon: float = 0.2,
        max_grad_norm: float = 1.0,
        max_new_tokens: int = 256,
        temperature: float = 0.9,
        top_p: float = 0.95,
        max_steps: int = 10000,
        save_steps: int = 500,
        eval_steps: int = 250,
        logging_steps: int = 10,
        warmup_steps: int = 100,
        output_dir: str = "",
        device: str = "cuda",
        wandb_enabled: bool = False,
    ):
        self.model            = model
        self.ref_model        = ref_model
        self.tokenizer        = tokenizer
        self.reward_cfg       = reward_cfg
        self.thinking_enabled = thinking_enabled
        self.device           = device
        self.num_generations  = num_generations
        self.beta             = beta
        self.epsilon          = epsilon
        self.max_grad_norm    = max_grad_norm
        self.batch_size       = batch_size
        self.gradient_accumulation_steps = gradient_accumulation_steps
        self.max_new_tokens   = max_new_tokens
        self.temperature      = temperature
        self.top_p            = top_p
        self.max_steps        = max_steps
        self.save_steps       = save_steps
        self.eval_steps       = eval_steps
        self.logging_steps    = logging_steps
        self.output_dir       = output_dir
        self.wandb_enabled    = wandb_enabled

        # Freeze reference
        for p in self.ref_model.parameters():
            p.requires_grad_(False)
        self.ref_model.eval()

        # Optimizer
        trainable = [p for p in self.model.parameters() if p.requires_grad]
        logger.info(f"GRPO trainable parameters: {sum(p.numel() for p in trainable):,}")

        self.optimizer = torch.optim.AdamW(
            trainable, lr=learning_rate, weight_decay=0.01, betas=(0.9, 0.95)
        )
        self.scheduler = get_cosine_schedule_with_warmup(
            self.optimizer,
            num_warmup_steps=warmup_steps,
            num_training_steps=max_steps,
        )

        self.global_step    = 0
        self.best_acc       = 0.0
        self._accum_count   = 0
        self._log_history: List[Dict] = []

        os.makedirs(output_dir, exist_ok=True)

    # ── Group rollout ─────────────────────────────────────────────────────────

    @torch.no_grad()
    def sample_group(
        self,
        prompt:     str,
        true_label: int,
        problem:    str,
        problem_id: str = "",
    ) -> GroupSample:
        """
        Sample G completions for one prompt, compute rewards and advantages.
        Runs entirely under torch.no_grad() — no gradient state affected.
        """
        self.model.eval()

        enc = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=512,
        ).to(self.device)

        q_ids  = enc["input_ids"]        # (1, Q)
        q_mask = enc["attention_mask"]
        Q      = q_ids.shape[-1]

        # Repeat G times for batch generation
        batch_ids  = q_ids.expand(self.num_generations, -1)    # (G, Q)
        batch_mask = q_mask.expand(self.num_generations, -1)   # (G, Q)

        # Generate G completions
        out_ids = self.model.generate(
            input_ids=batch_ids,
            attention_mask=batch_mask,
            max_new_tokens=self.max_new_tokens,
            temperature=self.temperature,
            top_p=self.top_p,
            do_sample=True,
            pad_token_id=self.tokenizer.eos_token_id,
            eos_token_id=self.tokenizer.eos_token_id,
        )  # (G, Q+R_max)

        # Decode response tokens
        completions    = []
        completion_ids = []
        for i in range(self.num_generations):
            text = self.tokenizer.decode(out_ids[i, Q:], skip_special_tokens=True)
            completions.append(text.strip())
            completion_ids.append(out_ids[i:i+1, :])   # (1, Q+R_i)

        # Score all completions
        rewards, _ = compute_rewards_batch(
            raw_outputs=completions,
            true_labels=[true_label] * self.num_generations,
            problems=[problem]      * self.num_generations,
            cfg=self.reward_cfg,
            thinking_enabled=self.thinking_enabled,
        )

        self.model.train()

        group = GroupSample(
            prompt=prompt,
            completion_ids=completion_ids,
            completions=completions,
            prompt_len=Q,
            rewards=rewards,
            true_label=true_label,
            problem=problem,
            problem_id=problem_id,
        )
        group.compute_advantages()
        return group

    # ── GRPO loss for one group ───────────────────────────────────────────────

    def grpo_step(self, group: GroupSample) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Compute GRPO loss for one group.

        CRITICAL ORDER:
          1. Capture old_resp_lps under no_grad (rollout-time policy)
          2. Capture ref_resp_lps under no_grad (reference policy)
          3. Compute new_resp_lps WITH grad (new policy)
          4. Compute GRPO loss and return
        """
        Q  = group.prompt_len
        G  = self.num_generations
        pad_id = self.tokenizer.pad_token_id or self.tokenizer.eos_token_id

        # Pad all G full sequences to same length
        max_len = max(ids.shape[-1] for ids in group.completion_ids)
        all_ids  = torch.full((G, max_len), pad_id, dtype=torch.long)
        all_mask = torch.zeros(G, max_len, dtype=torch.long)

        for i, ids in enumerate(group.completion_ids):
            L = ids.shape[-1]
            all_ids[i, :L]  = ids.squeeze(0)
            all_mask[i, :L] = 1

        all_ids  = all_ids.to(self.device)
        all_mask = all_mask.to(self.device)

        # Response mask: 1 for positions >= Q in original sequence
        # In the shifted (logit→token) view, response starts at Q-1
        R_max = max_len - Q                                     # max response length
        resp_mask = all_mask[:, Q:].float()                     # (G, R_max)

        # ── Step 1: Old policy log probs (no grad) — MUST come first ─────────
        old_resp_lps = _get_response_log_probs(
            self.model, all_ids, all_mask, Q
        )  # (G, R_max) — detached, no grad

        # ── Step 2: Reference log probs (no grad) ────────────────────────────
        ref_resp_lps = _get_response_log_probs(
            self.ref_model, all_ids, all_mask, Q
        )  # (G, R_max) — detached, no grad

        # ── Step 3: New policy log probs (WITH grad) ─────────────────────────
        new_resp_lps, _ = _get_response_log_probs_grad(
            self.model, all_ids, all_mask, Q
        )  # (G, R_max) — has grad

        # Ensure all response tensors have the same R dimension
        R = min(new_resp_lps.shape[1], old_resp_lps.shape[1],
                ref_resp_lps.shape[1], resp_mask.shape[1])
        new_resp_lps = new_resp_lps[:, :R]
        old_resp_lps = old_resp_lps[:, :R]
        ref_resp_lps = ref_resp_lps[:, :R]
        resp_mask    = resp_mask[:, :R]

        # ── Step 4: Advantages tensor ─────────────────────────────────────────
        advantages = torch.tensor(
            group.advantages, dtype=torch.float32, device=self.device
        )  # (G,)

        # ── Step 5: GRPO loss ─────────────────────────────────────────────────
        loss, stats = compute_grpo_loss(
            new_resp_lps=new_resp_lps,
            old_resp_lps=old_resp_lps,
            ref_resp_lps=ref_resp_lps,
            resp_mask=resp_mask,
            advantages=advantages,
            epsilon=self.epsilon,
            beta=self.beta,
        )

        # Augment stats with reward info
        stats["reward/mean"] = float(np.mean(group.rewards))
        stats["reward/std"]  = float(np.std(group.rewards))
        stats["reward/max"]  = float(np.max(group.rewards))

        _, comps = compute_rewards_batch(
            group.completions,
            [group.true_label] * G,
            [group.problem]    * G,
            cfg=self.reward_cfg,
        )
        stats["accuracy/group_any"]  = float(any(c.get("correct", 0) for c in comps))
        stats["accuracy/group_mean"] = float(np.mean([c.get("correct", 0) for c in comps]))

        return loss, stats

    # ── Training loop ─────────────────────────────────────────────────────────

    def train(
        self,
        train_dataloader,
        eval_samples: Optional[List] = None,
    ) -> None:
        """
        GRPO outer training loop.

        Args:
            train_dataloader: yields dict batches with keys:
                              prompt, label, problem, problem_id
            eval_samples: List[RLVERSample] for periodic accuracy eval
        """
        logger.info(
            f"Starting GRPO: max_steps={self.max_steps} "
            f"G={self.num_generations} β={self.beta} ε={self.epsilon}"
        )
        self.model.train()
        self.optimizer.zero_grad()

        train_iter  = iter(train_dataloader)
        step        = 0
        accum_stats: List[Dict] = []

        while step < self.max_steps:
            try:
                batch = next(train_iter)
            except StopIteration:
                train_iter = iter(train_dataloader)
                batch      = next(train_iter)

            prompts     = batch["prompt"]
            labels      = batch["label"]
            problems    = batch.get("problem",    [""] * len(prompts))
            problem_ids = batch.get("problem_id", [f"p{i}" for i in range(len(prompts))])

            if hasattr(labels, "tolist"):
                labels = labels.tolist()

            # Process each prompt in the batch
            for prompt, label, problem, pid in zip(
                prompts, labels, problems, problem_ids
            ):
                # Sample G completions
                group = self.sample_group(
                    prompt=prompt,
                    true_label=int(label),
                    problem=problem,
                    problem_id=str(pid),
                )

                # Skip groups with zero variance (no learning signal)
                if not group.has_signal:
                    logger.debug(
                        f"Skipping group {pid}: reward std ~ 0 "
                        f"(reward={group.rewards[0]:.3f})"
                    )
                    continue

                # GRPO loss
                loss, stats = self.grpo_step(group)

                # Gradient accumulation
                (loss / self.gradient_accumulation_steps).backward()
                self._accum_count += 1
                accum_stats.append(stats)

                if self._accum_count % self.gradient_accumulation_steps == 0:
                    grad_norm = torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(), self.max_grad_norm
                    )
                    self.optimizer.step()
                    self.scheduler.step()
                    self.optimizer.zero_grad()

                    self.global_step += 1
                    step += 1

                    # Log
                    if self.global_step % self.logging_steps == 0 and accum_stats:
                        agg = {
                            k: float(np.mean([s[k] for s in accum_stats if k in s]))
                            for k in accum_stats[0]
                        }
                        agg["grad_norm"] = float(grad_norm)
                        agg["lr"] = self.scheduler.get_last_lr()[0]

                        logger.info(
                            f"[GRPO {self.global_step}/{self.max_steps}]  "
                            f"loss={agg['loss/total']:.4f}  "
                            f"kl={agg['kl/mean']:.4f}  "
                            f"clip={agg['ratio/clip_frac']:.3f}  "
                            f"r_mean={agg['reward/mean']:.3f}  "
                            f"acc={agg.get('accuracy/group_mean',0):.3f}  "
                            f"lr={agg['lr']:.2e}"
                        )
                        if self.wandb_enabled:
                            try:
                                import wandb
                                wandb.log({"step": self.global_step, **agg})
                            except Exception:
                                pass
                        self._log_history.append({"step": self.global_step, **agg})
                        accum_stats = []

                    # Checkpoint
                    if self.global_step % self.save_steps == 0:
                        self.save_checkpoint(f"checkpoint-{self.global_step}")

                    # Eval
                    if eval_samples and self.global_step % self.eval_steps == 0:
                        acc = self._quick_eval(eval_samples[:150])
                        logger.info(
                            f"[Eval {self.global_step}]  acc={acc:.4f}  "
                            f"(best={self.best_acc:.4f})"
                        )
                        if acc > self.best_acc:
                            self.best_acc = acc
                            self.save_checkpoint("best_model")
                            logger.info(f"  ↑ New best  acc={acc:.4f}")

                    if step >= self.max_steps:
                        break

        # Final
        self.save_checkpoint("final_model")
        with open(os.path.join(self.output_dir, "training_log.json"), "w") as f:
            json.dump(self._log_history, f, indent=2)
        logger.info("GRPO training complete.")

    # ── Quick eval ────────────────────────────────────────────────────────────

    @torch.no_grad()
    def _quick_eval(self, eval_samples: List) -> float:
        from dataset_builder import format_verification_prompt
        self.model.eval()
        correct = 0

        for s in eval_samples:
            prompt = format_verification_prompt(s, thinking_enabled=self.thinking_enabled)
            enc    = self.tokenizer(
                prompt, return_tensors="pt", truncation=True, max_length=512
            ).to(self.device)
            out = self.model.generate(
                **enc,
                max_new_tokens=128,
                do_sample=False,                     # greedy for eval
                pad_token_id=self.tokenizer.eos_token_id,
            )
            text = self.tokenizer.decode(
                out[0][enc["input_ids"].shape[-1]:], skip_special_tokens=True
            )
            _, comps = compute_rewards_batch(
                [text], [s.label], [s.problem], cfg=self.reward_cfg
            )
            correct += comps[0].get("correct", 0)

        self.model.train()
        return correct / max(len(eval_samples), 1)

    # ── Save ──────────────────────────────────────────────────────────────────

    def save_checkpoint(self, name: str) -> None:
        path = os.path.join(self.output_dir, name)
        os.makedirs(path, exist_ok=True)
        self.model.save_pretrained(path)
        self.tokenizer.save_pretrained(path)
        torch.save(
            {
                "optimizer":   self.optimizer.state_dict(),
                "scheduler":   self.scheduler.state_dict(),
                "global_step": self.global_step,
                "best_acc":    self.best_acc,
            },
            os.path.join(path, "trainer_state.pt"),
        )
        logger.info(f"Checkpoint → {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Smoke-test (CPU, no model load)
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    G, R, V = 8, 32, 8192

    new_lps = torch.randn(G, R)
    old_lps = (new_lps + torch.randn(G, R) * 0.05).detach()
    ref_lps = (new_lps + torch.randn(G, R) * 0.10).detach()
    mask    = torch.ones(G, R)
    mask[:, -6:] = 0    # simulate padding

    rewards = [random.uniform(-1.0, 1.0) for _ in range(G)]
    r_np    = np.array(rewards, dtype=np.float32)
    adv_np  = (r_np - r_np.mean()) / (r_np.std() + 1e-8)
    adv     = torch.tensor(adv_np, dtype=torch.float32)

    loss, stats = compute_grpo_loss(
        new_lps, old_lps, ref_lps, mask, adv, epsilon=0.2, beta=0.04
    )
    print(f"\n[GRPO loss smoke-test]  loss={loss.item():.4f}")
    for k, v in stats.items():
        print(f"  {k:<30}: {v:.4f}")

    # GroupSample
    g = GroupSample(
        prompt="What is 2+2?",
        completion_ids=[torch.zeros(1, 20, dtype=torch.long)] * G,
        completions=["4"] * G,
        prompt_len=10,
        rewards=rewards,
        true_label=1, problem="What is 2+2?", problem_id="p0",
    )
    g.compute_advantages()
    print(f"\n[GroupSample]")
    print(f"  rewards    : {[f'{r:.3f}' for r in g.rewards]}")
    print(f"  advantages : {[f'{a:.3f}' for a in g.advantages]}")
    print(f"  has_signal : {g.has_signal}")
    print("\n[OK] grpo_trainer_custom.py smoke-test passed.")
