"""
=============================================================================
RLVER — Data Download & Preprocessing Script
File  : scripts/01_download_data.py
Author: Dushyant (u23ai085)

Run BEFORE training. This script:
  1. Downloads and caches GSM8K (train + test) from HuggingFace
  2. Runs difficulty tagging on all samples
  3. Optionally runs Mistral-7B adversarial generation (--gen_adversarial)
  4. Saves two JSONL files:
       cache/datasets/rlver_train.jsonl   (train split, ~7473 samples + adversarials)
       cache/datasets/rlver_eval.jsonl    (test split,  ~1319 samples + adversarials)
  5. Prints dataset statistics

Usage:
  conda activate rlver_env

  # Fast: rule-based adversarials (no GPU needed)
  python scripts/01_download_data.py

  # Full: Mistral-7B adversarial generation (uses GPU, ~45 min)
  python scripts/01_download_data.py --gen_adversarial

  # Specify custom adversarial ratio and sample limits
  python scripts/01_download_data.py \
      --adversarial_ratio 0.4 \
      --max_train 7473 \
      --max_eval  1319 \
      --gen_adversarial

  # Re-generate even if cache exists
  python scripts/01_download_data.py --force
=============================================================================
"""

from __future__ import annotations

import os
import sys
import json
import time
import random
import logging
import argparse
from pathlib import Path
from typing import Optional, List, Dict
from collections import Counter

# ── Path setup ────────────────────────────────────────────────────────────────
PROJECT_ROOT = os.path.expanduser("~/Dushyant_u23ai085_9256777500")
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rlver_adversarial"))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rl_training"))

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Step 1: Environment check
# ─────────────────────────────────────────────────────────────────────────────

def check_environment() -> None:
    """Verify all required packages are importable."""
    import importlib

    required = [
        ("torch",             "PyTorch"),
        ("transformers",      "Transformers"),
        ("datasets",          "HuggingFace Datasets"),
        ("peft",              "PEFT"),
        ("trl",               "TRL"),
        ("accelerate",        "Accelerate"),
        ("numpy",             "NumPy"),
        ("sklearn",           "scikit-learn"),
        ("tqdm",              "tqdm"),
    ]

    all_ok = True
    print("\n[Environment Check]")
    for mod, name in required:
        try:
            m = importlib.import_module(mod)
            ver = getattr(m, "__version__", "?")
            print(f"  ✓ {name:<22} v{ver}")
        except ImportError:
            print(f"  ✗ {name:<22} NOT FOUND")
            all_ok = False

    # GPU
    import torch
    if torch.cuda.is_available():
        props = torch.cuda.get_device_properties(0)
        vram_gb = props.total_memory / 1e9
        print(f"\n  ✓ GPU: {props.name} ({vram_gb:.1f} GB VRAM)")
    else:
        print(f"\n  ⚠ GPU: Not available (CPU only)")

    if not all_ok:
        print("\n[ERROR] Missing packages. Run: bash 00_setup.sh")
        sys.exit(1)

    print()


# ─────────────────────────────────────────────────────────────────────────────
# Step 2: GSM8K download and caching
# ─────────────────────────────────────────────────────────────────────────────

def download_gsm8k(cache_dir: str) -> None:
    """
    Download GSM8K from HuggingFace and cache to disk.
    HF caches automatically; this just ensures the download happens.
    """
    from datasets import load_dataset

    print("[Step 2] Downloading GSM8K from HuggingFace ...")
    t0 = time.time()

    for split in ["train", "test"]:
        print(f"  Downloading split: {split} ...")
        ds = load_dataset(
            "openai/gsm8k",
            "main",
            split=split,
            cache_dir=os.path.join(cache_dir, "hf"),
        )
        print(f"  ✓ {split}: {len(ds)} samples")

    print(f"  GSM8K download complete in {time.time()-t0:.1f}s\n")


# ─────────────────────────────────────────────────────────────────────────────
# Step 3: Build RLVER JSONL datasets
# ─────────────────────────────────────────────────────────────────────────────

def build_and_save_datasets(
    cache_dir: str,
    datasets_dir: str,
    adversarial_ratio: float,
    max_train: Optional[int],
    max_eval: Optional[int],
    use_mistral_gen: bool,
    mistral_model_path: str,
    seed: int,
    force: bool,
) -> Dict[str, str]:
    """
    Build RLVER JSONL datasets (train + eval) and save to disk.

    Returns:
        Dict mapping split name → saved file path
    """
    from dataset_builder import RLVERDatasetBuilder

    os.makedirs(datasets_dir, exist_ok=True)

    saved_paths = {}

    for split, max_samples in [("train", max_train), ("test", max_eval)]:
        out_name = "rlver_train.jsonl" if split == "train" else "rlver_eval.jsonl"
        out_path = os.path.join(datasets_dir, out_name)

        if os.path.isfile(out_path) and not force:
            # Check line count
            with open(out_path) as f:
                n = sum(1 for _ in f)
            print(f"[Step 3] Cache exists: {out_path} ({n} samples) — skipping.")
            saved_paths[split] = out_path
            continue

        print(f"[Step 3] Building RLVER {split} dataset ...")
        t0 = time.time()

        builder = RLVERDatasetBuilder(
            adversarial_ratio=adversarial_ratio,
            cache_dir=os.path.join(cache_dir, "hf"),
            seed=seed,
        )

        # Inject Mistral adversarial generator if requested
        if use_mistral_gen and os.path.isdir(mistral_model_path):
            print(f"  Loading Mistral adversarial generator: {mistral_model_path}")
            from adversarial_gen import AdversarialGenerator
            gen = AdversarialGenerator(
                model_path=mistral_model_path,
                device="cuda",
                max_new_tokens=300,
                temperature=0.85,
                top_p=0.92,
                seed=seed,
            )
            gen.load()
            builder.set_adversarial_generator(gen)
            print("  ✓ Mistral generator loaded")
        elif use_mistral_gen:
            print(f"  ⚠ Mistral model not found at {mistral_model_path}.")
            print(f"    Falling back to rule-based adversarial generation.")

        samples = builder.build(
            split=split,
            max_samples=max_samples,
            save_path=out_path,
        )

        # Unload Mistral to free GPU before next split
        if use_mistral_gen and hasattr(builder, "_adversarial_generator") \
                and builder._adversarial_generator is not None:
            builder._adversarial_generator.unload()

        print(f"  ✓ {split}: {len(samples)} samples saved in {time.time()-t0:.1f}s")
        saved_paths[split] = out_path

    return saved_paths


# ─────────────────────────────────────────────────────────────────────────────
# Step 4: Validate and print statistics
# ─────────────────────────────────────────────────────────────────────────────

def validate_and_print_stats(saved_paths: Dict[str, str]) -> None:
    """Load saved JSONL files, validate schema, print statistics."""
    print("\n[Step 4] Dataset Validation & Statistics")
    print("=" * 60)

    required_keys = {
        "problem_id", "problem", "solution", "label",
        "is_adversarial", "difficulty", "answer", "source"
    }

    for split, path in saved_paths.items():
        print(f"\n  Split: {split} — {path}")

        samples = []
        errors = []

        with open(path) as f:
            for i, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                    missing = required_keys - set(d.keys())
                    if missing:
                        errors.append(f"Line {i+1}: missing keys {missing}")
                    else:
                        samples.append(d)
                except json.JSONDecodeError as e:
                    errors.append(f"Line {i+1}: JSON error: {e}")

        if errors:
            print(f"    ⚠ Schema errors ({len(errors)}):")
            for e in errors[:5]:
                print(f"      {e}")

        if not samples:
            print(f"    ✗ No valid samples found!")
            continue

        # Statistics
        n_total      = len(samples)
        n_correct    = sum(1 for s in samples if s["label"] == 1)
        n_adversarial = sum(1 for s in samples if s["is_adversarial"])
        diff_counts  = Counter(s["difficulty"] for s in samples)

        # Answer length distribution
        sol_lengths = [len(s["solution"].split()) for s in samples]
        avg_sol_len = sum(sol_lengths) / len(sol_lengths)

        # Problem length
        prob_lengths = [len(s["problem"].split()) for s in samples]
        avg_prob_len = sum(prob_lengths) / len(prob_lengths)

        print(f"    Total samples     : {n_total:,}")
        print(f"    Label=1 (correct) : {n_correct:,} ({100*n_correct/n_total:.1f}%)")
        print(f"    Label=0 (wrong)   : {n_total-n_correct:,} ({100*(n_total-n_correct)/n_total:.1f}%)")
        print(f"    Adversarial       : {n_adversarial:,} ({100*n_adversarial/n_total:.1f}%)")
        print(f"    Difficulty breakdown:")
        for diff in ["easy", "medium", "hard"]:
            c = diff_counts.get(diff, 0)
            print(f"      {diff:<8}: {c:,} ({100*c/n_total:.1f}%)")
        print(f"    Avg problem len   : {avg_prob_len:.1f} words")
        print(f"    Avg solution len  : {avg_sol_len:.1f} words")

        # Sample peek
        sample = samples[0]
        print(f"\n    Sample #0:")
        print(f"      problem_id  : {sample['problem_id']}")
        print(f"      label       : {sample['label']}")
        print(f"      is_adv      : {sample['is_adversarial']}")
        print(f"      difficulty  : {sample['difficulty']}")
        print(f"      problem[:80]: {sample['problem'][:80]}...")

    print("\n" + "=" * 60)


# ─────────────────────────────────────────────────────────────────────────────
# Step 5: Prompt template preview
# ─────────────────────────────────────────────────────────────────────────────

def preview_prompts(datasets_dir: str) -> None:
    """Show formatted prompt examples for thinking and non-thinking modes."""
    from dataset_builder import RLVERDatasetBuilder, RLVERSample, format_verification_prompt

    train_path = os.path.join(datasets_dir, "rlver_train.jsonl")
    if not os.path.isfile(train_path):
        return

    samples = RLVERDatasetBuilder.load_jsonl(train_path)
    if not samples:
        return

    print("\n[Step 5] Prompt Template Preview")
    print("=" * 70)

    # Pick one clean and one adversarial example
    clean_ex = next((s for s in samples if not s.is_adversarial), samples[0])
    adv_ex   = next((s for s in samples if s.is_adversarial), samples[-1])

    for sample, label in [(clean_ex, "CLEAN sample"), (adv_ex, "ADVERSARIAL sample")]:
        print(f"\n  {label} (label={sample.label}, difficulty={sample.difficulty})")
        print(f"  {'-'*66}")
        print("\n  [Thinking mode ON]")
        prompt_think = format_verification_prompt(sample, thinking_enabled=True)
        # Print first 400 chars
        print(f"  {prompt_think[:400].strip()}")
        print(f"  ...")
        print("\n  [Thinking mode OFF]")
        prompt_nothink = format_verification_prompt(sample, thinking_enabled=False)
        print(f"  {prompt_nothink[:300].strip()}")

    print("\n" + "=" * 70)


# ─────────────────────────────────────────────────────────────────────────────
# Step 6: Directory structure summary
# ─────────────────────────────────────────────────────────────────────────────

def print_directory_summary() -> None:
    """Print current project directory structure."""
    print("\n[Step 6] Project Directory Summary")
    print("=" * 60)

    dirs_to_check = [
        ("models/qwen_1p5b",         "Qwen2.5-1.5B-Instruct (base)"),
        ("models/qwen_7b",           "Qwen2.5-7B-Instruct (base)"),
        ("models/mistral_7b_sim",    "Mistral-7B-Instruct-v0.3 (adversary)"),
        ("cache/datasets",           "RLVER datasets (JSONL)"),
        ("cache/hf",                 "HuggingFace model cache"),
        ("rl_training/checkpoints",  "RL training checkpoints"),
        ("results",                  "Evaluation results"),
        ("logs",                     "Training logs"),
        ("configs",                  "YAML configurations"),
    ]

    for rel_path, desc in dirs_to_check:
        full = os.path.join(PROJECT_ROOT, rel_path)
        if os.path.isdir(full):
            # Count files
            n_files = sum(len(files) for _, _, files in os.walk(full))
            size_mb = sum(
                os.path.getsize(os.path.join(dp, f))
                for dp, _, files in os.walk(full)
                for f in files
            ) / 1e6
            status = f"✓  {n_files} files  ({size_mb:.0f} MB)"
        else:
            status = "✗  not found"

        print(f"  {rel_path:<35} {status}")
        print(f"  {'':35}   {desc}")

    print("=" * 60)


# ─────────────────────────────────────────────────────────────────────────────
# Step 7: Write run_config.json (used by training scripts)
# ─────────────────────────────────────────────────────────────────────────────

def write_run_config(
    datasets_dir: str,
    adversarial_ratio: float,
    seed: int,
) -> None:
    """Write a run_config.json summarizing data paths for training scripts."""
    config = {
        "train_jsonl": os.path.join(datasets_dir, "rlver_train.jsonl"),
        "eval_jsonl":  os.path.join(datasets_dir, "rlver_eval.jsonl"),
        "adversarial_ratio": adversarial_ratio,
        "seed": seed,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "gsm8k_train_url": "https://huggingface.co/datasets/openai/gsm8k",
        "model_paths": {
            "qwen_1p5b": os.path.join(PROJECT_ROOT, "models", "qwen_1p5b"),
            "qwen_7b":   os.path.join(PROJECT_ROOT, "models", "qwen_7b"),
            "mistral":   os.path.join(PROJECT_ROOT, "models", "mistral_7b_sim"),
        },
    }
    config_path = os.path.join(PROJECT_ROOT, "configs", "run_config.json")
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)
    print(f"\n  Run config saved → {config_path}")


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="RLVER Data Download & Preprocessing",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--adversarial_ratio", type=float, default=0.4,
        help="Fraction of training samples that get adversarial variants"
    )
    parser.add_argument(
        "--max_train", type=int, default=7473,
        help="Max GSM8K training samples (full = 7473)"
    )
    parser.add_argument(
        "--max_eval", type=int, default=1319,
        help="Max GSM8K test samples (full = 1319)"
    )
    parser.add_argument(
        "--gen_adversarial", action="store_true",
        help="Use Mistral-7B to generate adversarial solutions (requires GPU, ~45 min)"
    )
    parser.add_argument(
        "--mistral_model_path", type=str,
        default=os.path.join(PROJECT_ROOT, "models", "mistral_7b_sim"),
        help="Path to local Mistral-7B model directory"
    )
    parser.add_argument(
        "--datasets_dir", type=str,
        default=os.path.join(PROJECT_ROOT, "cache", "datasets"),
        help="Output directory for processed JSONL files"
    )
    parser.add_argument(
        "--cache_dir", type=str,
        default=os.path.join(PROJECT_ROOT, "cache"),
        help="Root HuggingFace cache directory"
    )
    parser.add_argument(
        "--seed", type=int, default=42,
        help="Random seed for reproducibility"
    )
    parser.add_argument(
        "--force", action="store_true",
        help="Overwrite existing cached datasets"
    )
    parser.add_argument(
        "--skip_download", action="store_true",
        help="Skip GSM8K download (use if already cached)"
    )
    parser.add_argument(
        "--preview_prompts", action="store_true",
        help="Show sample formatted prompts after building"
    )
    return parser


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(message)s",
        datefmt="%H:%M:%S",
    )

    parser = build_parser()
    args = parser.parse_args()

    random.seed(args.seed)

    print("\n" + "=" * 70)
    print("  RLVER — Data Download & Preprocessing")
    print(f"  Project root     : {PROJECT_ROOT}")
    print(f"  Datasets dir     : {args.datasets_dir}")
    print(f"  Adversarial ratio: {args.adversarial_ratio}")
    print(f"  Max train samples: {args.max_train}")
    print(f"  Max eval samples : {args.max_eval}")
    print(f"  Gen adversarial  : {'Mistral-7B' if args.gen_adversarial else 'rule-based'}")
    print(f"  Seed             : {args.seed}")
    print("=" * 70)

    # ── Step 1: Environment ───────────────────────────────────────────────────
    check_environment()

    # ── Step 2: Download GSM8K ────────────────────────────────────────────────
    if not args.skip_download:
        download_gsm8k(cache_dir=args.cache_dir)
    else:
        print("[Step 2] Skipping GSM8K download (--skip_download).")

    # ── Step 3: Build datasets ────────────────────────────────────────────────
    saved_paths = build_and_save_datasets(
        cache_dir=args.cache_dir,
        datasets_dir=args.datasets_dir,
        adversarial_ratio=args.adversarial_ratio,
        max_train=args.max_train,
        max_eval=args.max_eval,
        use_mistral_gen=args.gen_adversarial,
        mistral_model_path=args.mistral_model_path,
        seed=args.seed,
        force=args.force,
    )

    # ── Step 4: Validate ──────────────────────────────────────────────────────
    validate_and_print_stats(saved_paths)

    # ── Step 5: Prompt preview ────────────────────────────────────────────────
    if args.preview_prompts:
        preview_prompts(args.datasets_dir)

    # ── Step 6: Directory summary ─────────────────────────────────────────────
    print_directory_summary()

    # ── Step 7: Write run config ──────────────────────────────────────────────
    write_run_config(
        datasets_dir=args.datasets_dir,
        adversarial_ratio=args.adversarial_ratio,
        seed=args.seed,
    )

    print("\n" + "=" * 70)
    print("  DATA PREPARATION COMPLETE")
    print("=" * 70)
    print("\n  Next steps:")
    print("  1. conda activate rlver_env")
    print("  2. bash scripts/02_run_training.sh               # all 4 variants")
    print("  3. bash scripts/03_run_eval.sh                   # evaluate all")
    print()
    print("  Or run individual variants:")
    print("  python rl_training/rlver_rl_train.py --algorithm grpo --thinking")
    print("  python rl_training/rlver_rl_train.py --algorithm ppo  --thinking")
    print()


if __name__ == "__main__":
    main()
