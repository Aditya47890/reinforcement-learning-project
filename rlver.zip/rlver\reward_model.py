"""
=============================================================================
RLVER — Reward Model
File  : rl_training/reward_model.py
Author: Dushyant (u23ai085)

Implements the reward function for RLVER RL training.

Reward components:
  R_total = R_verification + R_reasoning + R_format + R_length_penalty

  R_verification  ∈ {-1.0, +1.0}   — correct/wrong binary decision
  R_reasoning     ∈ [0, 0.3]        — partial credit for valid CoT
  R_format        ∈ {0, 0.1}        — output format compliance
  R_length_penalty ∈ [-0.3, 0]      — penalize excessively long outputs

  Total range: [-1.3, 1.4]
  After clipping to [-1.0, 1.0] for stability.

Used by both PPO and GRPO trainers.
=============================================================================
"""

from __future__ import annotations

import re
import math
import logging
from dataclasses import dataclass
from typing import List, Optional, Tuple, Dict

import torch
import numpy as np

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RewardConfig:
    correct_verification: float = 1.0
    wrong_verification: float = -1.0
    partial_reasoning: float = 0.3        # max partial reward for valid CoT
    format_bonus: float = 0.1             # reward for correct output format
    length_penalty_coef: float = 0.001    # penalty per token above threshold
    max_length_no_penalty: int = 200      # token threshold
    clip_min: float = -1.0
    clip_max: float = 1.0

    # Thinking-specific
    thinking_reward_enabled: bool = True
    min_thinking_words: int = 10          # below this = no partial reward


# ─────────────────────────────────────────────────────────────────────────────
# Output parser (shared with metrics.py but standalone here for import safety)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_verdict(raw_output: str) -> Optional[int]:
    """
    Extract predicted label from raw model output.
    Returns 1 (correct), 0 (incorrect), or None (unparseable).
    """
    # Primary: explicit VERDICT: CORRECT/INCORRECT
    match = re.search(r"VERDICT\s*:\s*(CORRECT|INCORRECT)", raw_output, re.IGNORECASE)
    if match:
        return 1 if match.group(1).upper() == "CORRECT" else 0

    # Fallback: natural language
    lower = raw_output.lower()
    if "the solution is correct" in lower or "solution is right" in lower:
        return 1
    if "the solution is incorrect" in lower or "solution is wrong" in lower:
        return 0

    # Last resort: look for standalone correct/incorrect near end of output
    tail = raw_output[-200:].lower()
    if re.search(r"\bcorrect\b", tail) and not re.search(r"\bincorrect\b", tail):
        return 1
    if re.search(r"\bincorrect\b", tail) or re.search(r"\bwrong\b", tail):
        return 0

    return None


def _parse_thinking(raw_output: str) -> Optional[str]:
    """Extract <think>...</think> block."""
    match = re.search(r"<think>(.*?)</think>", raw_output, re.DOTALL | re.IGNORECASE)
    return match.group(1).strip() if match else None


def _count_tokens_approx(text: str) -> int:
    """Approximate token count (chars / 4)."""
    return max(1, len(text) // 4)


# ─────────────────────────────────────────────────────────────────────────────
# Individual reward components
# ─────────────────────────────────────────────────────────────────────────────

def _verification_reward(
    predicted_label: Optional[int],
    true_label: int,
    cfg: RewardConfig,
) -> float:
    """Binary reward for correct/wrong verification decision."""
    if predicted_label is None:
        # Unparseable output — mild penalty
        return cfg.wrong_verification * 0.5

    if predicted_label == true_label:
        return cfg.correct_verification
    else:
        return cfg.wrong_verification


def _reasoning_reward(
    thinking_text: Optional[str],
    problem: str,
    cfg: RewardConfig,
) -> float:
    """
    Partial reward for valid chain-of-thought reasoning.
    Range: [0, cfg.partial_reasoning]
    """
    if not cfg.thinking_reward_enabled:
        return 0.0

    if thinking_text is None or len(thinking_text.split()) < cfg.min_thinking_words:
        return 0.0

    score = 0.0
    words = thinking_text.split()
    thinking_lower = thinking_text.lower()

    # 1. Length adequacy (0–0.4 of partial_reasoning)
    if len(words) >= 50:
        score += 0.4
    elif len(words) >= 20:
        score += 0.2

    # 2. Mathematical content (0–0.3 of partial_reasoning)
    math_hit = bool(re.search(r"\d+\s*[\+\-\*\/]\s*\d+|\=\s*\d+", thinking_text))
    if math_hit:
        score += 0.3

    # 3. Problem reference (0–0.2 of partial_reasoning)
    problem_nums = set(re.findall(r"\b\d+\b", problem))
    think_nums = set(re.findall(r"\b\d+\b", thinking_text))
    if problem_nums and len(problem_nums & think_nums) / len(problem_nums) > 0.3:
        score += 0.2

    # 4. Logical connectives (0–0.1 of partial_reasoning)
    connectives = ["therefore", "thus", "because", "since", "so", "hence"]
    if any(c in thinking_lower for c in connectives):
        score += 0.1

    return min(1.0, score) * cfg.partial_reasoning


def _format_reward(raw_output: str, cfg: RewardConfig) -> float:
    """
    Reward for compliant output format.
    Full bonus if both VERDICT and CONFIDENCE are present.
    """
    has_verdict = bool(
        re.search(r"VERDICT\s*:\s*(CORRECT|INCORRECT)", raw_output, re.IGNORECASE)
    )
    has_confidence = bool(
        re.search(r"CONFIDENCE\s*:\s*[0-9]*\.?[0-9]+", raw_output, re.IGNORECASE)
    )

    if has_verdict and has_confidence:
        return cfg.format_bonus
    elif has_verdict:
        return cfg.format_bonus * 0.5
    return 0.0


def _length_penalty(raw_output: str, cfg: RewardConfig) -> float:
    """Penalty for outputs that are excessively long."""
    n_tokens = _count_tokens_approx(raw_output)
    excess = max(0, n_tokens - cfg.max_length_no_penalty)
    return -cfg.length_penalty_coef * excess


# ─────────────────────────────────────────────────────────────────────────────
# Main reward function
# ─────────────────────────────────────────────────────────────────────────────

def compute_reward(
    raw_output: str,
    true_label: int,
    problem: str,
    cfg: Optional[RewardConfig] = None,
    thinking_enabled: bool = True,
) -> Tuple[float, Dict[str, float]]:
    """
    Compute total reward for one model output.

    Args:
        raw_output: Full text generated by the policy model.
        true_label: Ground truth (1=correct solution, 0=incorrect).
        problem: The math problem text (used for reasoning quality check).
        cfg: RewardConfig (uses defaults if None).
        thinking_enabled: Whether to extract and reward thinking.

    Returns:
        (total_reward, component_dict)
        total_reward is clipped to [cfg.clip_min, cfg.clip_max]
    """
    if cfg is None:
        cfg = RewardConfig()

    # Parse output
    predicted_label = _parse_verdict(raw_output)
    thinking_text = _parse_thinking(raw_output) if thinking_enabled else None

    # Compute components
    r_verify = _verification_reward(predicted_label, true_label, cfg)
    r_reason = _reasoning_reward(thinking_text, problem, cfg)
    r_format = _format_reward(raw_output, cfg)
    r_length = _length_penalty(raw_output, cfg)

    total = r_verify + r_reason + r_format + r_length
    total_clipped = float(np.clip(total, cfg.clip_min, cfg.clip_max))

    components = {
        "r_verification": r_verify,
        "r_reasoning": r_reason,
        "r_format": r_format,
        "r_length_penalty": r_length,
        "r_total_raw": total,
        "r_total": total_clipped,
        "predicted_label": predicted_label if predicted_label is not None else -1,
        "true_label": true_label,
        "correct": int(predicted_label == true_label) if predicted_label is not None else 0,
    }

    return total_clipped, components


# ─────────────────────────────────────────────────────────────────────────────
# Batch reward (for TRL integration)
# ─────────────────────────────────────────────────────────────────────────────

def compute_rewards_batch(
    raw_outputs: List[str],
    true_labels: List[int],
    problems: List[str],
    cfg: Optional[RewardConfig] = None,
    thinking_enabled: bool = True,
) -> Tuple[List[float], List[Dict[str, float]]]:
    """
    Batch version of compute_reward.

    Args:
        raw_outputs: List of generated strings from policy model.
        true_labels: Ground truth labels (1 or 0).
        problems: Corresponding math problems.
        cfg: Shared RewardConfig.
        thinking_enabled: Whether thinking mode is active.

    Returns:
        (rewards, component_list)
    """
    assert len(raw_outputs) == len(true_labels) == len(problems), (
        "raw_outputs, true_labels, problems must have same length"
    )

    if cfg is None:
        cfg = RewardConfig()

    rewards = []
    components = []

    for out, label, prob in zip(raw_outputs, true_labels, problems):
        r, comp = compute_reward(out, label, prob, cfg=cfg, thinking_enabled=thinking_enabled)
        rewards.append(r)
        components.append(comp)

    return rewards, components


# ─────────────────────────────────────────────────────────────────────────────
# TRL-compatible reward callable
# ─────────────────────────────────────────────────────────────────────────────

class RLVERRewardFunction:
    """
    Callable reward function compatible with TRL PPOTrainer and GRPOTrainer.

    TRL expects: reward_fn(outputs, inputs) → List[float]
    where:
        outputs: List[str]  — generated completions
        inputs : Dict       — batch from dataset (must have 'label', 'prompt')
    """

    def __init__(
        self,
        cfg: Optional[RewardConfig] = None,
        thinking_enabled: bool = True,
    ):
        self.cfg = cfg or RewardConfig()
        self.thinking_enabled = thinking_enabled
        self._step = 0
        self._reward_history: List[float] = []

    def __call__(
        self,
        completions: List[str],
        **kwargs,
    ) -> List[float]:
        """
        TRL GRPOTrainer reward function signature:
            reward_fn(completions, **kwargs) → List[float]

        kwargs contains the full batch dict (labels, prompts, etc.)
        """
        labels = kwargs.get("label", [1] * len(completions))
        problems = kwargs.get("problem", [""] * len(completions))

        # Handle tensor labels
        if isinstance(labels, torch.Tensor):
            labels = labels.tolist()

        rewards, components = compute_rewards_batch(
            raw_outputs=completions,
            true_labels=labels,
            problems=problems,
            cfg=self.cfg,
            thinking_enabled=self.thinking_enabled,
        )

        self._step += 1
        self._reward_history.extend(rewards)

        if self._step % 50 == 0:
            recent = self._reward_history[-200:]
            logger.info(
                f"[Reward] step={self._step}  "
                f"mean={np.mean(recent):.4f}  "
                f"std={np.std(recent):.4f}  "
                f"acc={np.mean([c['correct'] for c in components[-len(completions):]]):.3f}"
            )

        return rewards

    def get_stats(self) -> Dict[str, float]:
        if not self._reward_history:
            return {}
        return {
            "mean_reward": float(np.mean(self._reward_history)),
            "std_reward": float(np.std(self._reward_history)),
            "min_reward": float(np.min(self._reward_history)),
            "max_reward": float(np.max(self._reward_history)),
            "total_steps": self._step,
        }


# ─────────────────────────────────────────────────────────────────────────────
# PPO-specific: value target
# ─────────────────────────────────────────────────────────────────────────────

def compute_returns(
    rewards: List[float],
    gamma: float = 0.99,
) -> List[float]:
    """Compute discounted cumulative returns (for single-step episodes, = reward)."""
    # For single-turn verification, each episode is one step.
    # Returns = reward for each step.
    returns = []
    G = 0.0
    for r in reversed(rewards):
        G = r + gamma * G
        returns.insert(0, G)
    return returns


# ─────────────────────────────────────────────────────────────────────────────
# Smoke-test
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import json

    logging.basicConfig(level=logging.INFO)

    cfg = RewardConfig()
    rf = RLVERRewardFunction(cfg=cfg, thinking_enabled=True)

    test_cases = [
        # (output, true_label, problem, description)
        (
            "<think>\nThe problem asks for 240/8. 240÷8=30. The solution says 30. "
            "That matches.\n</think>\nVERDICT: CORRECT\nCONFIDENCE: 0.95",
            1, "240 cookies in 8 hours, how many per hour?",
            "Correct prediction, good thinking"
        ),
        (
            "<think>\nChecks... answer seems off by 5.\n</think>\n"
            "VERDICT: INCORRECT\nCONFIDENCE: 0.80",
            0, "Find x + y where x=3, y=4",
            "Correct prediction (correctly identified wrong solution)"
        ),
        (
            "VERDICT: CORRECT\nCONFIDENCE: 0.70",
            0, "Basic arithmetic problem",
            "Wrong prediction, no thinking, correct format"
        ),
        (
            "I think this looks right to me.",
            1, "Some problem",
            "Unparseable output"
        ),
    ]

    print(f"\n{'='*70}")
    print(f"  RLVER Reward Function — Test Cases")
    print(f"{'='*70}")
    for out, label, prob, desc in test_cases:
        r, comp = compute_reward(out, label, prob, cfg=cfg)
        print(f"\n  [{desc}]")
        print(f"  True label   : {label}  Predicted: {comp['predicted_label']}")
        print(f"  R_verify     : {comp['r_verification']:+.2f}")
        print(f"  R_reason     : {comp['r_reasoning']:+.2f}")
        print(f"  R_format     : {comp['r_format']:+.2f}")
        print(f"  R_length_pen : {comp['r_length_penalty']:+.4f}")
        print(f"  R_TOTAL      : {r:+.4f}")
    print(f"\n{'='*70}")
