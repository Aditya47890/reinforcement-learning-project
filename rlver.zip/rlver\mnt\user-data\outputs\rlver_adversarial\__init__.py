"""
RLVER Adversarial Evaluation Package
=====================================
Submodules
----------
dataset_builder
    RLVERSample, RLVERDatasetBuilder, format_verification_prompt,
    VERIFY_PROMPT_THINKING, VERIFY_PROMPT_NO_THINKING, to_hf_dataset,
    perturb_solution_rule_based

adversarial_gen
    AdversarialGenerator, AdversarialStrategy

metrics
    VerificationSample, EvalMetrics, compute_metrics,
    parse_model_output, compute_thinking_quality_score, compute_ece,
    save_metrics, load_metrics, compare_metrics

rlver_eval
    EvalModel, evaluate_model, evaluate_all_variants,
    print_comparison_table, resolve_model_path
"""

from .metrics import (
    VerificationSample,
    EvalMetrics,
    compute_metrics,
    parse_model_output,
    compute_thinking_quality_score,
    compute_ece,
    save_metrics,
    load_metrics,
    compare_metrics,
)

from .dataset_builder import (
    RLVERSample,
    RLVERDatasetBuilder,
    format_verification_prompt,
    to_hf_dataset,
    perturb_solution_rule_based,
    assign_difficulty,
    VERIFY_PROMPT_THINKING,
    VERIFY_PROMPT_NO_THINKING,
)

from .adversarial_gen import (
    AdversarialGenerator,
    AdversarialStrategy,
)

__version__ = "1.0.0"
__author__  = "Dushyant (u23ai085)"
__all__ = [
    # metrics
    "VerificationSample", "EvalMetrics", "compute_metrics",
    "parse_model_output", "compute_thinking_quality_score", "compute_ece",
    "save_metrics", "load_metrics", "compare_metrics",
    # dataset_builder
    "RLVERSample", "RLVERDatasetBuilder", "format_verification_prompt",
    "to_hf_dataset", "perturb_solution_rule_based", "assign_difficulty",
    "VERIFY_PROMPT_THINKING", "VERIFY_PROMPT_NO_THINKING",
    # adversarial_gen
    "AdversarialGenerator", "AdversarialStrategy",
]
