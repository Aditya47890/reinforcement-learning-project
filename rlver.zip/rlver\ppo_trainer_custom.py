"""
=============================================================================
RLVER — Custom PPO Trainer
File  : rl_training/ppo_trainer_custom.py
Author: Dushyant (u23ai085)

Self-contained PPO trainer for RLVER. No dependency on TRL PPOTrainer.

Architecture:
  Actor  : Qwen2.5-7B-Instruct + LoRA  (policy π_θ)
  Critic : ValueHead on top of actor hidden state
  Ref    : Frozen copy of actor        (KL penalty baseline π_ref)

Key design decisions:
  - RolloutSample stores query_ids and response_ids SEPARATELY (not concatenated)
    so the PPO loss can correctly mask prompt vs response tokens.
  - GAE is computed over the rollout buffer before each update epoch.
  - KL penalty adapts via KLController to stay near target_kl.
  - Gradient accumulation is tracked via a dedicated counter (not global_step).

Mathematical formulation:
  L_CLIP  = E[min(r_t·A_t, clip(r_t, 1-ε, 1+ε)·A_t)]
  L_VF    = 0.5 · E[(V_θ(s) - V_target)²]          (clipped)
  L_ENT   = E[-log π_θ(a|s)]
  L_KL    = KL(π_θ || π_ref)
  L_TOTAL = -L_CLIP + c1·L_VF - c2·L_ENT + β·L_KL
=============================================================================
"""

from __future__ import annotations

import os
import sys
import json
import time
import random
import logging
from collections import deque
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, get_cosine_schedule_with_warmup

PROJECT_ROOT = os.path.expanduser("~/Dushyant_u23ai085_9256777500")
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rlver_adversarial"))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rl_training"))

from reward_model import RewardConfig, compute_rewards_batch

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Value Head
# ─────────────────────────────────────────────────────────────────────────────

class ValueHead(nn.Module):
    """
    Scalar value head: last-token hidden state → V(s).
    Reads the hidden state at the last non-padding position.
    """

    def __init__(self, hidden_size: int, dropout: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        self.summary = nn.Linear(hidden_size, 1)
        nn.init.normal_(self.summary.weight, std=0.01)
        nn.init.zeros_(self.summary.bias)

    def forward(
        self,
        hidden_states: torch.Tensor,              # (B, T, H)
        attention_mask: Optional[torch.Tensor],   # (B, T)
    ) -> torch.Tensor:                             # (B,)
        if attention_mask is not None:
            seq_len = attention_mask.sum(dim=1) - 1            # (B,)
            seq_len = seq_len.clamp(min=0).long()
            batch_idx = torch.arange(
                hidden_states.size(0), device=hidden_states.device
            )
            last_hidden = hidden_states[batch_idx, seq_len, :]  # (B, H)
        else:
            last_hidden = hidden_states[:, -1, :]

        return self.summary(self.dropout(last_hidden)).squeeze(-1)  # (B,)


class ActorCriticModel(nn.Module):
    """
    CausalLM + ValueHead.
    Policy and value function share all transformer weights;
    only the small ValueHead is exclusively for the critic.
    """

    def __init__(self, base_model: nn.Module, hidden_size: int, dropout: float = 0.1):
        super().__init__()
        self.base_model = base_model
        self.value_head = ValueHead(hidden_size, dropout=dropout)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        return_value: bool = True,
    ) -> Dict[str, torch.Tensor]:
        outputs = self.base_model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_hidden_states=True,
            return_dict=True,
        )
        result = {"logits": outputs.logits}
        if return_value:
            hidden = outputs.hidden_states[-1]
            result["values"] = self.value_head(hidden, attention_mask)
        return result

    def generate(self, *args, **kwargs):
        """Delegate to base model for generation."""
        return self.base_model.generate(*args, **kwargs)


# ─────────────────────────────────────────────────────────────────────────────
# Rollout Buffer
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RolloutSample:
    """
    One (prompt → response → reward) trajectory.

    IMPORTANT: query_ids and response_ids are stored SEPARATELY.
    query_ids  : tokenized prompt only (1D LongTensor)
    response_ids: tokenized response only (1D LongTensor)
    This makes it easy to build the response mask for the PPO loss.
    """
    query_ids:    torch.Tensor   # (Q,)   — prompt tokens
    response_ids: torch.Tensor   # (R,)   — response tokens only (no prompt)

    reward:    float             # scalar from reward_fn
    value:     float             # V(s) from critic at rollout time
    log_prob:  float             # mean log prob of response tokens (old policy)

    advantage: float = 0.0       # filled by GAE after batch collection
    returns:   float = 0.0       # filled by GAE after batch collection

    # Metadata
    problem_id: str = ""
    true_label: int = 1
    correct:    bool = False


class RolloutBuffer:
    """Fixed-capacity buffer for PPO rollout data."""

    def __init__(self, capacity: int = 512):
        self.capacity = capacity
        self._buf: List[RolloutSample] = []

    def add(self, s: RolloutSample) -> None:
        if len(self._buf) >= self.capacity:
            self._buf.pop(0)
        self._buf.append(s)

    def clear(self) -> None:
        self._buf.clear()

    def __len__(self) -> int:
        return len(self._buf)

    def get_batches(self, mini_batch_size: int):
        """Yield randomly ordered mini-batches without replacement."""
        idxs = list(range(len(self._buf)))
        random.shuffle(idxs)
        for start in range(0, len(idxs), mini_batch_size):
            yield [self._buf[i] for i in idxs[start: start + mini_batch_size]]

    def compute_gae(
        self,
        gamma: float = 0.99,
        lam: float = 0.95,
        normalize: bool = True,
    ) -> None:
        """
        Compute GAE advantages and discounted returns in-place.
        For single-step episodes (one turn verification):
          delta_t = r_t - V(s_t)   [next_value = 0, terminal]
          A_t     = delta_t + γλ · A_{t+1}  (→ just delta for single-step)
        """
        rewards = np.array([s.reward for s in self._buf], dtype=np.float32)
        values  = np.array([s.value  for s in self._buf], dtype=np.float32)

        adv = np.zeros_like(rewards)
        gae = 0.0
        for t in reversed(range(len(self._buf))):
            delta = rewards[t] + gamma * 0.0 - values[t]   # next_value=0 (terminal)
            gae   = delta + gamma * lam * gae
            adv[t] = gae

        ret = adv + values

        if normalize and adv.std() > 1e-8:
            adv = (adv - adv.mean()) / (adv.std() + 1e-8)

        for i, s in enumerate(self._buf):
            s.advantage = float(adv[i])
            s.returns   = float(ret[i])


# ─────────────────────────────────────────────────────────────────────────────
# Adaptive KL Controller
# ─────────────────────────────────────────────────────────────────────────────

class KLController:
    """
    Adaptive β for KL penalty term (Ziegler et al. 2019).
    Increases β if KL > target, decreases if KL < target.
    """

    def __init__(
        self,
        init_kl_coef: float = 0.05,
        target_kl: float = 6.0,
        horizon: int = 10000,
    ):
        self.kl_coef  = init_kl_coef
        self.target   = target_kl
        self.horizon  = horizon
        self._history: deque = deque(maxlen=50)

    def update(self, observed_kl: float) -> float:
        self._history.append(observed_kl)
        error = (observed_kl - self.target) / self.target
        self.kl_coef = float(
            np.clip(self.kl_coef * (1.0 + error / self.horizon), 1e-4, 1.0)
        )
        return self.kl_coef

    @property
    def recent_kl(self) -> float:
        return float(np.mean(self._history)) if self._history else 0.0


# ─────────────────────────────────────────────────────────────────────────────
# PPO Loss (token-level over response tokens)
# ─────────────────────────────────────────────────────────────────────────────

def compute_ppo_loss(
    logits_new: torch.Tensor,       # (B, Q+R, V)
    logits_ref: torch.Tensor,       # (B, Q+R, V)
    full_ids:   torch.Tensor,       # (B, Q+R)
    resp_mask:  torch.Tensor,       # (B, Q+R) — 1 only for response positions
    old_log_probs: torch.Tensor,    # (B,) — sequence-level lp at rollout time
    values_new:    torch.Tensor,    # (B,)
    advantages:    torch.Tensor,    # (B,)
    returns:       torch.Tensor,    # (B,)
    cliprange:       float = 0.2,
    cliprange_value: float = 0.2,
    vf_coef:  float = 0.1,
    ent_coef: float = 0.01,
    kl_coef:  float = 0.05,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """
    Clipped PPO surrogate loss + clipped value loss + entropy + KL penalty.
    All quantities are averaged over response tokens only.
    """
    # Shift: logit[t] predicts token[t+1]
    shift_logits = logits_new[:, :-1, :].contiguous()   # (B, T-1, V)
    shift_ids    = full_ids[:, 1:].contiguous()          # (B, T-1)
    # Shift response mask: resp_mask[:,1:] gives 1 for response token positions
    # in the shifted view (logit[t] predicts resp token[t+1])
    shift_resp   = resp_mask[:, 1:].contiguous().float() # (B, T-1)

    # Token log probs under new policy
    lp_new_all = F.log_softmax(shift_logits, dim=-1)            # (B, T-1, V)
    tok_lp_new = lp_new_all.gather(2, shift_ids.unsqueeze(-1)).squeeze(-1)  # (B, T-1)

    # Sequence-level log prob (mean over response tokens)
    n_resp = shift_resp.sum(dim=1).clamp(min=1)                 # (B,)
    seq_lp_new = (tok_lp_new * shift_resp).sum(dim=1) / n_resp  # (B,)

    # Reference log probs (no grad)
    with torch.no_grad():
        shift_ref   = logits_ref[:, :-1, :].contiguous()
        lp_ref_all  = F.log_softmax(shift_ref, dim=-1)
        tok_lp_ref  = lp_ref_all.gather(2, shift_ids.unsqueeze(-1)).squeeze(-1)
        seq_lp_ref  = (tok_lp_ref * shift_resp).sum(dim=1) / n_resp

    # KL divergence (approx per-sequence)
    kl_per_seq = seq_lp_new - seq_lp_ref

    # Policy loss (clipped surrogate)
    ratio   = torch.exp(seq_lp_new - old_log_probs.detach())   # (B,)
    pg_l1   = -advantages * ratio
    pg_l2   = -advantages * ratio.clamp(1.0 - cliprange, 1.0 + cliprange)
    pg_loss = torch.max(pg_l1, pg_l2).mean()

    # Value loss (clipped)
    old_values = returns - advantages
    vf_l1      = (values_new - returns) ** 2
    v_clipped  = old_values + (values_new - old_values).clamp(-cliprange_value, cliprange_value)
    vf_l2      = (v_clipped - returns) ** 2
    vf_loss    = 0.5 * torch.max(vf_l1, vf_l2).mean()

    # Entropy bonus (over response tokens)
    probs_new = F.softmax(shift_logits, dim=-1)                 # (B, T-1, V)
    entropy   = -(probs_new * lp_new_all).sum(-1)               # (B, T-1)
    ent_loss  = (entropy * shift_resp).sum(1).div(n_resp).mean()

    # KL penalty
    kl_loss = kl_per_seq.mean()

    total = pg_loss + vf_coef * vf_loss - ent_coef * ent_loss + kl_coef * kl_loss

    stats = {
        "loss/total":     total.item(),
        "loss/policy":    pg_loss.item(),
        "loss/value":     vf_loss.item(),
        "loss/entropy":   ent_loss.item(),
        "loss/kl":        kl_loss.item(),
        "ratio/mean":     ratio.mean().item(),
        "ratio/clip_frac": ((ratio - 1.0).abs() > cliprange).float().mean().item(),
    }
    return total, stats


# ─────────────────────────────────────────────────────────────────────────────
# PPO Trainer
# ─────────────────────────────────────────────────────────────────────────────

class RLVERPPOTrainer:
    """
    Custom PPO trainer for RLVER. Does NOT depend on TRL's PPOTrainer.

    Usage (from rlver_rl_train.py):
        trainer = RLVERPPOTrainer(actor_critic, ref_model, tokenizer, ...)
        trainer.train(train_dataloader, eval_samples)
    """

    def __init__(
        self,
        actor_critic: ActorCriticModel,
        ref_model: nn.Module,
        tokenizer: AutoTokenizer,
        reward_cfg: RewardConfig,
        thinking_enabled: bool = True,
        learning_rate: float = 1e-5,
        batch_size: int = 8,
        mini_batch_size: int = 4,
        gradient_accumulation_steps: int = 4,
        num_ppo_epochs: int = 4,
        cliprange: float = 0.2,
        cliprange_value: float = 0.2,
        vf_coef: float = 0.1,
        ent_coef: float = 0.01,
        max_grad_norm: float = 1.0,
        gamma: float = 0.99,
        lam: float = 0.95,
        init_kl_coef: float = 0.05,
        target_kl: float = 6.0,
        max_new_tokens: int = 256,
        temperature: float = 0.9,
        top_p: float = 0.95,
        max_steps: int = 10000,
        save_steps: int = 500,
        eval_steps: int = 250,
        logging_steps: int = 10,
        warmup_steps: int = 100,
        output_dir: str = "",
        device: str = "cuda",
        wandb_enabled: bool = False,
    ):
        self.actor_critic     = actor_critic
        self.ref_model        = ref_model
        self.tokenizer        = tokenizer
        self.thinking_enabled = thinking_enabled
        self.device           = device
        self.reward_cfg       = reward_cfg
        self.batch_size       = batch_size
        self.mini_batch_size  = mini_batch_size
        self.gradient_accumulation_steps = gradient_accumulation_steps
        self.num_ppo_epochs   = num_ppo_epochs
        self.cliprange        = cliprange
        self.cliprange_value  = cliprange_value
        self.vf_coef          = vf_coef
        self.ent_coef         = ent_coef
        self.max_grad_norm    = max_grad_norm
        self.gamma            = gamma
        self.lam              = lam
        self.max_new_tokens   = max_new_tokens
        self.temperature      = temperature
        self.top_p            = top_p
        self.max_steps        = max_steps
        self.save_steps       = save_steps
        self.eval_steps       = eval_steps
        self.logging_steps    = logging_steps
        self.output_dir       = output_dir
        self.wandb_enabled    = wandb_enabled

        # Freeze reference
        for p in self.ref_model.parameters():
            p.requires_grad_(False)
        self.ref_model.eval()

        # KL controller
        self.kl_ctrl = KLController(init_kl_coef=init_kl_coef, target_kl=target_kl)

        # Rollout buffer
        self.buffer = RolloutBuffer(capacity=batch_size * 8)

        # Optimizer (only LoRA + value head params)
        trainable = [p for p in actor_critic.parameters() if p.requires_grad]
        self.optimizer = torch.optim.AdamW(
            trainable, lr=learning_rate, weight_decay=0.01
        )
        self.scheduler = get_cosine_schedule_with_warmup(
            self.optimizer,
            num_warmup_steps=warmup_steps,
            num_training_steps=max_steps,
        )

        self.global_step = 0
        self.best_acc    = 0.0
        self._accum_counter = 0   # tracks gradient accumulation steps
        self._log_history: List[Dict] = []

        os.makedirs(output_dir, exist_ok=True)

    # ── Rollout collection ────────────────────────────────────────────────────

    @torch.no_grad()
    def collect_rollouts(
        self,
        prompts:     List[str],
        true_labels: List[int],
        problems:    List[str],
        problem_ids: Optional[List[str]] = None,
    ) -> None:
        """
        Generate one response per prompt, score with reward_fn,
        estimate value, and store in rollout buffer.
        """
        self.actor_critic.eval()

        if problem_ids is None:
            problem_ids = [f"prob_{i}" for i in range(len(prompts))]

        for prompt, label, problem, pid in zip(prompts, true_labels, problems, problem_ids):

            # Tokenize prompt
            enc = self.tokenizer(
                prompt,
                return_tensors="pt",
                truncation=True,
                max_length=512,
            ).to(self.device)
            query_ids  = enc["input_ids"]       # (1, Q)
            query_mask = enc["attention_mask"]
            Q = query_ids.shape[-1]

            # Generate response (response_ids only, without prompt)
            full_out = self.actor_critic.generate(
                input_ids=query_ids,
                attention_mask=query_mask,
                max_new_tokens=self.max_new_tokens,
                temperature=self.temperature,
                top_p=self.top_p,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )  # (1, Q+R)
            resp_ids = full_out[:, Q:]           # (1, R) — response only
            R = resp_ids.shape[-1]

            response_text = self.tokenizer.decode(resp_ids[0], skip_special_tokens=True)

            # Compute reward
            rewards, components = compute_rewards_batch(
                raw_outputs=[response_text],
                true_labels=[label],
                problems=[problem],
                cfg=self.reward_cfg,
                thinking_enabled=self.thinking_enabled,
            )
            reward  = rewards[0]
            correct = bool(components[0].get("correct", 0))

            # Build full sequence for value estimate
            full_ids  = full_out                                 # (1, Q+R)
            full_mask = torch.ones_like(full_ids)

            out = self.actor_critic(
                input_ids=full_ids,
                attention_mask=full_mask,
                return_value=True,
            )
            value = out["values"].item()

            # Compute sequence log prob over response tokens (old policy)
            # In shifted view: logit[t] → token[t+1], so response starts at Q-1
            logits     = out["logits"]                           # (1, Q+R, V)
            shift_log  = F.log_softmax(logits[:, :-1, :], dim=-1)  # (1, Q+R-1, V)
            shift_ids  = full_ids[:, 1:]                           # (1, Q+R-1)
            tok_lp     = shift_log.gather(2, shift_ids.unsqueeze(-1)).squeeze(-1)  # (1, Q+R-1)
            # Response positions in shifted view: index Q-1 onwards
            resp_shifted = tok_lp[:, Q - 1:]                    # (1, R)
            log_prob = resp_shifted.mean().item() if R > 0 else 0.0

            self.buffer.add(RolloutSample(
                query_ids    = query_ids.squeeze(0).cpu(),    # (Q,)
                response_ids = resp_ids.squeeze(0).cpu(),     # (R,) — response only
                reward       = reward,
                value        = value,
                log_prob     = log_prob,
                problem_id   = pid,
                true_label   = label,
                correct      = correct,
            ))

        self.actor_critic.train()

    # ── PPO update ────────────────────────────────────────────────────────────

    def ppo_update(self) -> Dict[str, float]:
        """
        Compute GAE, then run num_ppo_epochs × mini-batch gradient steps.
        Returns averaged stats over all mini-batch updates.
        """
        self.buffer.compute_gae(gamma=self.gamma, lam=self.lam, normalize=True)

        all_stats = []
        for _ in range(self.num_ppo_epochs):
            for mini_batch in self.buffer.get_batches(self.mini_batch_size):
                stats = self._ppo_mini_step(mini_batch)
                all_stats.append(stats)

        return {k: float(np.mean([s[k] for s in all_stats])) for k in all_stats[0]}

    def _ppo_mini_step(self, batch: List[RolloutSample]) -> Dict[str, float]:
        """
        Single mini-batch PPO gradient step.
        Builds full (query + response) tensors for each sample, padded to same length.
        """
        pad_id = self.tokenizer.pad_token_id or self.tokenizer.eos_token_id

        full_ids_list   = []
        resp_mask_list  = []

        for s in batch:
            Q  = s.query_ids.shape[0]
            R  = s.response_ids.shape[0]
            # Full sequence
            full = torch.cat([s.query_ids, s.response_ids], dim=0)  # (Q+R,)
            # Response mask: 0 for prompt, 1 for response
            rmask = torch.zeros(Q + R, dtype=torch.long)
            rmask[Q:] = 1
            full_ids_list.append(full)
            resp_mask_list.append(rmask)

        # Pad to same length
        max_len = max(t.shape[0] for t in full_ids_list)
        full_ids  = torch.zeros(len(batch), max_len, dtype=torch.long)
        resp_mask = torch.zeros(len(batch), max_len, dtype=torch.long)

        for i, (fid, rm) in enumerate(zip(full_ids_list, resp_mask_list)):
            L = fid.shape[0]
            full_ids[i, :L]  = fid
            full_ids[i, L:]  = pad_id
            resp_mask[i, :L] = rm
            # Padding positions stay 0 in resp_mask (correct)

        full_ids  = full_ids.to(self.device)
        resp_mask = resp_mask.to(self.device)
        attn_mask = (full_ids != pad_id).long()

        advantages = torch.tensor(
            [s.advantage for s in batch], dtype=torch.float32, device=self.device
        )
        returns = torch.tensor(
            [s.returns for s in batch], dtype=torch.float32, device=self.device
        )
        old_lp = torch.tensor(
            [s.log_prob for s in batch], dtype=torch.float32, device=self.device
        )

        # New policy forward
        out_new     = self.actor_critic(full_ids, attn_mask, return_value=True)
        logits_new  = out_new["logits"]
        values_new  = out_new["values"]

        # Reference policy forward (no grad)
        with torch.no_grad():
            out_ref    = self.ref_model(
                input_ids=full_ids,
                attention_mask=attn_mask,
                return_dict=True,
            )
            logits_ref = out_ref.logits

        loss, stats = compute_ppo_loss(
            logits_new   = logits_new,
            logits_ref   = logits_ref,
            full_ids     = full_ids,
            resp_mask    = resp_mask,
            old_log_probs = old_lp,
            values_new   = values_new,
            advantages   = advantages,
            returns      = returns,
            cliprange    = self.cliprange,
            cliprange_value = self.cliprange_value,
            vf_coef      = self.vf_coef,
            ent_coef     = self.ent_coef,
            kl_coef      = self.kl_ctrl.kl_coef,
        )

        # Gradient accumulation
        scaled_loss = loss / self.gradient_accumulation_steps
        scaled_loss.backward()
        self._accum_counter += 1

        if self._accum_counter % self.gradient_accumulation_steps == 0:
            torch.nn.utils.clip_grad_norm_(
                self.actor_critic.parameters(), self.max_grad_norm
            )
            self.optimizer.step()
            self.scheduler.step()
            self.optimizer.zero_grad()

        # Update KL controller
        self.kl_ctrl.update(stats["loss/kl"])

        return stats

    # ── Main training loop ────────────────────────────────────────────────────

    def train(
        self,
        train_dataloader: DataLoader,
        eval_samples: Optional[List] = None,
    ) -> None:
        """
        PPO outer training loop.

        Args:
            train_dataloader: yields dict batches with keys:
                              prompt (list[str]), label (Tensor|list),
                              problem (list[str]), problem_id (list[str])
            eval_samples: List[RLVERSample] for periodic accuracy eval
        """
        logger.info(f"Starting PPO training: max_steps={self.max_steps}")
        self.actor_critic.train()
        self.optimizer.zero_grad()

        train_iter  = iter(train_dataloader)
        step        = 0

        while step < self.max_steps:
            # Refill iterator
            try:
                batch = next(train_iter)
            except StopIteration:
                train_iter = iter(train_dataloader)
                batch      = next(train_iter)

            prompts     = batch["prompt"]
            labels      = batch["label"]
            problems    = batch.get("problem", [""] * len(prompts))
            problem_ids = batch.get("problem_id", [f"p{i}" for i in range(len(prompts))])

            if hasattr(labels, "tolist"):
                labels = labels.tolist()

            # Collect rollouts for this batch
            self.collect_rollouts(
                prompts=prompts,
                true_labels=labels,
                problems=problems,
                problem_ids=problem_ids,
            )

            # Update only when buffer has enough samples
            if len(self.buffer) < self.batch_size:
                continue

            # PPO update
            stats = self.ppo_update()
            self.buffer.clear()
            self.global_step += 1
            step += 1

            # Logging
            if step % self.logging_steps == 0:
                logger.info(
                    f"[PPO {step}/{self.max_steps}]  "
                    f"loss={stats['loss/total']:.4f}  "
                    f"pg={stats['loss/policy']:.4f}  "
                    f"vf={stats['loss/value']:.4f}  "
                    f"kl={stats['loss/kl']:.4f}  "
                    f"kl_coef={self.kl_ctrl.kl_coef:.4f}  "
                    f"clip={stats['ratio/clip_frac']:.3f}"
                )
                if self.wandb_enabled:
                    try:
                        import wandb
                        wandb.log({"step": step, **stats})
                    except Exception:
                        pass
                self._log_history.append({"step": step, **stats})

            # Checkpoint
            if step % self.save_steps == 0:
                self.save_checkpoint(f"checkpoint-{step}")

            # Eval
            if eval_samples and step % self.eval_steps == 0:
                acc = self._quick_eval(eval_samples[:150])
                logger.info(f"[Eval {step}]  verification_accuracy={acc:.4f}")
                if acc > self.best_acc:
                    self.best_acc = acc
                    self.save_checkpoint("best_model")
                    logger.info(f"  ↑ New best  acc={acc:.4f}")

        # Final
        self.save_checkpoint("final_model")
        with open(os.path.join(self.output_dir, "training_log.json"), "w") as f:
            json.dump(self._log_history, f, indent=2)
        logger.info("PPO training complete.")

    # ── Quick eval ────────────────────────────────────────────────────────────

    @torch.no_grad()
    def _quick_eval(self, eval_samples: List) -> float:
        from dataset_builder import format_verification_prompt
        self.actor_critic.eval()
        correct = 0

        for s in eval_samples:
            prompt = format_verification_prompt(s, thinking_enabled=self.thinking_enabled)
            enc    = self.tokenizer(
                prompt, return_tensors="pt", truncation=True, max_length=512
            ).to(self.device)
            out = self.actor_critic.generate(
                input_ids=enc["input_ids"],
                attention_mask=enc["attention_mask"],
                max_new_tokens=128,
                do_sample=False,                     # greedy for eval
                pad_token_id=self.tokenizer.eos_token_id,
            )
            text = self.tokenizer.decode(
                out[0][enc["input_ids"].shape[-1]:], skip_special_tokens=True
            )
            _, comps = compute_rewards_batch(
                [text], [s.label], [s.problem], cfg=self.reward_cfg
            )
            correct += comps[0].get("correct", 0)

        self.actor_critic.train()
        return correct / max(len(eval_samples), 1)

    # ── Save / Load ───────────────────────────────────────────────────────────

    def save_checkpoint(self, name: str) -> None:
        path = os.path.join(self.output_dir, name)
        os.makedirs(path, exist_ok=True)
        # Save LoRA adapter (and merged weights if full model)
        self.actor_critic.base_model.save_pretrained(path)
        self.tokenizer.save_pretrained(path)
        # Save value head
        torch.save(
            self.actor_critic.value_head.state_dict(),
            os.path.join(path, "value_head.pt"),
        )
        # Save optimizer / scheduler state
        torch.save(
            {
                "optimizer":   self.optimizer.state_dict(),
                "scheduler":   self.scheduler.state_dict(),
                "global_step": self.global_step,
                "best_acc":    self.best_acc,
                "kl_coef":     self.kl_ctrl.kl_coef,
            },
            os.path.join(path, "trainer_state.pt"),
        )
        logger.info(f"Checkpoint saved → {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Smoke-test (no GPU needed — pure tensor operations)
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import random as _rng
    logging.basicConfig(level=logging.INFO)

    B, Q, R, V = 2, 10, 16, 8192
    full_len = Q + R

    logits_new = torch.randn(B, full_len, V)
    logits_ref = torch.randn(B, full_len, V)
    full_ids   = torch.randint(0, V, (B, full_len))
    resp_mask  = torch.zeros(B, full_len, dtype=torch.long)
    resp_mask[:, Q:] = 1                        # response positions
    old_lp     = torch.randn(B) * 0.1
    values     = torch.randn(B)
    advantages = torch.randn(B)
    returns    = advantages + values

    loss, stats = compute_ppo_loss(
        logits_new, logits_ref, full_ids, resp_mask,
        old_lp, values, advantages, returns,
    )
    print(f"\n[PPO loss smoke-test]  loss={loss.item():.4f}")
    for k, v in stats.items():
        print(f"  {k:<28}: {v:.4f}")

    # KL controller
    kl = KLController(init_kl_coef=0.05, target_kl=6.0)
    print("\n[KL controller]")
    for obs in [2.0, 5.0, 8.0, 12.0, 6.1, 5.9]:
        c = kl.update(obs)
        print(f"  KL={obs:.1f}  → β={c:.6f}")

    # Rollout buffer
    buf = RolloutBuffer(capacity=16)
    for i in range(8):
        buf.add(RolloutSample(
            query_ids=torch.randint(0, 100, (10,)),
            response_ids=torch.randint(0, 100, (16,)),
            reward=_rng.uniform(-1, 1),
            value=_rng.uniform(-0.5, 0.5),
            log_prob=_rng.uniform(-2, 0),
        ))
    buf.compute_gae(gamma=0.99, lam=0.95)
    print(f"\n[RolloutBuffer] len={len(buf)}")
    print(f"  advantage[0]={buf._buf[0].advantage:.4f}  returns[0]={buf._buf[0].returns:.4f}")
    print("\n[OK] ppo_trainer_custom.py smoke-test passed.")
