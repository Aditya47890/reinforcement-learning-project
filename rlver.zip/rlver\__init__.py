"""
RLVER Ablation Study Package
==============================
Submodules
----------
ablation_config
    AblationGroup, AblationExperiment, ALL_ABLATION_GROUPS,
    get_experiment_config

ablation_runner
    AblationRunner — runs one ablation experiment end-to-end

ablation_analysis
    AblationAnalysis — loads results, runs statistics, generates plots/tables
"""

from .ablation_config import (
    AblationExperiment,
    AblationGroup,
    ALL_ABLATION_GROUPS,
    get_experiment_config,
    ABLATION_STEPS,
    ABLATION_EVAL_SAMPLES,
)

from .ablation_runner import AblationRunner

from .ablation_analysis import AblationAnalysis

__version__ = "1.0.0"
__author__  = "Dushyant (u23ai085)"
__all__ = [
    "AblationExperiment", "AblationGroup", "ALL_ABLATION_GROUPS",
    "get_experiment_config", "ABLATION_STEPS", "ABLATION_EVAL_SAMPLES",
    "AblationRunner", "AblationAnalysis",
]
