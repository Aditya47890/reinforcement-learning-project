#!/bin/bash
# =============================================================================
# RLVER PROJECT — MASTER SETUP SCRIPT  (v2 — HPC / Blackwell verified)
# =============================================================================
# Author  : Dushyant (u23ai085) | 9256777500
# Machine : NVIDIA RTX PRO 4500 Blackwell  |  33.7 GB VRAM  |  Ubuntu 24
# Run as  : bash 00_setup.sh
#
# What this script does (in order):
#   1.  Wipe old project folder and recreate directory structure
#   2.  Hardware audit (GPU, VRAM, CUDA, disk space)
#   3.  Verify / install Miniconda
#   4.  Create conda environment  (Python 3.11)
#   5.  Install PyTorch 2.6.0 for CUDA 12.4 (Blackwell sm_100 compatible)
#   6.  Install all ML packages with pinned compatible versions
#   7.  Verify every package imports correctly
#   8.  Download HuggingFace models with retry + checksum logic
#   9.  Write environment.yml + requirements.txt snapshots
#  10.  Print next-steps summary
#
# On re-run: existing conda env is removed and recreated from scratch.
# =============================================================================

set -euo pipefail          # exit on error, undefined var, pipe failure
IFS=$'\n\t'

# ── Colours ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
BLU='\033[0;34m'; NC='\033[0m'; BOLD='\033[1m'

info()  { echo -e "${BLU}[INFO]${NC}  $*"; }
ok()    { echo -e "${GRN}[ OK ]${NC}  $*"; }
warn()  { echo -e "${YLW}[WARN]${NC}  $*"; }
die()   { echo -e "${RED}[FAIL]${NC}  $*" >&2; exit 1; }
hdr()   { echo -e "\n${BOLD}${BLU}══════════════════════════════════════════${NC}"; \
           echo -e "${BOLD}${BLU}  $*${NC}"; \
           echo -e "${BOLD}${BLU}══════════════════════════════════════════${NC}"; }

# ── Configuration ─────────────────────────────────────────────────────────────
PROJECT_DIR="$HOME/Dushyant_u23ai085_9256777500"
ENV_NAME="rlver_env"
PYTHON_VER="3.11"

# Package versions — tested compatible set for Python 3.11 + CUDA 12.4
# All versions verified to exist on PyPI / PyTorch index as of 2025-04
TORCH_VER="2.6.0"
TORCH_CUDA_TAG="cu124"          # CUDA 12.4 → Blackwell sm_100 support
TORCH_INDEX="https://download.pytorch.org/whl/cu124"

TRANSFORMERS_VER="4.47.1"       # last stable with Qwen2.5 full support
ACCELERATE_VER="1.2.1"          # compatible with transformers 4.47.x
PEFT_VER="0.14.0"               # compatible with transformers 4.47.x
TRL_VER="0.13.0"                # stable; RLVER uses custom trainers (not TRL API)
BITSANDBYTES_VER="0.45.0"       # CUDA 12.4 compatible wheel available
DATASETS_VER="3.2.0"            # stable; supports streaming + caching
TOKENIZERS_VER="0.21.0"         # matches transformers 4.47.x
HF_HUB_VER="0.27.1"            # stable upload/download API

NUMPY_VER="1.26.4"              # last version before numpy 2.0 API break
PANDAS_VER="2.2.3"
SCIPY_VER="1.13.1"
SKLEARN_VER="1.5.2"
MATPLOTLIB_VER="3.9.3"
SEABORN_VER="0.13.2"
SENTENCEPIECE_VER="0.2.0"
PROTOBUF_VER="5.29.3"
TQDM_VER="4.67.1"
WANDB_VER="0.19.11"
JSONLINES_VER="4.0.0"
RICH_VER="13.9.4"
TYPER_VER="0.15.1"
PSUTIL_VER="6.1.1"
PYYAML_VER="6.0.2"

# Models to download
declare -A MODELS=(
    ["Qwen/Qwen2.5-1.5B-Instruct"]="qwen_1p5b"
    ["Qwen/Qwen2.5-7B-Instruct"]="qwen_7b"
    ["mistralai/Mistral-7B-Instruct-v0.3"]="mistral_7b_sim"
)
MODELS_DIR="$PROJECT_DIR/models"

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 1 — Directory structure"
# ─────────────────────────────────────────────────────────────────────────────

# Back up previous run logs if they exist
if [ -d "$PROJECT_DIR/logs" ]; then
    BACKUP="$HOME/.rlver_backup_$(date +%Y%m%d_%H%M%S)"
    info "Backing up logs → $BACKUP"
    cp -r "$PROJECT_DIR/logs" "$BACKUP" 2>/dev/null || true
fi

# Remove old project directory entirely
if [ -d "$PROJECT_DIR" ]; then
    warn "Removing existing project directory: $PROJECT_DIR"
    rm -rf "$PROJECT_DIR"
fi

# Re-create full directory tree
info "Creating directory tree..."
mkdir -p "$PROJECT_DIR"/{configs,scripts,models,logs,logs/ablation,cache/hf,cache/datasets,results,results/ablation,results/ablation/plots,rl_training,rlver_adversarial,ablation}
ok "Created: $PROJECT_DIR"

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 2 — Hardware audit"
# ─────────────────────────────────────────────────────────────────────────────

python3 - << 'PYEOF'
import subprocess, sys, os

def run(cmd, default="N/A"):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return default

print("")
print("  ┌─ System ─────────────────────────────────────────────────────┐")
cpu   = run("lscpu | grep 'Model name' | head -1 | awk -F: '{print $2}'").strip()
cores = run("nproc")
ram   = run("free -h | awk '/Mem:/{print $2}'")
disk  = run(f"df -h {os.path.expanduser('~')} | awk 'NR==2{{print $2\" total / \"$4\" free}}'")
print(f"  │  CPU  : {cpu}")
print(f"  │  Cores: {cores}")
print(f"  │  RAM  : {ram}")
print(f"  │  Disk : {disk}")

print("  ├─ GPU ────────────────────────────────────────────────────────┤")
try:
    name  = run("nvidia-smi --query-gpu=name --format=csv,noheader")
    vram  = run("nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits")
    driver= run("nvidia-smi --query-gpu=driver_version --format=csv,noheader")
    cuda_v= run("nvcc --version | grep release | awk '{print $6}' | tr -d ','")
    util  = run("nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader")
    vram_gb = float(vram) / 1024
    print(f"  │  GPU    : {name}")
    print(f"  │  VRAM   : {vram_gb:.1f} GB  ({vram} MiB)")
    print(f"  │  Driver : {driver}")
    print(f"  │  CUDA   : {cuda_v}")
    print(f"  │  Util   : {util}")
    if vram_gb < 20:
        print(f"  │  ⚠ WARNING: <20 GB VRAM — reduce batch sizes in configs")
    else:
        print(f"  │  ✓ VRAM sufficient for Qwen-7B + LoRA")
except Exception as e:
    print(f"  │  GPU: NOT DETECTED ({e})")
    print(f"  │  ⚠ CUDA training will not work — check nvidia-smi")

print("  └──────────────────────────────────────────────────────────────┘")
print("")

# Disk space check (need ~80 GB for models + cache)
try:
    free_gb = float(run("df --output=avail -BG $HOME | tail -1").replace('G',''))
    if free_gb < 50:
        print(f"  ⚠ WARNING: Only {free_gb:.0f} GB free — models need ~30 GB, datasets ~5 GB")
        print(f"    Run: du -sh ~/Dushyant_u23ai085_9256777500 to check usage")
    else:
        print(f"  ✓ Disk: {free_gb:.0f} GB free (sufficient)")
except:
    pass
PYEOF

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 3 — Conda setup"
# ─────────────────────────────────────────────────────────────────────────────

# Check for conda; try multiple locations used by HPC systems
CONDA_CMD=""
for conda_path in \
    "conda" \
    "$HOME/miniconda3/bin/conda" \
    "$HOME/anaconda3/bin/conda" \
    "/opt/conda/bin/conda" \
    "/usr/local/anaconda3/bin/conda" \
    "$HOME/miniconda/bin/conda"; do
    if command -v "$conda_path" &>/dev/null 2>&1; then
        CONDA_CMD="$conda_path"
        ok "Found conda: $CONDA_CMD  ($(${CONDA_CMD} --version))"
        break
    fi
done

if [ -z "$CONDA_CMD" ]; then
    warn "conda not found — installing Miniconda..."
    MINI_INSTALLER="$HOME/miniconda_install.sh"
    MINI_URL="https://repo.anaconda.com/miniconda/Miniconda3-py311_24.11.1-0-Linux-x86_64.sh"

    info "Downloading Miniconda → $MINI_INSTALLER"
    if command -v wget &>/dev/null; then
        wget -q --show-progress "$MINI_URL" -O "$MINI_INSTALLER" || \
            die "wget failed. Check internet connection or manually install Miniconda from:\n  $MINI_URL"
    elif command -v curl &>/dev/null; then
        curl -fL --progress-bar "$MINI_URL" -o "$MINI_INSTALLER" || \
            die "curl failed. Check internet connection or manually install Miniconda."
    else
        die "Neither wget nor curl found. Install one: sudo apt-get install wget"
    fi

    info "Installing Miniconda silently..."
    bash "$MINI_INSTALLER" -b -p "$HOME/miniconda3" -u
    rm -f "$MINI_INSTALLER"
    CONDA_CMD="$HOME/miniconda3/bin/conda"

    # Init for bash
    "$CONDA_CMD" init bash
    ok "Miniconda installed at $HOME/miniconda3"
    warn "NOTE: You may need to run 'source ~/.bashrc' after this script."
fi

# Source conda
CONDA_BASE=$("$CONDA_CMD" info --base)
# shellcheck disable=SC1091
source "$CONDA_BASE/etc/profile.d/conda.sh"

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 4 — Create conda environment: $ENV_NAME"
# ─────────────────────────────────────────────────────────────────────────────

# Remove existing env if present
if conda env list | grep -q "^${ENV_NAME}\s"; then
    info "Removing existing environment: $ENV_NAME"
    conda env remove -n "$ENV_NAME" -y
fi

info "Creating fresh environment: $ENV_NAME  (Python $PYTHON_VER)"
conda create -n "$ENV_NAME" python="$PYTHON_VER" pip setuptools wheel -y
ok "Environment created"

info "Activating: $ENV_NAME"
conda activate "$ENV_NAME"

# Verify we're in the right env
ACTIVE_PYTHON=$(python --version 2>&1)
info "Active Python: $ACTIVE_PYTHON"
[[ "$ACTIVE_PYTHON" == *"3.11"* ]] || warn "Python version mismatch — expected 3.11"

# Upgrade pip first
info "Upgrading pip..."
pip install --quiet --upgrade pip

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 5 — Install PyTorch $TORCH_VER + CUDA $TORCH_CUDA_TAG"
# ─────────────────────────────────────────────────────────────────────────────
# PyTorch 2.6.0 with CUDA 12.4 is confirmed to support:
#   - Ada Lovelace (sm_89): RTX 4090, 4080, etc.
#   - Hopper      (sm_90): H100
#   - Blackwell   (sm_100): RTX PRO 4500, RTX 5090, etc.
# Source: https://pytorch.org/get-started/locally/

info "Installing PyTorch $TORCH_VER (CUDA $TORCH_CUDA_TAG) — this may take 5-10 minutes..."
pip install \
    "torch==${TORCH_VER}" \
    "torchvision" \
    "torchaudio" \
    --index-url "$TORCH_INDEX" \
    --timeout 300 \
    || die "PyTorch installation failed. Try manually:\n  pip install torch==${TORCH_VER} --index-url ${TORCH_INDEX}"

# Verify CUDA is accessible
python - << 'PYEOF'
import torch, sys
print(f"  PyTorch version : {torch.__version__}")
print(f"  CUDA available  : {torch.cuda.is_available()}")
if torch.cuda.is_available():
    props = torch.cuda.get_device_properties(0)
    print(f"  GPU name        : {props.name}")
    print(f"  VRAM            : {props.total_memory / 1e9:.1f} GB")
    print(f"  Compute cap.    : sm_{props.major}{props.minor}")
    # Blackwell = sm_100, Ada = sm_89, Hopper = sm_90
    cc = props.major * 10 + props.minor
    if cc >= 89:
        print(f"  ✓ GPU compute capability OK for LoRA fine-tuning")
    else:
        print(f"  ⚠ Old GPU — may encounter issues with bfloat16")
else:
    print("  ⚠ CUDA not available — set CUDA_VISIBLE_DEVICES if on HPC")
PYEOF
ok "PyTorch installed"

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 6 — Install ML packages (pinned, compatibility-verified)"
# ─────────────────────────────────────────────────────────────────────────────

info "Installing HuggingFace ecosystem..."
pip install \
    "transformers==${TRANSFORMERS_VER}" \
    "accelerate==${ACCELERATE_VER}" \
    "peft==${PEFT_VER}" \
    "trl==${TRL_VER}" \
    "datasets==${DATASETS_VER}" \
    "tokenizers==${TOKENIZERS_VER}" \
    "huggingface-hub==${HF_HUB_VER}" \
    "sentencepiece==${SENTENCEPIECE_VER}" \
    "protobuf==${PROTOBUF_VER}" \
    --timeout 300 \
    || die "HuggingFace ecosystem install failed"
ok "HuggingFace ecosystem installed"

info "Installing bitsandbytes (quantization)..."
# bitsandbytes needs special handling for CUDA 12.4 on some HPC systems
pip install "bitsandbytes==${BITSANDBYTES_VER}" --timeout 300 \
    || { warn "bitsandbytes standard install failed — trying pre-built wheel..."; \
         pip install bitsandbytes --prefer-binary --timeout 300 \
         || warn "bitsandbytes unavailable — quantization disabled (not needed for LoRA-only runs)"; }

info "Installing analysis packages..."
pip install \
    "numpy==${NUMPY_VER}" \
    "pandas==${PANDAS_VER}" \
    "scipy==${SCIPY_VER}" \
    "scikit-learn==${SKLEARN_VER}" \
    "matplotlib==${MATPLOTLIB_VER}" \
    "seaborn==${SEABORN_VER}" \
    --timeout 300 \
    || die "Analysis packages install failed"
ok "Analysis packages installed"

info "Installing utility packages..."
pip install \
    "tqdm==${TQDM_VER}" \
    "wandb==${WANDB_VER}" \
    "jsonlines==${JSONLINES_VER}" \
    "rich==${RICH_VER}" \
    "typer==${TYPER_VER}" \
    "psutil==${PSUTIL_VER}" \
    "pyyaml==${PYYAML_VER}" \
    "einops" \
    "safetensors>=0.4.3" \
    "tiktoken>=0.7.0" \
    --timeout 300 \
    || die "Utility packages install failed"
ok "Utility packages installed"

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 7 — Verify all imports"
# ─────────────────────────────────────────────────────────────────────────────

python - << 'PYEOF'
import sys, importlib

PACKAGES = [
    # (import_name,          display_name,          critical)
    ("torch",                "PyTorch",              True),
    ("transformers",         "Transformers",         True),
    ("accelerate",           "Accelerate",           True),
    ("peft",                 "PEFT",                 True),
    ("trl",                  "TRL",                  True),
    ("datasets",             "Datasets",             True),
    ("tokenizers",           "Tokenizers",           True),
    ("huggingface_hub",      "HuggingFace Hub",      True),
    ("sentencepiece",        "SentencePiece",        False),
    ("bitsandbytes",         "BitsAndBytes",         False),
    ("numpy",                "NumPy",                True),
    ("pandas",               "Pandas",               True),
    ("scipy",                "SciPy",                True),
    ("sklearn",              "scikit-learn",         True),
    ("matplotlib",           "Matplotlib",           True),
    ("seaborn",              "Seaborn",              False),
    ("tqdm",                 "tqdm",                 True),
    ("wandb",                "WandB",                False),
    ("jsonlines",            "jsonlines",            True),
    ("rich",                 "rich",                 False),
    ("yaml",                 "PyYAML",               True),
    ("psutil",               "psutil",               False),
    ("safetensors",          "safetensors",          True),
]

failed_critical = []
print("")
for mod, name, critical in PACKAGES:
    try:
        m = importlib.import_module(mod)
        ver = getattr(m, "__version__", "?")
        print(f"  ✓  {name:<22} v{ver}")
    except ImportError as e:
        marker = "✗ CRITICAL" if critical else "⚠ optional "
        print(f"  {marker}  {name:<22} NOT FOUND: {e}")
        if critical:
            failed_critical.append(name)

print("")
if failed_critical:
    print(f"  CRITICAL FAILURES: {failed_critical}")
    print(f"  Run:  conda activate rlver_env && pip install <package>")
    sys.exit(1)
else:
    print("  All critical packages verified ✓")
PYEOF
ok "All imports verified"

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 8 — Download HuggingFace models"
# ─────────────────────────────────────────────────────────────────────────────
# Download strategy:
#   - Uses huggingface_hub.snapshot_download with retry logic
#   - Ignores large non-essential files (.msgpack, .h5, optimizer states)
#   - Checks if already downloaded (skip if complete)
#   - Sets HF_HOME to project cache dir so re-runs are instant

export HF_HOME="$PROJECT_DIR/cache/hf"
export TRANSFORMERS_CACHE="$PROJECT_DIR/cache/hf"
export HF_HUB_CACHE="$PROJECT_DIR/cache/hf"

python - << 'PYEOF'
import os, sys, time
from pathlib import Path

PROJECT_DIR = os.path.expanduser("~/Dushyant_u23ai085_9256777500")
MODELS_DIR  = os.path.join(PROJECT_DIR, "models")
os.makedirs(MODELS_DIR, exist_ok=True)

try:
    from huggingface_hub import snapshot_download, HfApi
    from huggingface_hub.utils import RepositoryNotFoundError, EntryNotFoundError
except ImportError:
    print("  huggingface_hub not available — models must be downloaded manually")
    sys.exit(0)

# Files to exclude (save disk space)
IGNORE_PATTERNS = [
    "*.msgpack", "*.h5", "*.ot",
    "flax_model*", "tf_model*",
    "rust_model*", "optimizer*",
    "*.arrow",
]

MODELS = [
    ("Qwen/Qwen2.5-1.5B-Instruct",         "qwen_1p5b",       "~3.1 GB"),
    ("Qwen/Qwen2.5-7B-Instruct",            "qwen_7b",         "~15 GB"),
    ("mistralai/Mistral-7B-Instruct-v0.3",  "mistral_7b_sim",  "~14 GB"),
]

def is_complete(local_dir):
    """Check if model directory has the essential files."""
    if not os.path.isdir(local_dir):
        return False
    files = list(Path(local_dir).rglob("*.safetensors")) + \
            list(Path(local_dir).rglob("*.bin"))
    has_config = os.path.isfile(os.path.join(local_dir, "config.json"))
    has_tokenizer = (
        os.path.isfile(os.path.join(local_dir, "tokenizer.json")) or
        os.path.isfile(os.path.join(local_dir, "tokenizer.model"))
    )
    return len(files) > 0 and has_config and has_tokenizer

def download_with_retry(hf_id, local_dir, retries=3, wait=30):
    for attempt in range(1, retries + 1):
        try:
            print(f"  Attempt {attempt}/{retries}: {hf_id}")
            snapshot_download(
                repo_id=hf_id,
                local_dir=local_dir,
                ignore_patterns=IGNORE_PATTERNS,
                resume_download=True,  # resumes interrupted downloads
                local_dir_use_symlinks=False,
            )
            return True
        except RepositoryNotFoundError:
            print(f"  ✗ Repo not found: {hf_id}")
            print(f"    Check HF_TOKEN env var if this is a gated model:")
            print(f"    export HF_TOKEN=hf_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
            return False
        except Exception as e:
            print(f"  ⚠ Attempt {attempt} failed: {type(e).__name__}: {e}")
            if attempt < retries:
                print(f"  Waiting {wait}s before retry...")
                time.sleep(wait)
    return False

print("")
all_ok = True
for hf_id, local_name, size in MODELS:
    local_dir = os.path.join(MODELS_DIR, local_name)
    print(f"\n  ── {hf_id}  ({size})")
    print(f"     → {local_dir}")

    if is_complete(local_dir):
        print(f"  ✓ Already downloaded and complete — skipping")
        continue

    success = download_with_retry(hf_id, local_dir, retries=3, wait=30)
    if success and is_complete(local_dir):
        # Count files
        n_files = sum(1 for _ in Path(local_dir).rglob("*") if os.path.isfile(_))
        size_gb  = sum(os.path.getsize(p) for p in Path(local_dir).rglob("*")
                       if os.path.isfile(p)) / 1e9
        print(f"  ✓ Downloaded: {n_files} files  ({size_gb:.1f} GB)")
    else:
        print(f"  ✗ Download incomplete for {hf_id}")
        print(f"    Manual command:")
        print(f"    huggingface-cli download {hf_id} --local-dir {local_dir}")
        all_ok = False

print("")
if all_ok:
    print("  ✓ All models downloaded successfully")
else:
    print("  ⚠ Some models failed — training will use HF hub fallback (requires internet)")
PYEOF

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 9 — Save environment snapshot"
# ─────────────────────────────────────────────────────────────────────────────

info "Exporting environment.yml..."
conda env export -n "$ENV_NAME" > "$PROJECT_DIR/configs/environment.yml"
ok "Saved: $PROJECT_DIR/configs/environment.yml"

info "Exporting pip requirements.txt..."
pip freeze > "$PROJECT_DIR/configs/requirements.txt"
ok "Saved: $PROJECT_DIR/configs/requirements.txt"

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 10 — Copy project files into place"
# ─────────────────────────────────────────────────────────────────────────────
# This assumes the user unpacked the zip next to 00_setup.sh
# The zip should extract to the same directory as 00_setup.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
info "Script directory: $SCRIPT_DIR"

# Copy all project code (everything except 00_setup.sh itself)
rsync_available=false
if command -v rsync &>/dev/null; then
    rsync_available=true
fi

copy_if_exists() {
    local src="$SCRIPT_DIR/$1"
    local dst="$PROJECT_DIR/$1"
    if [ -f "$src" ] || [ -d "$src" ]; then
        dst_dir=$(dirname "$dst")
        mkdir -p "$dst_dir"
        if $rsync_available && [ -d "$src" ]; then
            rsync -a "$src/" "$dst/"
        else
            cp -r "$src" "$dst"
        fi
        ok "Copied: $1"
    else
        warn "Not found (skip): $1"
    fi
}

# Core packages
copy_if_exists "rl_training"
copy_if_exists "rlver_adversarial"
copy_if_exists "ablation"
copy_if_exists "scripts"
copy_if_exists "configs/ppo_config.yaml"
copy_if_exists "configs/grpo_config.yaml"
copy_if_exists "README.md"
copy_if_exists "run_all.sh"
copy_if_exists "reset_and_fresh_start.sh"
copy_if_exists "environment.yml"

# Make scripts executable
chmod +x "$PROJECT_DIR"/scripts/*.sh 2>/dev/null || true
chmod +x "$PROJECT_DIR/run_all.sh"  2>/dev/null || true
chmod +x "$PROJECT_DIR/reset_and_fresh_start.sh" 2>/dev/null || true

# ─────────────────────────────────────────────────────────────────────────────
hdr "STEP 11 — Final verification"
# ─────────────────────────────────────────────────────────────────────────────

python - << 'PYEOF'
import os, sys

PROJECT_DIR = os.path.expanduser("~/Dushyant_u23ai085_9256777500")

required_files = [
    "configs/ppo_config.yaml",
    "configs/grpo_config.yaml",
    "rl_training/__init__.py",
    "rl_training/reward_model.py",
    "rl_training/ppo_trainer_custom.py",
    "rl_training/grpo_trainer_custom.py",
    "rl_training/rlver_rl_train.py",
    "rlver_adversarial/__init__.py",
    "rlver_adversarial/adversarial_gen.py",
    "rlver_adversarial/dataset_builder.py",
    "rlver_adversarial/metrics.py",
    "rlver_adversarial/rlver_eval.py",
    "ablation/__init__.py",
    "ablation/ablation_config.py",
    "ablation/ablation_runner.py",
    "ablation/ablation_analysis.py",
    "scripts/01_download_data.py",
    "scripts/02_run_training.sh",
    "scripts/03_run_eval.sh",
    "scripts/04_analyze_results.py",
    "scripts/05_run_ablations.sh",
    "README.md",
]

required_dirs = [
    "models/qwen_7b",
    "models/qwen_1p5b",
    "models/mistral_7b_sim",
    "cache/hf",
    "cache/datasets",
    "results",
    "results/ablation",
    "logs",
    "configs",
]

print("\n  Files:")
missing_files = []
for f in required_files:
    p = os.path.join(PROJECT_DIR, f)
    if os.path.isfile(p):
        print(f"  ✓ {f}")
    else:
        print(f"  ✗ MISSING: {f}")
        missing_files.append(f)

print("\n  Directories:")
missing_dirs = []
for d in required_dirs:
    p = os.path.join(PROJECT_DIR, d)
    if os.path.isdir(p):
        n = sum(1 for _ in os.scandir(p))
        print(f"  ✓ {d}/  ({n} items)")
    else:
        print(f"  ✗ MISSING: {d}/")
        missing_dirs.append(d)

print("")
if missing_files or missing_dirs:
    if missing_files:
        print(f"  Missing files: {missing_files}")
    if missing_dirs:
        print(f"  Missing dirs:  {missing_dirs}")
    print("  Some items missing — check that the ZIP was fully extracted.")
else:
    print("  ✓ All required files and directories present")
PYEOF

# ─────────────────────────────────────────────────────────────────────────────
hdr "SETUP COMPLETE"
# ─────────────────────────────────────────────────────────────────────────────

cat << EOF

  ┌─────────────────────────────────────────────────────────────────┐
  │  RLVER — Setup Complete                                         │
  ├─────────────────────────────────────────────────────────────────┤
  │  Project root  : $PROJECT_DIR
  │  Conda env     : $ENV_NAME  (Python $PYTHON_VER)
  │  PyTorch       : $TORCH_VER + CUDA $TORCH_CUDA_TAG
  ├─────────────────────────────────────────────────────────────────┤
  │  NEXT STEPS (in order):                                         │
  │                                                                 │
  │  1.  conda activate $ENV_NAME
  │  2.  cd $PROJECT_DIR
  │                                                                 │
  │  3a. Data preparation (fast — rule-based adversarials):         │
  │      python scripts/01_download_data.py                        │
  │                                                                 │
  │  3b. Data preparation (full quality — Mistral adversarials):    │
  │      python scripts/01_download_data.py --gen_adversarial       │
  │                                                                 │
  │  4.  Training (all 4 variants, runs overnight):                 │
  │      bash scripts/02_run_training.sh                            │
  │                                                                 │
  │  5.  Evaluation:                                                │
  │      bash scripts/03_run_eval.sh                                │
  │                                                                 │
  │  6.  Results analysis + plots:                                  │
  │      python scripts/04_analyze_results.py                       │
  │                                                                 │
  │  7.  Ablation study (48 experiments):                           │
  │      bash scripts/05_run_ablations.sh                           │
  │                                                                 │
  │  OR run everything at once:                                     │
  │      bash run_all.sh                                            │
  │                                                                 │
  │  Logs    : $PROJECT_DIR/logs/
  │  Results : $PROJECT_DIR/results/
  └─────────────────────────────────────────────────────────────────┘

EOF
