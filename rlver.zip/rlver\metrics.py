"""
=============================================================================
RLVER — Evaluation Metrics
File  : rlver_adversarial/metrics.py
Author: Dushyant (u23ai085)

Metrics computed:
  - Verification Accuracy (VA)      : % of correct verify/reject decisions
  - Precision / Recall / F1         : for "correct solution" class
  - Adversarial Robustness (AR)     : accuracy on adversarial subset only
  - Thinking Quality Score (TQS)    : semantic + structural quality of CoT
  - Calibration Error (ECE)         : expected calibration error
  - Per-category breakdown          : easy / medium / hard
=============================================================================
"""

from __future__ import annotations

import re
import json
import math
import logging
from dataclasses import dataclass, field, asdict
from typing import List, Optional, Dict, Tuple

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    roc_auc_score,
    confusion_matrix,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Data structures
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class VerificationSample:
    """Single evaluation sample with prediction and metadata."""
    problem_id: str
    problem: str
    solution: str                   # the solution being verified
    label: int                      # 1 = correct solution, 0 = incorrect
    is_adversarial: bool            # whether solution was adversarially generated
    difficulty: str                 # "easy" | "medium" | "hard"

    # Model outputs
    predicted_label: int            # 1 = model says correct, 0 = model says incorrect
    confidence: float               # [0, 1] confidence in prediction
    thinking_text: Optional[str]    # chain-of-thought if enabled
    raw_output: str                 # full model output


@dataclass
class EvalMetrics:
    """All computed metrics for a single evaluation run."""
    # Core
    verification_accuracy: float = 0.0
    precision: float = 0.0
    recall: float = 0.0
    f1_score: float = 0.0
    roc_auc: float = 0.0

    # Adversarial subset
    adversarial_accuracy: float = 0.0
    adversarial_f1: float = 0.0

    # Thinking quality
    thinking_quality_score: float = 0.0   # TQS ∈ [0, 1]
    thinking_coverage: float = 0.0        # % of samples with valid CoT

    # Calibration
    expected_calibration_error: float = 0.0

    # Confusion matrix
    true_positives: int = 0
    true_negatives: int = 0
    false_positives: int = 0
    false_negatives: int = 0

    # Per difficulty
    easy_accuracy: float = 0.0
    medium_accuracy: float = 0.0
    hard_accuracy: float = 0.0

    # Counts
    total_samples: int = 0
    adversarial_samples: int = 0
    clean_samples: int = 0

    # Meta
    model_name: str = ""
    algorithm: str = ""          # "ppo" | "grpo" | "baseline"
    thinking_enabled: bool = False
    run_id: str = ""

    def to_dict(self) -> Dict:
        return asdict(self)

    def summary(self) -> str:
        lines = [
            f"{'='*60}",
            f"  RLVER Evaluation — {self.model_name} [{self.algorithm}]",
            f"{'='*60}",
            f"  Thinking         : {'ON' if self.thinking_enabled else 'OFF'}",
            f"  Total samples    : {self.total_samples}",
            f"  Adversarial      : {self.adversarial_samples} "
            f"({100*self.adversarial_samples/max(self.total_samples,1):.1f}%)",
            f"",
            f"  Verification Acc : {self.verification_accuracy*100:.2f}%",
            f"  Precision        : {self.precision*100:.2f}%",
            f"  Recall           : {self.recall*100:.2f}%",
            f"  F1 Score         : {self.f1_score*100:.2f}%",
            f"  ROC-AUC          : {self.roc_auc:.4f}",
            f"",
            f"  Adv. Accuracy    : {self.adversarial_accuracy*100:.2f}%",
            f"  Adv. F1          : {self.adversarial_f1*100:.2f}%",
            f"",
            f"  TQS              : {self.thinking_quality_score:.4f}",
            f"  Thinking coverage: {self.thinking_coverage*100:.1f}%",
            f"  ECE              : {self.expected_calibration_error:.4f}",
            f"",
            f"  Difficulty Acc   : easy={self.easy_accuracy*100:.1f}%  "
            f"medium={self.medium_accuracy*100:.1f}%  "
            f"hard={self.hard_accuracy*100:.1f}%",
            f"",
            f"  Confusion Matrix:",
            f"    TP={self.true_positives}  FP={self.false_positives}",
            f"    FN={self.false_negatives}  TN={self.true_negatives}",
            f"{'='*60}",
        ]
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Core metric computation
# ─────────────────────────────────────────────────────────────────────────────

def compute_metrics(
    samples: List[VerificationSample],
    model_name: str = "",
    algorithm: str = "baseline",
    thinking_enabled: bool = False,
    run_id: str = "",
) -> EvalMetrics:
    """
    Compute all RLVER metrics from a list of VerificationSamples.

    Args:
        samples: List of evaluated samples with predictions.
        model_name: Name of the model being evaluated.
        algorithm: Training algorithm identifier.
        thinking_enabled: Whether thinking mode was active.
        run_id: Experiment run identifier.

    Returns:
        EvalMetrics dataclass with all computed metrics.
    """
    if not samples:
        logger.warning("compute_metrics called with empty samples list.")
        return EvalMetrics(model_name=model_name, algorithm=algorithm)

    y_true = np.array([s.label for s in samples])
    y_pred = np.array([s.predicted_label for s in samples])
    y_conf = np.array([s.confidence for s in samples])

    # ── Core classification ──────────────────────────────────────────────────
    acc = float(accuracy_score(y_true, y_pred))
    prec, rec, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="binary", zero_division=0
    )

    # ROC-AUC (needs both classes present)
    try:
        auc = float(roc_auc_score(y_true, y_conf))
    except ValueError:
        auc = 0.5

    # Confusion matrix
    cm = confusion_matrix(y_true, y_pred, labels=[1, 0])
    tp = int(cm[0, 0])
    fp = int(cm[1, 0])
    fn = int(cm[0, 1])
    tn = int(cm[1, 1])

    # ── Adversarial subset ───────────────────────────────────────────────────
    adv_samples = [s for s in samples if s.is_adversarial]
    if adv_samples:
        adv_true = np.array([s.label for s in adv_samples])
        adv_pred = np.array([s.predicted_label for s in adv_samples])
        adv_acc = float(accuracy_score(adv_true, adv_pred))
        _, _, adv_f1, _ = precision_recall_fscore_support(
            adv_true, adv_pred, average="binary", zero_division=0
        )
    else:
        adv_acc = 0.0
        adv_f1 = 0.0

    # ── Per-difficulty ───────────────────────────────────────────────────────
    def _diff_acc(diff: str) -> float:
        sub = [s for s in samples if s.difficulty == diff]
        if not sub:
            return 0.0
        return float(accuracy_score(
            [s.label for s in sub], [s.predicted_label for s in sub]
        ))

    # ── Thinking Quality Score (TQS) ─────────────────────────────────────────
    tqs, cov = compute_thinking_quality_score(samples)

    # ── Expected Calibration Error (ECE) ─────────────────────────────────────
    ece = compute_ece(y_true, y_pred, y_conf, n_bins=10)

    metrics = EvalMetrics(
        verification_accuracy=acc,
        precision=float(prec),
        recall=float(rec),
        f1_score=float(f1),
        roc_auc=auc,
        adversarial_accuracy=adv_acc,
        adversarial_f1=float(adv_f1),
        thinking_quality_score=tqs,
        thinking_coverage=cov,
        expected_calibration_error=ece,
        true_positives=tp,
        true_negatives=tn,
        false_positives=fp,
        false_negatives=fn,
        easy_accuracy=_diff_acc("easy"),
        medium_accuracy=_diff_acc("medium"),
        hard_accuracy=_diff_acc("hard"),
        total_samples=len(samples),
        adversarial_samples=len(adv_samples),
        clean_samples=len(samples) - len(adv_samples),
        model_name=model_name,
        algorithm=algorithm,
        thinking_enabled=thinking_enabled,
        run_id=run_id,
    )

    return metrics


# ─────────────────────────────────────────────────────────────────────────────
# Thinking Quality Score (TQS)
# ─────────────────────────────────────────────────────────────────────────────

def compute_thinking_quality_score(
    samples: List[VerificationSample],
) -> Tuple[float, float]:
    """
    Compute Thinking Quality Score (TQS) and coverage.

    TQS rewards:
      - Presence of logical reasoning steps
      - Consistent reference to problem content
      - Correct structural format (<think>...</think>)
      - Absence of degenerate outputs (repetition, empty)

    Returns:
        (mean_tqs, coverage_ratio): both in [0, 1]
    """
    scores = []
    valid_count = 0

    for s in samples:
        if not s.thinking_text:
            scores.append(0.0)
            continue

        thinking = s.thinking_text.strip()
        if len(thinking) < 10:
            scores.append(0.0)
            continue

        valid_count += 1
        score = 0.0

        # 1. Length adequacy (0–0.2): reward non-trivial thinking
        word_count = len(thinking.split())
        if word_count >= 50:
            score += 0.20
        elif word_count >= 20:
            score += 0.10
        elif word_count >= 5:
            score += 0.05

        # 2. Structural markers (0–0.2): uses numbered steps or bullet logic
        step_patterns = [
            r"\bstep\s*\d",
            r"^\s*\d+[\.\)]\s",
            r"\bfirst\b.*\bthen\b",
            r"\bbecause\b",
            r"\btherefore\b",
            r"\bthus\b",
            r"\bsince\b",
            r"\bif\b.*\bthen\b",
        ]
        struct_hits = sum(
            1 for p in step_patterns
            if re.search(p, thinking, re.IGNORECASE | re.MULTILINE)
        )
        score += min(0.20, struct_hits * 0.04)

        # 3. Mathematical content (0–0.25): contains equations or calculations
        math_patterns = [
            r"\d+\s*[\+\-\*\/\=]\s*\d+",
            r"\b\d+\s*\*\s*\d+",
            r"\=\s*\d+",
            r"\$[^\$]+\$",           # LaTeX inline
            r"\\frac",
            r"\\sum",
        ]
        math_hits = sum(
            1 for p in math_patterns
            if re.search(p, thinking)
        )
        score += min(0.25, math_hits * 0.05)

        # 4. Problem reference (0–0.15): mentions key terms from problem
        problem_words = set(s.problem.lower().split()) - _stopwords()
        thinking_words = set(thinking.lower().split())
        overlap = len(problem_words & thinking_words) / max(len(problem_words), 1)
        score += min(0.15, overlap * 0.30)

        # 5. Non-repetition (0–0.10): penalize if >30% bigrams repeated
        bigrams = _bigrams(thinking)
        if bigrams:
            unique_ratio = len(set(bigrams)) / len(bigrams)
            score += 0.10 * unique_ratio
        else:
            score += 0.05

        # 6. Consistent verdict (0–0.10): thinking leads to correct conclusion
        #    Check if thinking mentions "correct" or "incorrect" matching label
        verdict_match = _check_verdict_consistency(thinking, s.label)
        score += 0.10 * verdict_match

        scores.append(min(1.0, score))

    mean_tqs = float(np.mean(scores)) if scores else 0.0
    coverage = valid_count / max(len(samples), 1)

    return mean_tqs, coverage


def _stopwords() -> set:
    return {
        "the", "a", "an", "is", "are", "was", "were", "be", "been",
        "has", "have", "had", "do", "does", "did", "will", "would",
        "could", "should", "may", "might", "of", "in", "on", "at",
        "to", "for", "with", "by", "from", "and", "or", "but", "if",
        "that", "this", "it", "its", "he", "she", "they", "we", "i",
    }


def _bigrams(text: str) -> List[Tuple[str, str]]:
    words = text.lower().split()
    return list(zip(words[:-1], words[1:]))


def _check_verdict_consistency(thinking: str, true_label: int) -> float:
    """Return 1.0 if thinking's conclusion matches true label, 0.5 otherwise."""
    thinking_lower = thinking.lower()
    has_correct = bool(re.search(r"\bcorrect\b|\bvalid\b|\bright\b", thinking_lower))
    has_incorrect = bool(
        re.search(r"\bincorrect\b|\binvalid\b|\bwrong\b|\berror\b", thinking_lower)
    )
    if true_label == 1 and has_correct and not has_incorrect:
        return 1.0
    if true_label == 0 and has_incorrect and not has_correct:
        return 1.0
    if has_correct == has_incorrect:  # ambiguous or absent
        return 0.5
    return 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Expected Calibration Error (ECE)
# ─────────────────────────────────────────────────────────────────────────────

def compute_ece(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_conf: np.ndarray,
    n_bins: int = 10,
) -> float:
    """
    Compute Expected Calibration Error.
    ECE = Σ (|B_m| / n) * |acc(B_m) - conf(B_m)|
    """
    bin_boundaries = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    n = len(y_true)

    for lo, hi in zip(bin_boundaries[:-1], bin_boundaries[1:]):
        mask = (y_conf >= lo) & (y_conf < hi)
        if mask.sum() == 0:
            continue
        bin_acc = float((y_pred[mask] == y_true[mask]).mean())
        bin_conf = float(y_conf[mask].mean())
        ece += (mask.sum() / n) * abs(bin_acc - bin_conf)

    return float(ece)


# ─────────────────────────────────────────────────────────────────────────────
# Output parsing utilities
# ─────────────────────────────────────────────────────────────────────────────

def parse_model_output(
    raw_output: str,
    thinking_enabled: bool = True,
) -> Tuple[Optional[int], float, Optional[str]]:
    """
    Parse raw model output into (predicted_label, confidence, thinking_text).

    Model output format:
        <think>
        [chain of thought]
        </think>
        VERDICT: CORRECT | INCORRECT
        CONFIDENCE: 0.XX

    Returns:
        predicted_label: 1 for correct, 0 for incorrect, None if unparseable
        confidence: float in [0, 1]
        thinking_text: extracted CoT string or None
    """
    # Extract thinking
    thinking_text = None
    if thinking_enabled:
        think_match = re.search(
            r"<think>(.*?)</think>", raw_output, re.DOTALL | re.IGNORECASE
        )
        if think_match:
            thinking_text = think_match.group(1).strip()

    # Extract verdict
    predicted_label = None
    verdict_match = re.search(
        r"VERDICT\s*:\s*(CORRECT|INCORRECT)", raw_output, re.IGNORECASE
    )
    if verdict_match:
        verdict = verdict_match.group(1).strip().upper()
        predicted_label = 1 if verdict == "CORRECT" else 0

    # Fallback: look for explicit labels
    if predicted_label is None:
        if re.search(r"\bthe solution is correct\b", raw_output, re.IGNORECASE):
            predicted_label = 1
        elif re.search(r"\bthe solution is (incorrect|wrong)\b", raw_output, re.IGNORECASE):
            predicted_label = 0

    # Extract confidence
    confidence = 0.5  # default
    conf_match = re.search(
        r"CONFIDENCE\s*:\s*([0-9]*\.?[0-9]+)", raw_output, re.IGNORECASE
    )
    if conf_match:
        try:
            confidence = max(0.0, min(1.0, float(conf_match.group(1))))
        except ValueError:
            confidence = 0.5

    # If label found but no explicit confidence, infer from verdict
    if predicted_label is not None and conf_match is None:
        confidence = 0.8 if predicted_label == 1 else 0.8

    return predicted_label, confidence, thinking_text


# ─────────────────────────────────────────────────────────────────────────────
# Results serialization
# ─────────────────────────────────────────────────────────────────────────────

def save_metrics(metrics: EvalMetrics, path: str) -> None:
    """Save metrics to JSON file."""
    import os
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(metrics.to_dict(), f, indent=2)
    logger.info(f"Metrics saved → {path}")


def load_metrics(path: str) -> EvalMetrics:
    """Load metrics from JSON file."""
    with open(path) as f:
        d = json.load(f)
    return EvalMetrics(**d)


def compare_metrics(
    baseline: EvalMetrics,
    trained: EvalMetrics,
    label_baseline: str = "Baseline",
    label_trained: str = "RL-Trained",
) -> str:
    """Generate a side-by-side comparison string."""
    def delta(a: float, b: float) -> str:
        d = b - a
        sign = "+" if d >= 0 else ""
        return f"{sign}{d*100:.2f}%"

    lines = [
        f"{'='*70}",
        f"  RLVER Metric Comparison",
        f"  {label_baseline:30s}  vs  {label_trained}",
        f"{'='*70}",
        f"  {'Metric':<28} {label_baseline:>12}  {label_trained:>12}  {'Δ':>8}",
        f"  {'-'*66}",
        f"  {'Verification Acc':<28} {baseline.verification_accuracy*100:>11.2f}%  "
        f"{trained.verification_accuracy*100:>11.2f}%  "
        f"{delta(baseline.verification_accuracy, trained.verification_accuracy):>8}",
        f"  {'F1 Score':<28} {baseline.f1_score*100:>11.2f}%  "
        f"{trained.f1_score*100:>11.2f}%  "
        f"{delta(baseline.f1_score, trained.f1_score):>8}",
        f"  {'Adversarial Accuracy':<28} {baseline.adversarial_accuracy*100:>11.2f}%  "
        f"{trained.adversarial_accuracy*100:>11.2f}%  "
        f"{delta(baseline.adversarial_accuracy, trained.adversarial_accuracy):>8}",
        f"  {'TQS':<28} {baseline.thinking_quality_score:>11.4f}   "
        f"{trained.thinking_quality_score:>11.4f}   "
        f"{trained.thinking_quality_score - baseline.thinking_quality_score:>+8.4f}",
        f"  {'ECE (lower=better)':<28} {baseline.expected_calibration_error:>11.4f}   "
        f"{trained.expected_calibration_error:>11.4f}   "
        f"{trained.expected_calibration_error - baseline.expected_calibration_error:>+8.4f}",
        f"{'='*70}",
    ]
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Quick smoke-test
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import random
    random.seed(42)

    # Build dummy samples
    dummy_samples = []
    for i in range(200):
        label = random.randint(0, 1)
        pred = label if random.random() > 0.25 else 1 - label
        conf = random.uniform(0.55, 0.95) if pred == label else random.uniform(0.45, 0.65)
        dummy_samples.append(
            VerificationSample(
                problem_id=f"prob_{i:03d}",
                problem=f"If x = {i} and y = {i+1}, what is x + y?",
                solution=f"x + y = {i} + {i+1} = {i+i+1}",
                label=label,
                is_adversarial=(i % 3 == 0),
                difficulty=["easy", "medium", "hard"][i % 3],
                predicted_label=pred,
                confidence=conf,
                thinking_text=(
                    f"Let me verify: x={i}, y={i+1}. Adding: {i}+{i+1}={'correct' if label else 'wrong'}."
                    if random.random() > 0.2 else None
                ),
                raw_output=(
                    f"<think>Let me verify: x={i}, y={i+1}.</think>\n"
                    f"VERDICT: {'CORRECT' if pred else 'INCORRECT'}\nCONFIDENCE: {conf:.2f}"
                ),
            )
        )

    metrics = compute_metrics(
        dummy_samples,
        model_name="Qwen2.5-7B-Instruct",
        algorithm="ppo",
        thinking_enabled=True,
        run_id="test_run_001",
    )
    print(metrics.summary())
