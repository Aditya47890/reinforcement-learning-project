"""
=============================================================================
RLVER — Adversarial Solution Generator
File  : rlver_adversarial/adversarial_gen.py
Author: Dushyant (u23ai085)

Uses Mistral-7B-Instruct-v0.3 to generate adversarial (plausible but wrong)
solutions to GSM8K math problems. These form the negative class for the
RLVER verification task.

Adversarial strategies implemented:
  1. WRONG_FINAL    — correct steps but wrong final arithmetic
  2. WRONG_STEP     — subtly wrong intermediate step
  3. WRONG_SETUP    — misinterprets the problem (wrong equation setup)
  4. MISSING_STEP   — skips a critical step
  5. UNIT_ERROR     — correct numbers but wrong units/interpretation

The generator applies one strategy per sample (weighted random selection).
=============================================================================
"""

from __future__ import annotations

import re
import json
import random
import logging
import time
from enum import Enum
from typing import Optional, List, Dict, Tuple
from dataclasses import dataclass

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Strategy enum
# ─────────────────────────────────────────────────────────────────────────────

class AdversarialStrategy(Enum):
    WRONG_FINAL   = "wrong_final"
    WRONG_STEP    = "wrong_step"
    WRONG_SETUP   = "wrong_setup"
    MISSING_STEP  = "missing_step"
    UNIT_ERROR    = "unit_error"


STRATEGY_WEIGHTS = {
    AdversarialStrategy.WRONG_FINAL:  0.35,
    AdversarialStrategy.WRONG_STEP:   0.30,
    AdversarialStrategy.WRONG_SETUP:  0.15,
    AdversarialStrategy.MISSING_STEP: 0.12,
    AdversarialStrategy.UNIT_ERROR:   0.08,
}


def _sample_strategy() -> AdversarialStrategy:
    strategies = list(STRATEGY_WEIGHTS.keys())
    weights = [STRATEGY_WEIGHTS[s] for s in strategies]
    return random.choices(strategies, weights=weights, k=1)[0]


# ─────────────────────────────────────────────────────────────────────────────
# Prompt templates per strategy
# ─────────────────────────────────────────────────────────────────────────────

_SYSTEM_PROMPT = (
    "You are an expert at creating realistic but subtly incorrect math solutions. "
    "You generate plausible-looking solutions that contain a specific type of error. "
    "Your solutions must look convincing — use proper mathematical notation and show work. "
    "Never reveal that the solution is wrong. Never say 'incorrect'. Just write the solution."
)

_STRATEGY_INSTRUCTIONS: Dict[AdversarialStrategy, str] = {
    AdversarialStrategy.WRONG_FINAL: (
        "Write a solution that follows all the correct reasoning steps but makes an arithmetic "
        "error only in the final computation. All intermediate steps must be correct."
    ),
    AdversarialStrategy.WRONG_STEP: (
        "Write a solution that has a subtle arithmetic or algebraic error in ONE intermediate step. "
        "All other steps should be correct and the writing style should look confident."
    ),
    AdversarialStrategy.WRONG_SETUP: (
        "Write a solution that misinterprets one aspect of the problem (e.g., misreads 'per day' "
        "as 'per week', or multiplies when it should divide). The math within the chosen interpretation "
        "should be consistent."
    ),
    AdversarialStrategy.MISSING_STEP: (
        "Write a solution that skips a necessary step or forgets to account for one element "
        "of the problem. The solution should look complete but arrive at a wrong answer."
    ),
    AdversarialStrategy.UNIT_ERROR: (
        "Write a solution that uses the correct mathematical operations but confuses units "
        "or fails to convert units correctly, leading to a wrong final number."
    ),
}

_USER_TEMPLATE = """\
Math Problem:
{problem}

Correct Solution (for reference — do NOT copy this, create your own wrong version):
{correct_solution}

Instruction: {instruction}

Write your subtly incorrect solution below. Show all work. End with "#### <number>" for your final answer.
"""


# ─────────────────────────────────────────────────────────────────────────────
# AdversarialGenerator
# ─────────────────────────────────────────────────────────────────────────────

class AdversarialGenerator:
    """
    Generates adversarial math solutions using Mistral-7B-Instruct-v0.3.

    Usage:
        gen = AdversarialGenerator(model_path="path/to/mistral_7b_sim")
        gen.load()
        wrong_sol = gen.generate(problem, correct_solution, correct_answer)
        gen.unload()
    """

    def __init__(
        self,
        model_path: str,
        device: str = "cuda",
        torch_dtype=torch.bfloat16,
        max_new_tokens: int = 300,
        temperature: float = 0.85,
        top_p: float = 0.92,
        seed: int = 42,
        batch_size: int = 4,
    ):
        self.model_path = model_path
        self.device = device
        self.torch_dtype = torch_dtype
        self.max_new_tokens = max_new_tokens
        self.temperature = temperature
        self.top_p = top_p
        self.seed = seed
        self.batch_size = batch_size

        self._tokenizer = None
        self._model = None
        self._loaded = False

        random.seed(seed)
        torch.manual_seed(seed)

    # ── Model lifecycle ───────────────────────────────────────────────────────

    def load(self) -> None:
        """Load Mistral tokenizer and model."""
        logger.info(f"Loading adversarial model from: {self.model_path}")
        t0 = time.time()

        self._tokenizer = AutoTokenizer.from_pretrained(
            self.model_path,
            trust_remote_code=True,
            padding_side="left",
        )
        if self._tokenizer.pad_token is None:
            self._tokenizer.pad_token = self._tokenizer.eos_token

        self._model = AutoModelForCausalLM.from_pretrained(
            self.model_path,
            torch_dtype=self.torch_dtype,
            device_map="auto",
            trust_remote_code=True,
        )
        self._model.eval()
        self._loaded = True

        elapsed = time.time() - t0
        logger.info(
            f"Adversarial model loaded in {elapsed:.1f}s | "
            f"Device: {next(self._model.parameters()).device}"
        )

    def unload(self) -> None:
        """Free GPU memory."""
        if self._model is not None:
            del self._model
            self._model = None
        if self._tokenizer is not None:
            del self._tokenizer
            self._tokenizer = None
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        self._loaded = False
        logger.info("Adversarial model unloaded.")

    # ── Single generation ─────────────────────────────────────────────────────

    def generate(
        self,
        problem: str,
        correct_solution: str,
        correct_answer: str,
        strategy: Optional[AdversarialStrategy] = None,
        max_retries: int = 3,
    ) -> str:
        """
        Generate one adversarial solution for a problem.

        Args:
            problem: The math problem text.
            correct_solution: The correct step-by-step solution.
            correct_answer: The correct numeric answer.
            strategy: If None, randomly samples a strategy.
            max_retries: Retry if output is too similar to original.

        Returns:
            Adversarial solution string (plausible but wrong).
        """
        if not self._loaded:
            raise RuntimeError("Call .load() before .generate()")

        chosen_strategy = strategy or _sample_strategy()

        for attempt in range(max_retries):
            raw = self._call_model(problem, correct_solution, chosen_strategy)
            cleaned = self._clean_output(raw)

            # Validate: ensure answer differs from correct
            if self._is_valid_adversarial(cleaned, correct_answer):
                return cleaned

            logger.debug(
                f"Attempt {attempt+1}: adversarial output too similar, retrying "
                f"with strategy {chosen_strategy.value}"
            )
            # Try different strategy on retry
            chosen_strategy = _sample_strategy()

        # Last resort: rule-based perturbation
        logger.warning("Falling back to rule-based perturbation.")
        from dataset_builder import perturb_solution_rule_based
        return perturb_solution_rule_based(correct_solution, correct_answer)

    # ── Batch generation ──────────────────────────────────────────────────────

    def generate_batch(
        self,
        records: List[Dict],
        show_progress: bool = True,
    ) -> List[str]:
        """
        Generate adversarial solutions for a batch of records.

        Args:
            records: List of dicts with keys: problem, solution, answer
            show_progress: Whether to show tqdm progress bar

        Returns:
            List of adversarial solutions, one per record.
        """
        if not self._loaded:
            raise RuntimeError("Call .load() before .generate_batch()")

        results = []
        iterator = records

        if show_progress:
            try:
                from tqdm import tqdm
                iterator = tqdm(records, desc="Generating adversarials")
            except ImportError:
                pass

        for record in iterator:
            adv = self.generate(
                problem=record["problem"],
                correct_solution=record["solution"],
                correct_answer=record["answer"],
            )
            results.append(adv)

        return results

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _build_chat_prompt(
        self,
        problem: str,
        correct_solution: str,
        strategy: AdversarialStrategy,
    ) -> str:
        """Build Mistral instruct chat prompt."""
        instruction = _STRATEGY_INSTRUCTIONS[strategy]
        user_content = _USER_TEMPLATE.format(
            problem=problem,
            correct_solution=correct_solution,
            instruction=instruction,
        )

        # Mistral instruct format: [INST] ... [/INST]
        prompt = (
            f"<s>[INST] <<SYS>>\n{_SYSTEM_PROMPT}\n<</SYS>>\n\n"
            f"{user_content} [/INST]"
        )
        return prompt

    def _call_model(
        self,
        problem: str,
        correct_solution: str,
        strategy: AdversarialStrategy,
    ) -> str:
        """Run a single forward pass and return generated text."""
        prompt = self._build_chat_prompt(problem, correct_solution, strategy)

        inputs = self._tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=1024,
        ).to(self.device)

        with torch.no_grad():
            output_ids = self._model.generate(
                **inputs,
                max_new_tokens=self.max_new_tokens,
                temperature=self.temperature,
                top_p=self.top_p,
                do_sample=True,
                pad_token_id=self._tokenizer.eos_token_id,
                eos_token_id=self._tokenizer.eos_token_id,
            )

        # Decode only new tokens
        new_ids = output_ids[0][inputs["input_ids"].shape[-1]:]
        generated = self._tokenizer.decode(new_ids, skip_special_tokens=True)
        return generated.strip()

    def _clean_output(self, raw: str) -> str:
        """Remove any meta-commentary from the generated solution."""
        # Remove any preamble like "Here is my solution:"
        lines = raw.split("\n")
        clean_lines = []
        skip_patterns = [
            r"^here is",
            r"^the incorrect",
            r"^note:",
            r"^disclaimer",
            r"^this is wrong",
            r"^i will",
        ]
        for line in lines:
            if any(re.match(p, line.strip(), re.IGNORECASE) for p in skip_patterns):
                continue
            clean_lines.append(line)

        return "\n".join(clean_lines).strip()

    def _is_valid_adversarial(self, generated: str, correct_answer: str) -> bool:
        """
        Validate that the generated solution:
          1. Has a different final answer from the correct one
          2. Has reasonable length (not degenerate)
          3. Actually contains some mathematical content
        """
        if len(generated.split()) < 10:
            return False

        # Must have some numeric content
        if not re.search(r"\d", generated):
            return False

        # Extract generated answer
        gen_answer = _extract_generated_answer(generated)
        if gen_answer is None:
            # No explicit #### answer — still usable if content differs
            return True

        # Ensure answer is numerically different
        try:
            gen_val = float(gen_answer.replace(",", ""))
            cor_val = float(correct_answer.replace(",", ""))
            if abs(gen_val - cor_val) < 1e-6:
                return False  # Same answer — not adversarial enough
        except (ValueError, AttributeError):
            pass  # Can't compare — assume valid

        return True


def _extract_generated_answer(text: str) -> Optional[str]:
    match = re.search(r"####\s*([\-0-9,\.]+)", text)
    return match.group(1).strip() if match else None


# ─────────────────────────────────────────────────────────────────────────────
# Standalone CLI
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    import os

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    parser = argparse.ArgumentParser(description="Generate adversarial solutions")
    parser.add_argument(
        "--model_path",
        type=str,
        default=os.path.expanduser(
            "~/Dushyant_u23ai085_9256777500/models/mistral_7b_sim"
        ),
    )
    parser.add_argument(
        "--input_jsonl",
        type=str,
        help="Input JSONL with fields: problem, solution, answer",
    )
    parser.add_argument(
        "--output_jsonl",
        type=str,
        default=os.path.expanduser(
            "~/Dushyant_u23ai085_9256777500/cache/datasets/adversarial_generated.jsonl"
        ),
    )
    parser.add_argument("--max_samples", type=int, default=None)
    args = parser.parse_args()

    # Demo without file input
    if args.input_jsonl is None:
        logger.info("No input file — running demo generation.")
        demo_problem = (
            "A bakery makes 240 cookies in 8 hours. "
            "How many cookies does it make per hour?"
        )
        demo_solution = (
            "To find cookies per hour, divide total cookies by hours.\n"
            "240 cookies ÷ 8 hours = 30 cookies per hour.\n"
            "#### 30"
        )
        demo_answer = "30"

        gen = AdversarialGenerator(model_path=args.model_path)
        gen.load()

        for strategy in AdversarialStrategy:
            print(f"\n{'─'*60}")
            print(f"Strategy: {strategy.value}")
            print(f"{'─'*60}")
            result = gen.generate(
                demo_problem, demo_solution, demo_answer, strategy=strategy
            )
            print(result)

        gen.unload()
    else:
        # File-based generation
        records = []
        with open(args.input_jsonl) as f:
            for line in f:
                line = line.strip()
                if line:
                    records.append(json.loads(line))

        if args.max_samples:
            records = records[:args.max_samples]

        gen = AdversarialGenerator(model_path=args.model_path)
        gen.load()

        adversarials = gen.generate_batch(records, show_progress=True)

        os.makedirs(os.path.dirname(os.path.abspath(args.output_jsonl)), exist_ok=True)
        with open(args.output_jsonl, "w") as f:
            for record, adv in zip(records, adversarials):
                out = {**record, "adversarial_solution": adv, "label": 0}
                f.write(json.dumps(out) + "\n")

        logger.info(f"Saved {len(adversarials)} adversarial solutions → {args.output_jsonl}")
        gen.unload()
