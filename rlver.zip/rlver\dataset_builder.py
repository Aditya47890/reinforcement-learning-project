"""
=============================================================================
RLVER — Dataset Builder
File  : rlver_adversarial/dataset_builder.py
Author: Dushyant (u23ai085)

Builds the RLVER verification dataset:
  - Base: GSM8K (openai/gsm8k) — ground-truth correct solutions
  - Adversarial: Mistral-7B-Instruct perturbed solutions (wrong answers)
  - Balanced: configurable ratio of correct:adversarial samples
  - Difficulty tagging via heuristic (word count, operator count, step count)

Output schema per sample:
  {
    "problem_id"    : str,
    "problem"       : str,   # the math question
    "solution"      : str,   # solution to verify
    "label"         : int,   # 1=correct, 0=incorrect
    "is_adversarial": bool,
    "difficulty"    : str,   # easy | medium | hard
    "answer"        : str,   # ground-truth final numeric answer
    "source"        : str    # "gsm8k_train" | "gsm8k_test"
  }
=============================================================================
"""

from __future__ import annotations

import re
import os
import json
import random
import logging
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Schema
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RLVERSample:
    problem_id: str
    problem: str
    solution: str
    label: int               # 1 = correct, 0 = incorrect/adversarial
    is_adversarial: bool
    difficulty: str          # easy | medium | hard
    answer: str              # numeric ground-truth answer
    source: str              # dataset split identifier

    def to_dict(self) -> Dict:
        return asdict(self)


# ─────────────────────────────────────────────────────────────────────────────
# GSM8K loader
# ─────────────────────────────────────────────────────────────────────────────

def load_gsm8k(
    split: str = "train",
    cache_dir: Optional[str] = None,
    max_samples: Optional[int] = None,
) -> List[Dict]:
    """
    Load GSM8K from HuggingFace datasets.
    GSM8K format: question: str, answer: str (solution text + "#### <number>")
    """
    try:
        from datasets import load_dataset
    except ImportError:
        raise ImportError("Install 'datasets': pip install datasets")

    logger.info(f"Loading GSM8K [{split}] ...")
    ds = load_dataset("openai/gsm8k", "main", split=split, cache_dir=cache_dir)

    if max_samples is not None:
        ds = ds.select(range(min(max_samples, len(ds))))

    records = []
    for idx, item in enumerate(ds):
        question = item["question"].strip()
        raw_answer = item["answer"].strip()
        final_ans = _extract_gsm8k_answer(raw_answer)
        solution_text = raw_answer.split("####")[0].strip()
        records.append({
            "idx": idx,
            "problem": question,
            "solution": solution_text,
            "answer": final_ans,
        })

    logger.info(f"  Loaded {len(records)} GSM8K [{split}] samples.")
    return records


def _extract_gsm8k_answer(raw: str) -> str:
    """Extract final numeric answer from '#### N' format."""
    match = re.search(r"####\s*([\-0-9,\.]+)", raw)
    if match:
        return match.group(1).strip().replace(",", "")
    return ""


# ─────────────────────────────────────────────────────────────────────────────
# Difficulty heuristic
# ─────────────────────────────────────────────────────────────────────────────

def assign_difficulty(problem: str, solution: str) -> str:
    """
    Heuristic difficulty: easy / medium / hard
    Based on: problem word count, number of solution steps, operator count.
    """
    word_count = len(problem.split())
    sentences  = [s for s in re.split(r"[.!?]", solution) if s.strip()]
    step_count = len(sentences)
    op_count   = len(re.findall(r"[\+\-\*\/]", solution))

    score = 0
    if word_count > 40: score += 1
    if step_count > 5:  score += 1
    if op_count   > 4:  score += 1

    return ["easy", "medium", "hard"][min(score, 2)]


# ─────────────────────────────────────────────────────────────────────────────
# Problem ID
# ─────────────────────────────────────────────────────────────────────────────

def make_problem_id(source: str, idx: int, adversarial: bool) -> str:
    suffix = "_adv" if adversarial else "_clean"
    return f"{source}_{idx:05d}{suffix}"


# ─────────────────────────────────────────────────────────────────────────────
# Rule-based adversarial perturbation (fallback when Mistral unavailable)
# ─────────────────────────────────────────────────────────────────────────────

def perturb_solution_rule_based(solution: str, answer: str) -> str:
    """
    Apply rule-based perturbations to create an incorrect solution.
    Tries to perturb the answer-matching number first, then any number.
    """
    perturbed = solution
    numbers   = re.findall(r"\b(\d+(?:\.\d+)?)\b", perturbed)

    if numbers:
        # Try to find the number that matches the answer and perturb it
        perturbed_flag = False
        if answer:
            for n in reversed(numbers):
                try:
                    if abs(float(n) - float(answer)) < 1e-6:
                        wrong = str(int(float(n)) + random.choice([-2, -1, 1, 2, 3, 5]))
                        # Replace last occurrence safely
                        idx = perturbed.rfind(n)
                        if idx != -1:
                            perturbed = perturbed[:idx] + wrong + perturbed[idx + len(n):]
                        perturbed_flag = True
                        break
                except (ValueError, TypeError):
                    continue

        if not perturbed_flag:
            # Perturb a random intermediate number
            target = random.choice(numbers)
            try:
                wrong = str(int(float(target)) + random.choice([-1, 1, 2]))
                perturbed = perturbed.replace(target, wrong, 1)
            except ValueError:
                pass

    # Optionally flip an addition to subtraction
    if random.random() < 0.3:
        perturbed = re.sub(
            r"(\d+)\s*\+\s*(\d+)",
            lambda m: f"{m.group(1)} - {m.group(2)}",
            perturbed,
            count=1,
        )

    return perturbed


# ─────────────────────────────────────────────────────────────────────────────
# Dataset builder (main class)
# ─────────────────────────────────────────────────────────────────────────────

class RLVERDatasetBuilder:
    """
    Builds the RLVER training / evaluation dataset.

    For each GSM8K problem:
      - Always adds a clean (correct) sample  → label=1
      - With prob adversarial_ratio: adds an adversarial sample → label=0
    Results are shuffled before return / save.
    """

    def __init__(
        self,
        adversarial_ratio: float = 0.4,
        cache_dir: Optional[str] = None,
        seed: int = 42,
    ):
        self.adversarial_ratio = adversarial_ratio
        self.cache_dir         = cache_dir
        self.seed              = seed
        random.seed(seed)
        self._adversarial_generator = None

    def set_adversarial_generator(self, generator) -> None:
        """Inject a loaded AdversarialGenerator (adversarial_gen.py)."""
        self._adversarial_generator = generator

    def build(
        self,
        split: str = "train",
        max_samples: Optional[int] = None,
        save_path: Optional[str] = None,
    ) -> List[RLVERSample]:
        """
        Build the RLVER dataset for a given split.

        Args:
            split       : "train" | "test"
            max_samples : cap on base problems loaded
            save_path   : if given, persist as JSONL

        Returns:
            List[RLVERSample]
        """
        gsm_records = load_gsm8k(
            split=split,
            cache_dir=self.cache_dir,
            max_samples=max_samples,
        )

        source = f"gsm8k_{split}"
        all_samples: List[RLVERSample] = []

        logger.info(
            f"Building [{split}] dataset from {len(gsm_records)} problems "
            f"(adversarial_ratio={self.adversarial_ratio}) ..."
        )

        for record in gsm_records:
            idx        = record["idx"]
            problem    = record["problem"]
            solution   = record["solution"]
            answer     = record["answer"]
            difficulty = assign_difficulty(problem, solution)

            # ── Clean sample (label = 1) ────────────────────────────────────
            all_samples.append(RLVERSample(
                problem_id   = make_problem_id(source, idx, adversarial=False),
                problem      = problem,
                solution     = solution,
                label        = 1,
                is_adversarial = False,
                difficulty   = difficulty,
                answer       = answer,
                source       = source,
            ))

            # ── Adversarial sample (label = 0) ──────────────────────────────
            if random.random() < self.adversarial_ratio:
                adv_solution = self._generate_adversarial(problem, solution, answer)
                all_samples.append(RLVERSample(
                    problem_id   = make_problem_id(source, idx, adversarial=True),
                    problem      = problem,
                    solution     = adv_solution,
                    label        = 0,
                    is_adversarial = True,
                    difficulty   = difficulty,
                    answer       = answer,
                    source       = source,
                ))

        random.shuffle(all_samples)

        n_clean = sum(1 for s in all_samples if not s.is_adversarial)
        n_adv   = len(all_samples) - n_clean
        logger.info(
            f"Dataset ready: {len(all_samples)} total "
            f"({n_clean} clean, {n_adv} adversarial)"
        )
        for diff in ["easy", "medium", "hard"]:
            c = sum(1 for s in all_samples if s.difficulty == diff)
            logger.info(f"  {diff:6s}: {c}")

        if save_path:
            self._save_jsonl(all_samples, save_path)

        return all_samples

    def _generate_adversarial(self, problem: str, solution: str, answer: str) -> str:
        if self._adversarial_generator is not None:
            try:
                return self._adversarial_generator.generate(problem, solution, answer)
            except Exception as e:
                logger.warning(f"Adversarial generator failed ({e}). Using rule-based.")
        return perturb_solution_rule_based(solution, answer)

    def _save_jsonl(self, samples: List[RLVERSample], path: str) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w") as f:
            for s in samples:
                f.write(json.dumps(s.to_dict()) + "\n")
        logger.info(f"Saved → {path} ({len(samples)} lines)")

    @staticmethod
    def load_jsonl(path: str) -> List[RLVERSample]:
        """Load a previously saved RLVER JSONL dataset."""
        samples = []
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line:
                    samples.append(RLVERSample(**json.loads(line)))
        logger.info(f"Loaded {len(samples)} samples from {path}")
        return samples


# ─────────────────────────────────────────────────────────────────────────────
# Prompt templates
# ─────────────────────────────────────────────────────────────────────────────

VERIFY_PROMPT_THINKING = """\
You are a rigorous math verifier. Your task is to determine whether the given solution to a math problem is CORRECT or INCORRECT.

Problem:
{problem}

Proposed Solution:
{solution}

First, think step-by-step inside <think> tags. Check each calculation carefully.
Then provide your verdict and confidence.

<think>
</think>
VERDICT: CORRECT or INCORRECT
CONFIDENCE: 0.XX"""


VERIFY_PROMPT_NO_THINKING = """\
You are a rigorous math verifier. Determine whether the given solution is CORRECT or INCORRECT.

Problem:
{problem}

Proposed Solution:
{solution}

Respond with:
VERDICT: CORRECT or INCORRECT
CONFIDENCE: 0.XX"""


def format_verification_prompt(
    sample: RLVERSample,
    thinking_enabled: bool = True,
) -> str:
    """Format a RLVERSample into a complete verification prompt."""
    template = VERIFY_PROMPT_THINKING if thinking_enabled else VERIFY_PROMPT_NO_THINKING
    return template.format(problem=sample.problem, solution=sample.solution)


# ─────────────────────────────────────────────────────────────────────────────
# HuggingFace Dataset conversion (for DataLoader)
# ─────────────────────────────────────────────────────────────────────────────

def to_hf_dataset(
    samples: List[RLVERSample],
    thinking_enabled: bool = True,
):
    """
    Convert RLVERSample list → HuggingFace Dataset for use with DataLoader.

    Fields in output Dataset:
      problem_id    : str
      prompt        : str  — formatted verification prompt
      label         : int  — 1 or 0
      is_adversarial: bool
      difficulty    : str
      answer        : str  — ground-truth numeric answer
      problem       : str  — raw problem text (REQUIRED by reward function)

    We intentionally do NOT tokenize here; the training loop tokenizes
    per-sample on-the-fly to handle variable lengths correctly.
    """
    try:
        from datasets import Dataset
    except ImportError:
        raise ImportError("pip install datasets")

    rows = []
    for s in samples:
        prompt = format_verification_prompt(s, thinking_enabled=thinking_enabled)
        rows.append({
            "problem_id":     s.problem_id,
            "prompt":         prompt,
            "label":          s.label,
            "is_adversarial": s.is_adversarial,
            "difficulty":     s.difficulty,
            "answer":         s.answer,
            "problem":        s.problem,   # ← needed by reward function
        })

    return Dataset.from_list(rows)


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    import pprint

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )

    _PROJECT_ROOT = os.path.expanduser("~/Dushyant_u23ai085_9256777500")

    parser = argparse.ArgumentParser(description="Build RLVER dataset")
    parser.add_argument("--split",             choices=["train", "test"], default="train")
    parser.add_argument("--max_samples",       type=int,   default=None)
    parser.add_argument("--adversarial_ratio", type=float, default=0.4)
    parser.add_argument(
        "--save_dir", type=str,
        default=os.path.join(_PROJECT_ROOT, "cache", "datasets"),
    )
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    builder = RLVERDatasetBuilder(
        adversarial_ratio=args.adversarial_ratio,
        cache_dir=os.path.join(_PROJECT_ROOT, "cache", "hf"),
        seed=args.seed,
    )

    os.makedirs(args.save_dir, exist_ok=True)
    save_path = os.path.join(args.save_dir, f"rlver_{args.split}.jsonl")
    samples = builder.build(
        split=args.split,
        max_samples=args.max_samples,
        save_path=save_path,
    )

    print(f"\nDataset ready: {len(samples)} samples → {save_path}")
    print("Sample #0:")
    pprint.pprint(samples[0].to_dict())
