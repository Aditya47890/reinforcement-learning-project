#!/bin/bash
# =============================================================================
# RLVER — Reset & Fresh Start
# File  : reset_and_fresh_start.sh
# Author: Dushyant (u23ai085)
#
# DANGER: Deletes the entire project folder + conda env and rebuilds from scratch.
# Run this when you want to completely wipe the previous state.
#
# Usage:
#   bash reset_and_fresh_start.sh           # interactive — asks confirmation
#   bash reset_and_fresh_start.sh --yes     # non-interactive (for HPC jobs)
# =============================================================================

set -euo pipefail

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
BLU='\033[0;34m'; NC='\033[0m'; BOLD='\033[1m'

PROJECT_DIR="$HOME/Dushyant_u23ai085_9256777500"
ENV_NAME="rlver_env"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NON_INTERACTIVE="${1:-}"

echo ""
echo -e "${RED}${BOLD}================================================================${NC}"
echo -e "${RED}${BOLD}  WARNING: This will DELETE the following completely:${NC}"
echo -e "${RED}${BOLD}    → $PROJECT_DIR  (ALL results, checkpoints, datasets)${NC}"
echo -e "${RED}${BOLD}    → conda env: $ENV_NAME${NC}"
echo -e "${RED}${BOLD}================================================================${NC}"
echo ""

# ── Confirmation ─────────────────────────────────────────────────────────────
if [ "$NON_INTERACTIVE" != "--yes" ]; then
    read -rp "  Type 'DELETE' to confirm: " CONFIRM
    if [ "$CONFIRM" != "DELETE" ]; then
        echo "  Cancelled."
        exit 0
    fi
else
    echo -e "${YLW}  --yes flag: proceeding without confirmation${NC}"
fi

# ── Step 1: Backup important results ────────────────────────────────────────
BACKUP_DIR="$HOME/.rlver_backup_$(date +%Y%m%d_%H%M%S)"
if [ -d "$PROJECT_DIR/results" ] && [ "$(ls -A "$PROJECT_DIR/results" 2>/dev/null)" ]; then
    echo -e "${GRN}[INFO]${NC}  Backing up results → $BACKUP_DIR/results"
    mkdir -p "$BACKUP_DIR"
    cp -r "$PROJECT_DIR/results" "$BACKUP_DIR/"
    echo -e "${GRN}[ OK ]${NC}  Results backed up"
fi
if [ -d "$PROJECT_DIR/logs" ] && [ "$(ls -A "$PROJECT_DIR/logs" 2>/dev/null)" ]; then
    mkdir -p "$BACKUP_DIR"
    cp -r "$PROJECT_DIR/logs" "$BACKUP_DIR/"
    echo -e "${GRN}[ OK ]${NC}  Logs backed up"
fi
if [ -d "$BACKUP_DIR" ]; then
    echo -e "${GRN}[ OK ]${NC}  Backup saved at: $BACKUP_DIR"
fi

# ── Step 2: Remove project directory ─────────────────────────────────────────
echo -e "${YLW}[INFO]${NC}  Removing: $PROJECT_DIR"
rm -rf "$PROJECT_DIR"
echo -e "${GRN}[ OK ]${NC}  Project directory removed"

# ── Step 3: Remove conda environment ─────────────────────────────────────────
CONDA_CMD=""
for conda_path in conda "$HOME/miniconda3/bin/conda" "$HOME/anaconda3/bin/conda" "/opt/conda/bin/conda"; do
    if command -v "$conda_path" &>/dev/null 2>&1; then
        CONDA_CMD="$conda_path"
        break
    fi
done

if [ -n "$CONDA_CMD" ]; then
    CONDA_BASE=$("$CONDA_CMD" info --base 2>/dev/null || echo "")
    if [ -n "$CONDA_BASE" ]; then
        # shellcheck disable=SC1091
        source "$CONDA_BASE/etc/profile.d/conda.sh" 2>/dev/null || true
    fi
    if conda env list 2>/dev/null | grep -q "^${ENV_NAME}\s"; then
        echo -e "${YLW}[INFO]${NC}  Removing conda env: $ENV_NAME"
        conda env remove -n "$ENV_NAME" -y
        echo -e "${GRN}[ OK ]${NC}  Conda env removed"
    else
        echo -e "${GRN}[ OK ]${NC}  Conda env $ENV_NAME not found (already clean)"
    fi
else
    echo -e "${YLW}[WARN]${NC}  conda not found — skipping env removal"
fi

# ── Step 4: Clean pip cache (optional, frees disk) ───────────────────────────
echo -e "${YLW}[INFO]${NC}  Clearing pip cache..."
pip cache purge 2>/dev/null || true
echo -e "${GRN}[ OK ]${NC}  Pip cache cleared"

# ── Step 5: Run fresh setup ──────────────────────────────────────────────────
echo ""
echo -e "${GRN}${BOLD}  Everything wiped. Running fresh setup...${NC}"
echo ""

SETUP_SCRIPT="$SCRIPT_DIR/00_setup.sh"
if [ -f "$SETUP_SCRIPT" ]; then
    bash "$SETUP_SCRIPT"
else
    echo -e "${RED}[FAIL]${NC}  00_setup.sh not found at $SETUP_SCRIPT"
    echo "  Make sure you extracted the ZIP first."
    echo "  Then run:  bash /path/to/extracted/00_setup.sh"
    exit 1
fi
