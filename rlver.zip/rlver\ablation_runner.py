"""
=============================================================================
RLVER — Ablation Runner
File  : ablation/ablation_runner.py
Author: Dushyant (u23ai085)

Runs a single ablation experiment end-to-end:
  1. Builds model, tokenizer, dataset according to AblationExperiment config
  2. Trains (or skips for zero_shot baselines)
  3. Evaluates on the RLVER eval set
  4. Saves result JSON to ablation_results/<exp_id>_<name>.json

Reuses all existing trainer/dataset/metric infrastructure without modification.

Design principles:
  - Every function call goes through the existing rlver_rl_train / custom-trainer
    APIs — no reimplementation of training logic here.
  - Results are saved immediately after evaluation so the run can be resumed
    if interrupted (skip_if_exists=True by default).
  - The runner is stateless: call run_experiment() and get a dict back.
=============================================================================
"""

from __future__ import annotations

import os
import sys
import json
import time
import random
import logging
from copy import deepcopy
from dataclasses import asdict
from typing import Optional, Dict, List, Tuple

import numpy as np
import torch

# ── Path setup ────────────────────────────────────────────────────────────────
PROJECT_ROOT = os.path.expanduser("~/Dushyant_u23ai085_9256777500")
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rlver_adversarial"))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rl_training"))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "ablation"))

# Local imports
from ablation_config import AblationExperiment, ABLATION_EVAL_SAMPLES

logger = logging.getLogger(__name__)

# ── Default output directory for ablation results ────────────────────────────
ABLATION_RESULTS_DIR = os.path.join(PROJECT_ROOT, "results", "ablation")
ABLATION_CKPT_DIR    = os.path.join(PROJECT_ROOT, "rl_training", "checkpoints", "ablation")


# ─────────────────────────────────────────────────────────────────────────────
# Convert AblationExperiment → TrainConfig
# ─────────────────────────────────────────────────────────────────────────────

def _ablation_to_train_config(exp: AblationExperiment):
    """
    Build a TrainConfig-compatible object from an AblationExperiment.
    We import TrainConfig lazily to avoid circular imports.
    """
    from rlver_rl_train import TrainConfig

    cfg = TrainConfig()

    # Identity
    cfg.algorithm        = exp.algorithm if exp.algorithm not in ("zero_shot", "reinforce") else "grpo"
    cfg.thinking_enabled = exp.thinking_enabled
    cfg.run_name         = f"ablation_{exp.exp_id}_{exp.name}"
    cfg.seed             = exp.seed

    # Model
    cfg.model_name_or_path = exp.model_name_or_path
    cfg.torch_dtype        = "bfloat16"
    cfg.use_lora           = exp.use_lora
    cfg.lora_r             = exp.lora_r
    cfg.lora_alpha         = exp.lora_alpha
    cfg.lora_dropout       = exp.lora_dropout

    # Data
    cfg.max_train_samples   = 4000      # reduced for ablation compute budget
    cfg.max_eval_samples    = ABLATION_EVAL_SAMPLES
    cfg.adversarial_ratio   = exp.adversarial_ratio
    cfg.cache_dir           = os.path.join(PROJECT_ROOT, "cache", "hf")

    # Training
    cfg.max_steps    = exp.max_steps
    cfg.save_steps   = max(500, exp.max_steps // 3)
    cfg.eval_steps   = max(250, exp.max_steps // 6)
    cfg.logging_steps = 25
    cfg.warmup_steps  = min(100, exp.max_steps // 10)
    cfg.bf16          = True
    cfg.wandb_enabled = False     # disable WandB for ablation runs

    # Output dir
    cfg.output_dir = os.path.join(
        ABLATION_CKPT_DIR,
        f"{exp.group_id}",
        f"{exp.exp_id}_{exp.name}",
    )

    # PPO
    cfg.ppo_learning_rate            = exp.ppo_learning_rate
    cfg.ppo_batch_size               = exp.ppo_batch_size
    cfg.ppo_mini_batch_size          = exp.ppo_mini_batch_size
    cfg.ppo_gradient_accumulation_steps = exp.ppo_gradient_accumulation
    cfg.ppo_num_epochs               = exp.ppo_num_epochs
    cfg.ppo_cliprange                = exp.ppo_cliprange
    cfg.ppo_vf_coef                  = exp.ppo_vf_coef
    cfg.ppo_ent_coef                 = exp.ppo_ent_coef
    cfg.ppo_init_kl_coef             = exp.ppo_init_kl_coef
    cfg.ppo_target_kl                = exp.ppo_target_kl
    cfg.ppo_gamma                    = 0.99
    cfg.ppo_lam                      = 0.95
    cfg.ppo_cliprange_value          = 0.2
    cfg.ppo_max_grad_norm            = 1.0

    # GRPO (also used for REINFORCE with G=1)
    cfg.grpo_learning_rate           = exp.grpo_learning_rate
    cfg.grpo_batch_size              = exp.grpo_batch_size
    cfg.grpo_gradient_accumulation_steps = exp.grpo_gradient_accumulation
    cfg.grpo_num_generations         = max(1, exp.grpo_num_generations)
    cfg.grpo_beta                    = exp.grpo_beta
    cfg.grpo_epsilon                 = exp.grpo_epsilon
    cfg.grpo_max_grad_norm           = 1.0

    # Generation
    cfg.max_new_tokens = exp.max_new_tokens
    cfg.temperature    = exp.temperature
    cfg.top_p          = exp.top_p

    # Reward
    cfg.reward_correct        = exp.reward_correct
    cfg.reward_wrong          = exp.reward_wrong
    cfg.reward_partial        = exp.reward_partial
    cfg.reward_format         = exp.reward_format
    cfg.reward_length_penalty = exp.reward_length_penalty
    cfg.reward_max_length     = exp.reward_max_length

    return cfg


# ─────────────────────────────────────────────────────────────────────────────
# Evaluation helper (shared by all algorithm types)
# ─────────────────────────────────────────────────────────────────────────────

@torch.no_grad()
def _evaluate_model_on_samples(
    model,
    tokenizer,
    eval_samples: List,
    thinking_enabled: bool,
    reward_cfg,
    max_new_tokens: int = 256,
    batch_size: int = 8,
    device: str = "cuda",
) -> Tuple[List[float], List[Dict]]:
    """
    Run batched greedy inference and score with reward_fn.
    Returns (rewards, components_list).
    """
    from dataset_builder import format_verification_prompt
    from reward_model import compute_rewards_batch

    model.eval()
    all_rewards    = []
    all_components = []

    for i in range(0, len(eval_samples), batch_size):
        batch_samples = eval_samples[i: i + batch_size]
        prompts = [
            format_verification_prompt(s, thinking_enabled=thinking_enabled)
            for s in batch_samples
        ]
        enc = tokenizer(
            prompts,
            return_tensors="pt",
            truncation=True,
            max_length=768,
            padding=True,
        ).to(device)

        Q = enc["input_ids"].shape[-1]
        out = model.generate(
            **enc,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )
        texts = [
            tokenizer.decode(out[j, Q:], skip_special_tokens=True).strip()
            for j in range(len(batch_samples))
        ]
        rewards, comps = compute_rewards_batch(
            raw_outputs=texts,
            true_labels=[s.label   for s in batch_samples],
            problems   =[s.problem for s in batch_samples],
            cfg=reward_cfg,
            thinking_enabled=thinking_enabled,
        )
        all_rewards.extend(rewards)
        all_components.extend(comps)

    model.train()
    return all_rewards, all_components


# ─────────────────────────────────────────────────────────────────────────────
# Full metrics from eval run
# ─────────────────────────────────────────────────────────────────────────────

def _compute_full_metrics(
    model,
    tokenizer,
    eval_samples: List,
    exp: AblationExperiment,
    reward_cfg,
    device: str = "cuda",
) -> Dict:
    """
    Run evaluation and return full EvalMetrics dict.
    """
    from metrics import (
        VerificationSample, compute_metrics,
        parse_model_output,
    )
    from reward_model import compute_rewards_batch
    from dataset_builder import format_verification_prompt

    model.eval()
    raw_outputs = []

    # Generate in batches of 8
    batch_size = 8
    for i in range(0, len(eval_samples), batch_size):
        sub = eval_samples[i: i + batch_size]
        prompts = [
            format_verification_prompt(s, thinking_enabled=exp.thinking_enabled)
            for s in sub
        ]
        enc = tokenizer(
            prompts, return_tensors="pt",
            truncation=True, max_length=768, padding=True,
        ).to(device)
        Q   = enc["input_ids"].shape[-1]
        out = model.generate(
            **enc, max_new_tokens=exp.max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )
        for j in range(len(sub)):
            raw_outputs.append(
                tokenizer.decode(out[j, Q:], skip_special_tokens=True).strip()
            )

    model.train()

    # Parse into VerificationSamples
    ver_samples = []
    for s, raw in zip(eval_samples, raw_outputs):
        pred, conf, thinking = parse_model_output(raw, thinking_enabled=exp.thinking_enabled)
        if pred is None:
            pred = 0
        ver_samples.append(VerificationSample(
            problem_id     = s.problem_id,
            problem        = s.problem,
            solution       = s.solution,
            label          = s.label,
            is_adversarial = s.is_adversarial,
            difficulty     = s.difficulty,
            predicted_label = pred,
            confidence     = conf,
            thinking_text  = thinking,
            raw_output     = raw,
        ))

    metrics = compute_metrics(
        samples          = ver_samples,
        model_name       = exp.model_name_or_path.split("/")[-1],
        algorithm        = exp.algorithm,
        thinking_enabled = exp.thinking_enabled,
        run_id           = exp.exp_id,
    )
    return metrics.to_dict()


# ─────────────────────────────────────────────────────────────────────────────
# Main AblationRunner class
# ─────────────────────────────────────────────────────────────────────────────

class AblationRunner:
    """
    Runs one AblationExperiment:
      1. Load model (+ apply LoRA if training)
      2. Train if algorithm != zero_shot
      3. Evaluate
      4. Save result JSON
      5. Unload model to free VRAM

    Usage:
        runner = AblationRunner(results_dir="results/ablation")
        result = runner.run(exp)   # AblationExperiment
    """

    def __init__(
        self,
        results_dir:    str  = ABLATION_RESULTS_DIR,
        skip_if_exists: bool = True,
        device:         str  = "cuda",
    ):
        self.results_dir    = results_dir
        self.skip_if_exists = skip_if_exists
        self.device         = device if torch.cuda.is_available() else "cpu"
        os.makedirs(results_dir, exist_ok=True)

    # ── Public entry point ────────────────────────────────────────────────────

    def run(self, exp: AblationExperiment) -> Dict:
        """
        Run the experiment and return the result dict.
        If skip_if_exists=True and the result JSON exists, loads and returns it.
        """
        result_path = os.path.join(self.results_dir, exp.result_filename())

        if self.skip_if_exists and os.path.isfile(result_path):
            logger.info(f"[{exp.exp_id}] Result exists, loading: {result_path}")
            with open(result_path) as f:
                return json.load(f)

        logger.info(
            f"\n{'='*60}\n"
            f"  Running ablation: {exp.exp_id} — {exp.name}\n"
            f"  Algorithm : {exp.algorithm}\n"
            f"  Thinking  : {exp.thinking_enabled}\n"
            f"  Steps     : {exp.max_steps}\n"
            f"{'='*60}"
        )

        _seed_everything(exp.seed)

        if exp.algorithm == "zero_shot":
            result = self._run_zero_shot(exp)
        elif exp.algorithm in ("grpo", "reinforce"):
            result = self._run_grpo(exp)
        elif exp.algorithm == "ppo":
            result = self._run_ppo(exp)
        else:
            raise ValueError(f"Unknown algorithm: {exp.algorithm}")

        # Attach ablation metadata
        result["ablation_meta"] = exp.to_dict()
        result["timestamp"]     = time.strftime("%Y-%m-%d %H:%M:%S")

        # Save
        with open(result_path, "w") as f:
            json.dump(result, f, indent=2)
        logger.info(f"[{exp.exp_id}] Result saved → {result_path}")

        return result

    # ── Zero-shot evaluation ─────────────────────────────────────────────────

    def _run_zero_shot(self, exp: AblationExperiment) -> Dict:
        """Load base model (no training) and evaluate directly."""
        from rlver_rl_train import resolve_model_path, load_tokenizer
        from reward_model import RewardConfig
        from dataset_builder import RLVERDatasetBuilder

        model_path = resolve_model_path(exp.model_name_or_path,
                                        os.path.join(PROJECT_ROOT, "models"))
        tokenizer  = load_tokenizer(model_path)

        from transformers import AutoModelForCausalLM
        model = AutoModelForCausalLM.from_pretrained(
            model_path, torch_dtype=torch.bfloat16,
            device_map="auto", trust_remote_code=True,
        )
        model.eval()

        eval_samples = self._load_eval_samples(exp)

        reward_cfg = RewardConfig(
            correct_verification    = exp.reward_correct,
            wrong_verification      = exp.reward_wrong,
            partial_reasoning       = exp.reward_partial,
            format_bonus            = exp.reward_format,
            length_penalty_coef     = exp.reward_length_penalty,
            max_length_no_penalty   = exp.reward_max_length,
            thinking_reward_enabled = exp.thinking_enabled,
        )

        metrics = _compute_full_metrics(
            model=model, tokenizer=tokenizer,
            eval_samples=eval_samples, exp=exp,
            reward_cfg=reward_cfg, device=self.device,
        )

        _unload_model(model)
        return metrics

    # ── GRPO / REINFORCE training + evaluation ────────────────────────────────

    def _run_grpo(self, exp: AblationExperiment) -> Dict:
        """Train with GRPO (or G=1 REINFORCE), then evaluate."""
        from rlver_rl_train import (
            resolve_model_path, load_tokenizer,
            load_model_with_lora, load_ref_model,
            build_dataloader, build_reward_cfg, TrainConfig,
        )
        from grpo_trainer_custom import RLVERGRPOTrainer
        from dataset_builder import RLVERDatasetBuilder

        cfg        = _ablation_to_train_config(exp)
        model_path = resolve_model_path(
            exp.model_name_or_path, os.path.join(PROJECT_ROOT, "models")
        )
        tokenizer  = load_tokenizer(model_path)
        model      = load_model_with_lora(model_path, cfg, torch.bfloat16)
        ref_model  = load_ref_model(model_path, torch.bfloat16)

        train_dl, _     = build_dataloader(
            cfg, "train", exp.thinking_enabled,
            exp.grpo_batch_size, cfg.max_train_samples
        )
        eval_samples    = self._load_eval_samples(exp)

        reward_cfg = build_reward_cfg(cfg)
        trainer    = RLVERGRPOTrainer(
            model=model, ref_model=ref_model, tokenizer=tokenizer,
            reward_cfg=reward_cfg,
            thinking_enabled  = exp.thinking_enabled,
            learning_rate     = exp.grpo_learning_rate,
            batch_size        = exp.grpo_batch_size,
            gradient_accumulation_steps = exp.grpo_gradient_accumulation,
            num_generations   = max(1, exp.grpo_num_generations),
            beta              = exp.grpo_beta,
            epsilon           = exp.grpo_epsilon,
            max_new_tokens    = exp.max_new_tokens,
            temperature       = exp.temperature,
            top_p             = exp.top_p,
            max_steps         = exp.max_steps,
            save_steps        = cfg.save_steps,
            eval_steps        = cfg.eval_steps,
            logging_steps     = cfg.logging_steps,
            warmup_steps      = cfg.warmup_steps,
            output_dir        = cfg.output_dir,
            wandb_enabled     = False,
        )
        trainer.train(train_dl, eval_samples[:100])   # smaller quick-eval during training

        # Full evaluation after training
        metrics = _compute_full_metrics(
            model=model, tokenizer=tokenizer,
            eval_samples=eval_samples, exp=exp,
            reward_cfg=reward_cfg, device=self.device,
        )
        _unload_model(model)
        _unload_model(ref_model)
        return metrics

    # ── PPO training + evaluation ─────────────────────────────────────────────

    def _run_ppo(self, exp: AblationExperiment) -> Dict:
        """Train with PPO, then evaluate."""
        from rlver_rl_train import (
            resolve_model_path, load_tokenizer,
            load_model_with_lora, load_ref_model,
            build_dataloader, build_reward_cfg, TrainConfig,
        )
        from ppo_trainer_custom import ActorCriticModel, RLVERPPOTrainer

        cfg        = _ablation_to_train_config(exp)
        model_path = resolve_model_path(
            exp.model_name_or_path, os.path.join(PROJECT_ROOT, "models")
        )
        tokenizer  = load_tokenizer(model_path)
        base_model = load_model_with_lora(model_path, cfg, torch.bfloat16)
        ref_model  = load_ref_model(model_path, torch.bfloat16)

        hidden_size  = base_model.config.hidden_size
        actor_critic = ActorCriticModel(base_model, hidden_size=hidden_size)

        train_dl, _  = build_dataloader(
            cfg, "train", exp.thinking_enabled,
            exp.ppo_batch_size, cfg.max_train_samples
        )
        eval_samples = self._load_eval_samples(exp)

        reward_cfg = build_reward_cfg(cfg)
        trainer    = RLVERPPOTrainer(
            actor_critic     = actor_critic,
            ref_model        = ref_model,
            tokenizer        = tokenizer,
            reward_cfg       = reward_cfg,
            thinking_enabled = exp.thinking_enabled,
            learning_rate    = exp.ppo_learning_rate,
            batch_size       = exp.ppo_batch_size,
            mini_batch_size  = exp.ppo_mini_batch_size,
            gradient_accumulation_steps = exp.ppo_gradient_accumulation,
            num_ppo_epochs   = exp.ppo_num_epochs,
            cliprange        = exp.ppo_cliprange,
            vf_coef          = exp.ppo_vf_coef,
            ent_coef         = exp.ppo_ent_coef,
            init_kl_coef     = exp.ppo_init_kl_coef,
            target_kl        = exp.ppo_target_kl,
            max_new_tokens   = exp.max_new_tokens,
            temperature      = exp.temperature,
            top_p            = exp.top_p,
            max_steps        = exp.max_steps,
            save_steps       = cfg.save_steps,
            eval_steps       = cfg.eval_steps,
            logging_steps    = cfg.logging_steps,
            warmup_steps     = cfg.warmup_steps,
            output_dir       = cfg.output_dir,
            wandb_enabled    = False,
        )
        trainer.train(train_dl, eval_samples[:100])

        # Full evaluation
        metrics = _compute_full_metrics(
            model=actor_critic.base_model, tokenizer=tokenizer,
            eval_samples=eval_samples, exp=exp,
            reward_cfg=reward_cfg, device=self.device,
        )
        _unload_model(actor_critic)
        _unload_model(ref_model)
        return metrics

    # ── Eval samples ──────────────────────────────────────────────────────────

    def _load_eval_samples(self, exp: AblationExperiment) -> List:
        """Load RLVER eval samples (use cache if available)."""
        from dataset_builder import RLVERDatasetBuilder

        cache_path = os.path.join(PROJECT_ROOT, "cache", "datasets", "rlver_eval.jsonl")
        builder    = RLVERDatasetBuilder(
            adversarial_ratio=exp.adversarial_ratio,
            cache_dir=os.path.join(PROJECT_ROOT, "cache", "hf"),
            seed=exp.seed,
        )

        if os.path.isfile(cache_path):
            samples = builder.load_jsonl(cache_path)
        else:
            samples = builder.build(split="test", max_samples=None)

        # Use consistent subset
        random.seed(exp.seed)
        random.shuffle(samples)
        return samples[:ABLATION_EVAL_SAMPLES]


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _unload_model(model) -> None:
    try:
        del model
    except Exception:
        pass
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


# ─────────────────────────────────────────────────────────────────────────────
# CLI: run a single experiment by exp_id
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(message)s",
        datefmt="%H:%M:%S",
    )
    os.makedirs(os.path.join(PROJECT_ROOT, "logs"), exist_ok=True)

    parser = argparse.ArgumentParser(description="Run single RLVER ablation experiment")
    parser.add_argument("exp_id", type=str,
                        help="Experiment ID, e.g. A1, B7, E3")
    parser.add_argument("--results_dir", type=str, default=ABLATION_RESULTS_DIR)
    parser.add_argument("--no_skip", action="store_true",
                        help="Re-run even if result file exists")
    args = parser.parse_args()

    from ablation_config import get_experiment_config
    exp    = get_experiment_config(args.exp_id)
    runner = AblationRunner(
        results_dir=args.results_dir,
        skip_if_exists=not args.no_skip,
    )
    result = runner.run(exp)
    print(f"\nResult for {exp.exp_id} ({exp.name}):")
    print(f"  Verification Accuracy : {result.get('verification_accuracy',0)*100:.2f}%")
    print(f"  F1 Score              : {result.get('f1_score',0)*100:.2f}%")
    print(f"  Adversarial Accuracy  : {result.get('adversarial_accuracy',0)*100:.2f}%")
    print(f"  TQS                   : {result.get('thinking_quality_score',0):.4f}")
    print(f"  ECE                   : {result.get('expected_calibration_error',0):.4f}")
