#!/bin/bash
# =============================================================================
# RLVER — Evaluation Runner
# File   : scripts/03_run_eval.sh
# Author : Dushyant (u23ai085)
#
# Evaluates all RLVER variants and produces comparison table.
#
# Usage:
#   bash scripts/03_run_eval.sh              # eval all variants + compare
#   bash scripts/03_run_eval.sh single       # single model eval (interactive)
#   bash scripts/03_run_eval.sh compare      # compare existing result JSONs
# =============================================================================

set -e

MODE="${1:-all}"
PROJECT_ROOT="$HOME/Dushyant_u23ai085_9256777500"
EVAL_SCRIPT="$PROJECT_ROOT/rlver_adversarial/rlver_eval.py"
RESULTS_DIR="$PROJECT_ROOT/results"
LOG_DIR="$PROJECT_ROOT/logs"

mkdir -p "$RESULTS_DIR" "$LOG_DIR"

echo ""
echo "=================================================================="
echo "  RLVER Evaluation Runner"
echo "  Mode    : $MODE"
echo "  Started : $(date)"
echo "=================================================================="

if [ "$MODE" = "all" ]; then
    echo "[INFO] Evaluating all RLVER variants ..."

    conda run -n rlver_env python "$EVAL_SCRIPT" all \
        --results_dir "$RESULTS_DIR" \
        --max_eval_samples 1319 \
        --eval_batch_size 16 \
        --seed 42 \
        2>&1 | tee "$LOG_DIR/eval_all.log"

    echo ""
    echo "[INFO] Generating comparison table ..."
    conda run -n rlver_env python "$EVAL_SCRIPT" compare \
        "$RESULTS_DIR"/*.json \
        2>&1 | tee "$LOG_DIR/comparison.log"

elif [ "$MODE" = "single" ]; then
    read -rp "Model path: " MODEL_PATH
    read -rp "Enable thinking? (y/n): " THINK_INPUT
    read -rp "Algorithm (baseline/ppo/grpo): " ALGORITHM

    THINK_FLAG=""
    if [ "$THINK_INPUT" = "y" ]; then THINK_FLAG="--thinking"; fi

    conda run -n rlver_env python "$EVAL_SCRIPT" single \
        --model_path "$MODEL_PATH" \
        $THINK_FLAG \
        --algorithm "$ALGORITHM" \
        --max_samples 500 \
        --eval_batch_size 8 \
        --save_path "$RESULTS_DIR/custom_eval_$(date +%Y%m%d_%H%M%S).json" \
        2>&1 | tee "$LOG_DIR/eval_single.log"

elif [ "$MODE" = "compare" ]; then
    echo "[INFO] Comparing all result JSONs in $RESULTS_DIR ..."
    conda run -n rlver_env python "$EVAL_SCRIPT" compare \
        "$RESULTS_DIR"/*.json

else
    echo "[ERROR] Unknown mode: $MODE"
    echo "Usage: $0 [all|single|compare]"
    exit 1
fi

echo ""
echo "=================================================================="
echo "  Evaluation DONE at $(date)"
echo "  Results : $RESULTS_DIR"
echo "  Logs    : $LOG_DIR/eval_all.log"
echo "=================================================================="
