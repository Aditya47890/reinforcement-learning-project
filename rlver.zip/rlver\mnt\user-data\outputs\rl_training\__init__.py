"""
RLVER RL Training Package
==========================
Submodules
----------
reward_model
    RewardConfig, RLVERRewardFunction,
    compute_reward, compute_rewards_batch, compute_returns

ppo_trainer_custom
    ValueHead, ActorCriticModel,
    RolloutSample, RolloutBuffer, KLController,
    compute_ppo_loss, RLVERPPOTrainer

grpo_trainer_custom
    GroupSample, compute_grpo_loss, RLVERGRPOTrainer

rlver_rl_train
    TrainConfig, run_ppo_training, run_grpo_training,
    resolve_model_path, build_dataloader
"""

from .reward_model import (
    RewardConfig,
    RLVERRewardFunction,
    compute_reward,
    compute_rewards_batch,
    compute_returns,
)

from .ppo_trainer_custom import (
    ValueHead,
    ActorCriticModel,
    RolloutSample,
    RolloutBuffer,
    KLController,
    compute_ppo_loss,
    RLVERPPOTrainer,
)

from .grpo_trainer_custom import (
    GroupSample,
    compute_grpo_loss,
    RLVERGRPOTrainer,
)

__version__ = "1.0.0"
__author__  = "Dushyant (u23ai085)"
__all__ = [
    # reward_model
    "RewardConfig", "RLVERRewardFunction",
    "compute_reward", "compute_rewards_batch", "compute_returns",
    # ppo_trainer_custom
    "ValueHead", "ActorCriticModel",
    "RolloutSample", "RolloutBuffer", "KLController",
    "compute_ppo_loss", "RLVERPPOTrainer",
    # grpo_trainer_custom
    "GroupSample", "compute_grpo_loss", "RLVERGRPOTrainer",
]
