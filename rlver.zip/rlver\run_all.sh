#!/bin/bash
# =============================================================================
# RLVER — Master Run Script
# File  : run_all.sh
# Author: Dushyant (u23ai085)
#
# Runs the complete RLVER pipeline in order:
#   1. Data preparation
#   2. Training (all 4 variants)
#   3. Evaluation
#   4. Results analysis
#   5. Ablation study
#
# Usage:
#   bash run_all.sh                         # full pipeline
#   bash run_all.sh --from training         # skip data prep
#   bash run_all.sh --from eval             # skip data + training
#   bash run_all.sh --from analysis         # only analysis + ablation
#   bash run_all.sh --only ablation         # only ablation study
#   bash run_all.sh --gen_adversarial       # use Mistral for adversarials
# =============================================================================

set -euo pipefail

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
BLU='\033[0;34m'; NC='\033[0m'; BOLD='\033[1m'

PROJECT_DIR="$HOME/Dushyant_u23ai085_9256777500"
ENV_NAME="rlver_env"
LOG_DIR="$PROJECT_DIR/logs"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
MASTER_LOG="$LOG_DIR/run_all_${TIMESTAMP}.log"

# ── Parse args ────────────────────────────────────────────────────────────────
FROM_STAGE="data"
ONLY_STAGE=""
GEN_ADVERSARIAL=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --from)      FROM_STAGE="$2";    shift 2 ;;
        --only)      ONLY_STAGE="$2";   shift 2 ;;
        --gen_adversarial) GEN_ADVERSARIAL="--gen_adversarial"; shift ;;
        *) echo "Unknown arg: $1"; shift ;;
    esac
done

# ── Stage skip logic ──────────────────────────────────────────────────────────
should_run() {
    local stage="$1"
    local order=("data" "training" "eval" "analysis" "ablation")
    if [ -n "$ONLY_STAGE" ]; then
        [ "$stage" = "$ONLY_STAGE" ]
        return
    fi
    for i in "${!order[@]}"; do
        if [ "${order[$i]}" = "$FROM_STAGE" ]; then
            local from_idx=$i
        fi
        if [ "${order[$i]}" = "$stage" ]; then
            local stage_idx=$i
        fi
    done
    [ "${stage_idx:-99}" -ge "${from_idx:-0}" ]
}

# ── Activate environment ──────────────────────────────────────────────────────
CONDA_BASE=""
for conda_path in "$HOME/miniconda3/bin/conda" "$HOME/anaconda3/bin/conda" \
                  "/opt/conda/bin/conda" "$(command -v conda 2>/dev/null)"; do
    if [ -n "$conda_path" ] && [ -f "$conda_path" ]; then
        CONDA_BASE="$(dirname "$(dirname "$conda_path")")"
        break
    fi
done

if [ -z "$CONDA_BASE" ]; then
    echo -e "${RED}[FAIL]${NC}  conda not found. Run 00_setup.sh first."
    exit 1
fi
# shellcheck disable=SC1091
source "$CONDA_BASE/etc/profile.d/conda.sh"
conda activate "$ENV_NAME" || { echo -e "${RED}[FAIL]${NC}  Cannot activate $ENV_NAME. Run 00_setup.sh first."; exit 1; }

# ── Setup ─────────────────────────────────────────────────────────────────────
mkdir -p "$LOG_DIR"
cd "$PROJECT_DIR"

step()  { echo -e "\n${BOLD}${BLU}▶ $*${NC}"; }
ok()    { echo -e "${GRN}✓ $*${NC}"; }
fail()  { echo -e "${RED}✗ $*${NC}"; }

# ── Header ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}================================================================${NC}"
echo -e "${BOLD}  RLVER — Complete Pipeline${NC}"
echo -e "${BOLD}  Started: $(date)${NC}"
echo -e "${BOLD}  From stage: $FROM_STAGE${NC}"
[ -n "$ONLY_STAGE" ] && echo -e "${BOLD}  Only stage: $ONLY_STAGE${NC}"
echo -e "${BOLD}  Log: $MASTER_LOG${NC}"
echo -e "${BOLD}================================================================${NC}"

# All output also goes to master log
exec > >(tee -a "$MASTER_LOG") 2>&1

PIPELINE_START=$(date +%s)
STAGE_STATUS=()

run_stage() {
    local name="$1"
    local cmd="$2"
    local log="$LOG_DIR/${name}_${TIMESTAMP}.log"

    step "STAGE: $name"
    echo "  Command: $cmd"
    echo "  Log: $log"
    echo ""

    local start=$(date +%s)
    if eval "$cmd" 2>&1 | tee "$log"; then
        local elapsed=$(( $(date +%s) - start ))
        ok "$name complete  (${elapsed}s)"
        STAGE_STATUS+=("✓ $name (${elapsed}s)")
    else
        local elapsed=$(( $(date +%s) - start ))
        fail "$name FAILED  (${elapsed}s)"
        STAGE_STATUS+=("✗ $name FAILED")
        echo ""
        echo "  Check log: $log"
        echo "  Last 20 lines:"
        tail -20 "$log" 2>/dev/null || true
        return 1
    fi
}

# ── STAGE 1: Data ─────────────────────────────────────────────────────────────
if should_run "data"; then
    run_stage "01_data" \
        "python scripts/01_download_data.py $GEN_ADVERSARIAL --preview_prompts"
fi

# ── STAGE 2: Training ─────────────────────────────────────────────────────────
if should_run "training"; then
    run_stage "02_training" "bash scripts/02_run_training.sh"
fi

# ── STAGE 3: Evaluation ───────────────────────────────────────────────────────
if should_run "eval"; then
    run_stage "03_eval" "bash scripts/03_run_eval.sh"
fi

# ── STAGE 4: Analysis ─────────────────────────────────────────────────────────
if should_run "analysis"; then
    run_stage "04_analysis" \
        "python scripts/04_analyze_results.py --training_logs"
fi

# ── STAGE 5: Ablation ─────────────────────────────────────────────────────────
if should_run "ablation"; then
    run_stage "05_ablation" "bash scripts/05_run_ablations.sh"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
TOTAL_ELAPSED=$(( $(date +%s) - PIPELINE_START ))
TOTAL_H=$(( TOTAL_ELAPSED / 3600 ))
TOTAL_M=$(( (TOTAL_ELAPSED % 3600) / 60 ))

echo ""
echo -e "${BOLD}================================================================${NC}"
echo -e "${BOLD}  RLVER Pipeline Summary${NC}"
echo -e "${BOLD}  Total time: ${TOTAL_H}h ${TOTAL_M}m${NC}"
echo -e "${BOLD}================================================================${NC}"
for s in "${STAGE_STATUS[@]}"; do
    echo "  $s"
done
echo ""
echo -e "${BOLD}  Results:      $PROJECT_DIR/results/${NC}"
echo -e "${BOLD}  Ablation:     $PROJECT_DIR/results/ablation/${NC}"
echo -e "${BOLD}  Checkpoints:  $PROJECT_DIR/rl_training/checkpoints/${NC}"
echo -e "${BOLD}  Logs:         $LOG_DIR/${NC}"
echo -e "${BOLD}================================================================${NC}"
echo ""
