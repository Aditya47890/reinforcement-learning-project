# RLVER — Reinforcement Learning for Verification

**Dushyant | u23ai085 | 9256777500**

---

## Project Overview

RLVER trains a language model (Qwen2.5-7B-Instruct) to **verify mathematical solutions** using Reinforcement Learning. The model learns to correctly judge whether a proposed solution to a GSM8K math problem is correct or adversarially wrong.

### Four Training Variants

| Variant | Algorithm | Thinking | Description |
|---|---|---|---|
| PPO + Thinking | PPO | ✓ | Policy + value head, chain-of-thought reasoning rewarded |
| PPO No-Think | PPO | ✗ | Policy + value head, direct verdict only |
| GRPO + Thinking | GRPO | ✓ | Group-relative, G=8 completions/prompt, CoT rewarded |
| GRPO No-Think | GRPO | ✗ | Group-relative, direct verdict only |

### Hardware

- **GPU**: NVIDIA RTX PRO 4500 Blackwell, 33.7 GB VRAM
- **OS**: Ubuntu 24
- **CUDA**: 12.4

---

## Directory Structure

```
~/Dushyant_u23ai085_9256777500/
├── 00_setup.sh                      # Environment setup (run first)
├── configs/
│   ├── ppo_config.yaml              # PPO hyperparameters
│   ├── grpo_config.yaml             # GRPO hyperparameters
│   └── run_config.json              # Auto-generated data paths (after step 2)
├── scripts/
│   ├── 01_download_data.py          # Download GSM8K + build RLVER datasets
│   ├── 02_run_training.sh           # Run all 4 training variants
│   ├── 03_run_eval.sh               # Evaluate all variants
│   └── 04_analyze_results.py        # Generate plots and comparison table
├── rlver_adversarial/               # Evaluation package
│   ├── __init__.py
│   ├── dataset_builder.py           # GSM8K loader + adversarial dataset builder
│   ├── adversarial_gen.py           # Mistral-7B adversarial solution generator
│   ├── metrics.py                   # Accuracy, F1, TQS, ECE, adversarial robustness
│   └── rlver_eval.py                # Evaluation CLI (single / all / compare)
├── rl_training/                     # Training package
│   ├── __init__.py
│   ├── reward_model.py              # 4-component reward function
│   ├── ppo_trainer_custom.py        # Custom PPO: ActorCritic, RolloutBuffer, GAE, KL
│   ├── grpo_trainer_custom.py       # Custom GRPO: group sampling, token-level loss
│   └── rlver_rl_train.py            # Unified training entry point (PPO + GRPO)
├── models/
│   ├── qwen_1p5b/                   # Qwen2.5-1.5B-Instruct (downloaded by setup)
│   ├── qwen_7b/                     # Qwen2.5-7B-Instruct (downloaded by setup)
│   └── mistral_7b_sim/              # Mistral-7B-Instruct-v0.3 (adversary)
├── cache/
│   ├── hf/                          # HuggingFace dataset cache
│   └── datasets/
│       ├── rlver_train.jsonl        # Built by 01_download_data.py
│       └── rlver_eval.jsonl         # Built by 01_download_data.py
├── rl_training/checkpoints/         # Training checkpoints
│   ├── ppo/thinking/
│   ├── ppo/non_thinking/
│   ├── grpo/thinking/
│   └── grpo/non_thinking/
├── results/                         # Evaluation JSON files + plots
│   └── plots/
└── logs/                            # Training & evaluation logs
```

---

## Quick Start

### Step 0 — Environment Setup (one time only)

```bash
bash 00_setup.sh
conda activate rlver_env
```

This installs all dependencies and downloads the three base models (~30 GB total).

### Step 1 — Prepare Data

```bash
conda activate rlver_env
cd ~/Dushyant_u23ai085_9256777500

# Fast: rule-based adversarials (~2 min)
python scripts/01_download_data.py --preview_prompts

# Full quality: Mistral-7B adversarials (~45 min on GPU)
python scripts/01_download_data.py --gen_adversarial --preview_prompts
```

This builds `cache/datasets/rlver_train.jsonl` (≈ 10,400 samples) and `rlver_eval.jsonl` (≈ 1,850 samples).

### Step 2 — Train

```bash
# All 4 variants sequentially (recommended — runs overnight)
bash scripts/02_run_training.sh

# OR individual variants
python rl_training/rlver_rl_train.py --algorithm grpo --thinking --no_wandb
python rl_training/rlver_rl_train.py --algorithm grpo --no_wandb
python rl_training/rlver_rl_train.py --algorithm ppo  --thinking --no_wandb
python rl_training/rlver_rl_train.py --algorithm ppo  --no_wandb
```

Training flags:

| Flag | Description |
|---|---|
| `--algorithm ppo\|grpo` | Which RL algorithm to use |
| `--thinking` | Enable chain-of-thought thinking mode |
| `--config <yaml>` | Override default YAML config |
| `--max_steps N` | Override training steps |
| `--no_wandb` | Disable W&B logging |

Checkpoints saved to `rl_training/checkpoints/<algorithm>/<thinking|non_thinking>/`.

### Step 3 — Evaluate

```bash
# Evaluate all 6 variants (baselines + 4 RL-trained)
bash scripts/03_run_eval.sh

# Single model
python rlver_adversarial/rlver_eval.py single \
    --model_path models/qwen_7b \
    --algorithm baseline \
    --max_samples 500

# Compare two saved results
python rlver_adversarial/rlver_eval.py compare \
    results/baseline_7b.json results/grpo_thinking.json
```

### Step 4 — Analyze Results

```bash
python scripts/04_analyze_results.py
python scripts/04_analyze_results.py --training_logs   # include training curves
```

Generates 6–7 plots in `results/plots/` and prints a comparison table to terminal.

---

## Model Architecture

### Policy Model (PPO / GRPO)

```
Qwen2.5-7B-Instruct
  └─ LoRA adapters (r=64, α=128) on all attention + MLP projections
     └─ Trainable parameters: ~67M / 7.6B total (≈ 0.9%)
```

### PPO: Actor-Critic

```
Shared transformer backbone (Qwen-7B + LoRA)
  ├─ Logit head  → policy π_θ(a|s)
  └─ Value head  → V(s)  [small linear layer, initialized near-zero]

Reference model: frozen Qwen-7B (no LoRA), for KL penalty
```

### GRPO: Group Sampling

```
For each prompt q:
  Sample G=8 completions from π_θ
  Score each: r_1 ... r_8 via reward_fn
  Normalize: A_i = (r_i - μ) / σ
  Token-level loss: min(ρ·A, clip(ρ,1-ε,1+ε)·A) + β·KL(π_θ‖π_ref)
```

---

## Reward Function

```
R_total = R_verification + R_reasoning + R_format + R_length_penalty
  R_verification  ∈ {+1.0, -1.0}   correct/wrong binary decision
  R_reasoning     ∈ [0, +0.3]       chain-of-thought quality (thinking mode)
  R_format        ∈ {0, +0.1}       VERDICT: + CONFIDENCE: present
  R_length_penalty ∈ [-0.3, 0]      penalise excessively long outputs

Final range: clipped to [-1.0, +1.0]
```

---

## Dataset

| Split | Problems | Clean (label=1) | Adversarial (label=0) |
|---|---|---|---|
| Train | 7,473 | 7,473 | ~2,989 (40%) |
| Eval  | 1,319 | 1,319 | ~  528 (40%) |

**Source**: `openai/gsm8k` via HuggingFace Datasets.

**Adversarial strategies** (Mistral-7B-Instruct):
- `WRONG_FINAL` — correct steps, wrong arithmetic at the end (35%)
- `WRONG_STEP` — subtle error in one intermediate step (30%)
- `WRONG_SETUP` — misinterprets the problem structure (15%)
- `MISSING_STEP` — omits a required computation (12%)
- `UNIT_ERROR` — correct numbers, wrong units/conversion (8%)

---

## Metrics

| Metric | Description |
|---|---|
| **Verification Accuracy** | % of correct verify/reject decisions |
| **F1 Score** | harmonic mean of precision & recall (binary) |
| **Adversarial Accuracy** | accuracy on adversarial subset only |
| **TQS** | Thinking Quality Score: length, structure, math content, problem reference |
| **ECE** | Expected Calibration Error (lower = better calibrated) |
| **ROC-AUC** | area under ROC curve |

---

## Key Hyperparameters

### PPO

| Parameter | Value |
|---|---|
| Learning rate | 1e-5 |
| Batch size | 8 |
| Mini-batch size | 4 |
| PPO epochs / rollout | 4 |
| Clip range ε | 0.2 |
| KL target | 6.0 (adaptive) |
| γ (discount) | 0.99 |
| λ (GAE) | 0.95 |

### GRPO

| Parameter | Value |
|---|---|
| Learning rate | 5e-6 |
| Group size G | 8 |
| KL penalty β | 0.04 |
| Clip range ε | 0.2 |
| Gradient accumulation | 8 |

---

## Troubleshooting

**Out of GPU memory**
```bash
# Reduce batch size in the YAML config:
# ppo/batch_size: 4  (from 8)
# grpo/batch_size: 2 (from 4)
# grpo/num_generations: 4 (from 8)
```

**CUDA not found**
```bash
pip install torch --index-url https://download.pytorch.org/whl/cu124
python -c "import torch; print(torch.cuda.is_available())"
```

**HuggingFace download fails**
```bash
# Set HF_HUB_OFFLINE=0 and check network
# Or pre-download models manually:
huggingface-cli download Qwen/Qwen2.5-7B-Instruct \
    --local-dir ~/Dushyant_u23ai085_9256777500/models/qwen_7b
```

**W&B login**
```bash
wandb login        # paste your API key
# Or disable: --no_wandb flag on training commands
```

**Re-run data preparation (force regenerate)**
```bash
python scripts/01_download_data.py --force --gen_adversarial
```

---

## Environment

```
Python     : 3.11
PyTorch    : ≥ 2.6.0 (CUDA 12.4)
Transformers: 4.51.3
TRL        : 0.16.1
PEFT       : 0.15.0
Accelerate : 1.6.0
Datasets   : 3.6.0
```

Full pinned requirements: `configs/requirements.txt` (generated by `00_setup.sh`).

---

## Author

**Dushyant** | u23ai085 | 9256777500
