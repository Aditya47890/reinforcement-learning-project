"""
=============================================================================
RLVER — Main Evaluation Script
File  : rlver_adversarial/rlver_eval.py
Author: Dushyant (u23ai085)

Evaluates RLVER model checkpoints on the GSM8K verification task.

Subcommands:
  single   — evaluate one model checkpoint
  all      — evaluate all six RLVER variants and print comparison table
  compare  — compare previously saved result JSON files

Usage:
  conda activate rlver_env
  cd ~/Dushyant_u23ai085_9256777500

  # Single model
  python rlver_adversarial/rlver_eval.py single \
      --model_path models/qwen_7b --thinking --algorithm baseline

  # All variants (runs training checkpoints if they exist)
  python rlver_adversarial/rlver_eval.py all

  # Compare two saved JSON results
  python rlver_adversarial/rlver_eval.py compare \
      results/baseline_7b.json results/grpo_thinking.json
=============================================================================
"""

from __future__ import annotations

import os
import sys
import re
import json
import time
import random
import logging
import argparse
from pathlib import Path
from typing import List, Optional, Dict, Tuple

import torch
import numpy as np
from tqdm import tqdm
from transformers import AutoTokenizer, AutoModelForCausalLM

# ── Path setup ────────────────────────────────────────────────────────────────
PROJECT_ROOT = os.path.expanduser("~/Dushyant_u23ai085_9256777500")
sys.path.insert(0, os.path.dirname(__file__))            # rlver_adversarial/
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rl_training"))

from metrics import (
    EvalMetrics,
    VerificationSample,
    compute_metrics,
    parse_model_output,
    save_metrics,
    load_metrics,
    compare_metrics,
)
from dataset_builder import (
    RLVERDatasetBuilder,
    RLVERSample,
    format_verification_prompt,
)

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

LOCAL_ALIASES = {
    "qwen_1p5b": "Qwen/Qwen2.5-1.5B-Instruct",
    "qwen_7b":   "Qwen/Qwen2.5-7B-Instruct",
}

# Six evaluation variants: (variant_name, local_alias, thinking, algorithm, ckpt_subdir)
EVAL_VARIANTS = [
    ("baseline_1p5b",    "qwen_1p5b", False, "baseline", None),
    ("baseline_7b",      "qwen_7b",   False, "baseline", None),
    ("ppo_thinking",     "qwen_7b",   True,  "ppo",      "ppo/thinking/best_model"),
    ("ppo_non_thinking", "qwen_7b",   False, "ppo",      "ppo/non_thinking/best_model"),
    ("grpo_thinking",    "qwen_7b",   True,  "grpo",     "grpo/thinking/best_model"),
    ("grpo_non_thinking","qwen_7b",   False, "grpo",     "grpo/non_thinking/best_model"),
]


# ─────────────────────────────────────────────────────────────────────────────
# Model path resolver
# ─────────────────────────────────────────────────────────────────────────────

def resolve_model_path(
    model_identifier: str,
    checkpoint_subdir: Optional[str] = None,
) -> str:
    """
    Resolve model path in priority order:
      1. RL training checkpoint (if checkpoint_subdir given and exists)
      2. Local model cache (~/models/<alias>)
      3. As-is (HF hub ID or absolute path)
    """
    local_models = os.path.join(PROJECT_ROOT, "models")
    ckpt_root    = os.path.join(PROJECT_ROOT, "rl_training", "checkpoints")

    # 1. RL checkpoint
    if checkpoint_subdir:
        ckpt_path = os.path.join(ckpt_root, checkpoint_subdir)
        if os.path.isdir(ckpt_path):
            logger.info(f"Using RL checkpoint: {ckpt_path}")
            return ckpt_path

    # 2. Local alias
    if model_identifier in LOCAL_ALIASES:
        local_path = os.path.join(local_models, model_identifier)
        if os.path.isdir(local_path):
            logger.info(f"Using local cache: {local_path}")
            return local_path
        logger.info(f"Local cache not found, using HF hub: {LOCAL_ALIASES[model_identifier]}")
        return LOCAL_ALIASES[model_identifier]

    # 3. Absolute path or HF ID
    expanded = os.path.expanduser(model_identifier)
    if os.path.isdir(expanded):
        return expanded
    return model_identifier


# ─────────────────────────────────────────────────────────────────────────────
# Lightweight eval model wrapper
# ─────────────────────────────────────────────────────────────────────────────

class EvalModel:
    """
    Loads a CausalLM (or LoRA checkpoint) for inference only.
    Supports both base models and PEFT adapter directories.
    """

    def __init__(
        self,
        model_path: str,
        torch_dtype: torch.dtype = torch.bfloat16,
        device: str = "cuda",
    ):
        self.model_path  = model_path
        self.torch_dtype = torch_dtype
        self.device      = device
        self._tokenizer  = None
        self._model      = None

    def load(self) -> None:
        logger.info(f"Loading eval model: {self.model_path}")
        t0 = time.time()

        self._tokenizer = AutoTokenizer.from_pretrained(
            self.model_path, trust_remote_code=True, padding_side="left"
        )
        if self._tokenizer.pad_token is None:
            self._tokenizer.pad_token = self._tokenizer.eos_token

        # Handle PEFT/LoRA checkpoint directories
        peft_config_path = os.path.join(self.model_path, "adapter_config.json")
        if os.path.isfile(peft_config_path):
            from peft import PeftModel, PeftConfig
            peft_cfg   = PeftConfig.from_pretrained(self.model_path)
            base_model = AutoModelForCausalLM.from_pretrained(
                peft_cfg.base_model_name_or_path,
                torch_dtype=self.torch_dtype,
                device_map="auto",
                trust_remote_code=True,
            )
            self._model = PeftModel.from_pretrained(base_model, self.model_path)
            self._model = self._model.merge_and_unload()   # merge LoRA for faster inference
        else:
            self._model = AutoModelForCausalLM.from_pretrained(
                self.model_path,
                torch_dtype=self.torch_dtype,
                device_map="auto",
                trust_remote_code=True,
            )

        self._model.eval()
        logger.info(f"Eval model loaded in {time.time()-t0:.1f}s")

    def unload(self) -> None:
        del self._model, self._tokenizer
        self._model = self._tokenizer = None
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        logger.info("Eval model unloaded.")

    @torch.no_grad()
    def generate_batch(
        self,
        prompts: List[str],
        max_new_tokens: int = 256,
        batch_size: int = 8,
    ) -> List[str]:
        """
        Greedy generation for evaluation (do_sample=False for determinism).
        Returns list of generated strings (prompt NOT included).
        """
        outputs = []
        for i in range(0, len(prompts), batch_size):
            batch = prompts[i: i + batch_size]

            enc = self._tokenizer(
                batch,
                return_tensors="pt",
                truncation=True,
                max_length=768,
                padding=True,
            ).to(self.device)

            Q = enc["input_ids"].shape[-1]

            out_ids = self._model.generate(
                **enc,
                max_new_tokens=max_new_tokens,
                do_sample=False,                    # deterministic greedy eval
                pad_token_id=self._tokenizer.eos_token_id,
                eos_token_id=self._tokenizer.eos_token_id,
            )

            # Decode only generated tokens
            for out in out_ids:
                text = self._tokenizer.decode(
                    out[Q:], skip_special_tokens=True
                )
                outputs.append(text.strip())

        return outputs


# ─────────────────────────────────────────────────────────────────────────────
# Core evaluation loop
# ─────────────────────────────────────────────────────────────────────────────

def evaluate_model(
    model_path: str,
    samples: List[RLVERSample],
    thinking_enabled: bool = True,
    algorithm: str = "baseline",
    run_id: str = "",
    eval_batch_size: int = 8,
    max_new_tokens: int = 256,
) -> EvalMetrics:
    """
    Full evaluation pipeline for one model on the RLVER dataset.
    """
    model_name = os.path.basename(model_path.rstrip("/"))
    logger.info(
        f"\n{'='*60}\n"
        f"  Evaluating : {model_name}\n"
        f"  Algorithm  : {algorithm}\n"
        f"  Thinking   : {'ON' if thinking_enabled else 'OFF'}\n"
        f"  Samples    : {len(samples)}\n"
        f"{'='*60}"
    )

    # Build prompts
    prompts = [
        format_verification_prompt(s, thinking_enabled=thinking_enabled)
        for s in samples
    ]

    # Load → generate → unload
    eval_model = EvalModel(model_path=model_path)
    eval_model.load()
    t0 = time.time()
    raw_outputs = eval_model.generate_batch(
        prompts=prompts,
        max_new_tokens=max_new_tokens,
        batch_size=eval_batch_size,
    )
    elapsed = time.time() - t0
    logger.info(f"Generation: {elapsed:.1f}s ({elapsed/len(prompts):.2f}s/sample)")
    eval_model.unload()

    # Parse outputs → VerificationSamples
    eval_samples  = []
    n_unparseable = 0

    for sample, raw_out in zip(samples, raw_outputs):
        pred_label, confidence, thinking_text = parse_model_output(
            raw_out, thinking_enabled=thinking_enabled
        )
        if pred_label is None:
            pred_label = 0        # default: say incorrect when unparseable
            n_unparseable += 1

        eval_samples.append(VerificationSample(
            problem_id    = sample.problem_id,
            problem       = sample.problem,
            solution      = sample.solution,
            label         = sample.label,
            is_adversarial = sample.is_adversarial,
            difficulty    = sample.difficulty,
            predicted_label = pred_label,
            confidence    = confidence,
            thinking_text = thinking_text,
            raw_output    = raw_out,
        ))

    logger.info(
        f"Unparseable: {n_unparseable}/{len(samples)} "
        f"({100*n_unparseable/max(len(samples),1):.1f}%)"
    )

    # Compute metrics
    metrics = compute_metrics(
        samples         = eval_samples,
        model_name      = model_name,
        algorithm       = algorithm,
        thinking_enabled = thinking_enabled,
        run_id          = run_id,
    )
    logger.info(metrics.summary())
    return metrics


# ─────────────────────────────────────────────────────────────────────────────
# Evaluate all variants
# ─────────────────────────────────────────────────────────────────────────────

def evaluate_all_variants(
    results_dir: str,
    max_eval_samples: int = 1319,
    eval_batch_size: int = 8,
    seed: int = 42,
) -> Dict[str, EvalMetrics]:
    """Run evaluation for all six RLVER variants, save results."""
    random.seed(seed)
    np.random.seed(seed)
    os.makedirs(results_dir, exist_ok=True)

    # Build eval dataset once
    logger.info("Building RLVER eval dataset ...")
    builder = RLVERDatasetBuilder(
        adversarial_ratio=0.4,
        cache_dir=os.path.join(PROJECT_ROOT, "cache", "hf"),
        seed=seed,
    )

    # Try to use cached eval file
    cache_eval = os.path.join(PROJECT_ROOT, "cache", "datasets", "rlver_eval.jsonl")
    if os.path.isfile(cache_eval):
        eval_samples = builder.load_jsonl(cache_eval)
    else:
        eval_samples = builder.build(split="test", max_samples=max_eval_samples)

    if len(eval_samples) > max_eval_samples:
        eval_samples = eval_samples[:max_eval_samples]

    logger.info(f"Eval dataset: {len(eval_samples)} samples")

    all_metrics: Dict[str, EvalMetrics] = {}

    for variant_name, model_alias, thinking, algorithm, ckpt_sub in EVAL_VARIANTS:
        result_path = os.path.join(results_dir, f"{variant_name}.json")

        # Skip if result already exists
        if os.path.isfile(result_path):
            logger.info(f"Result exists, loading: {result_path}")
            all_metrics[variant_name] = load_metrics(result_path)
            continue

        logger.info(f"\n>>> Evaluating variant: {variant_name}")
        model_path = resolve_model_path(model_alias, checkpoint_subdir=ckpt_sub)
        run_id     = f"{variant_name}_{time.strftime('%Y%m%d_%H%M%S')}"

        try:
            metrics = evaluate_model(
                model_path      = model_path,
                samples         = eval_samples,
                thinking_enabled = thinking,
                algorithm       = algorithm,
                run_id          = run_id,
                eval_batch_size = eval_batch_size,
            )
        except Exception as e:
            logger.error(f"Variant {variant_name} failed: {e}", exc_info=True)
            continue

        save_metrics(metrics, result_path)
        all_metrics[variant_name] = metrics

    return all_metrics


# ─────────────────────────────────────────────────────────────────────────────
# Comparison table
# ─────────────────────────────────────────────────────────────────────────────

def print_comparison_table(all_metrics: Dict[str, EvalMetrics]) -> None:
    """Print a formatted side-by-side comparison table."""
    if not all_metrics:
        print("No metrics to compare.")
        return

    headers = ["Variant", "Acc%", "F1%", "AdvAcc%", "TQS", "ECE"]
    rows = [
        [
            name,
            f"{m.verification_accuracy*100:.2f}",
            f"{m.f1_score*100:.2f}",
            f"{m.adversarial_accuracy*100:.2f}",
            f"{m.thinking_quality_score:.4f}",
            f"{m.expected_calibration_error:.4f}",
        ]
        for name, m in all_metrics.items()
    ]

    col_w = [
        max(len(h), max((len(r[i]) for r in rows), default=0)) + 2
        for i, h in enumerate(headers)
    ]
    sep = "+" + "+".join("-" * w for w in col_w) + "+"
    fmt = "|" + "|".join(f" {{:<{w-1}}}" for w in col_w) + "|"

    print(f"\n{'='*70}")
    print("  RLVER — Variants Comparison")
    print(f"{'='*70}")
    print(sep)
    print(fmt.format(*headers))
    print(sep)
    for row in rows:
        print(fmt.format(*row))
    print(sep)
    print()


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="RLVER Evaluation",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command")

    # ── single ────────────────────────────────────────────────────────────────
    sp = sub.add_parser("single", help="Evaluate one model checkpoint")
    sp.add_argument("--model_path",     type=str, required=True)
    sp.add_argument("--thinking",       action="store_true")
    sp.add_argument("--algorithm",      type=str, default="baseline",
                    choices=["baseline", "ppo", "grpo"])
    sp.add_argument("--max_samples",    type=int, default=500)
    sp.add_argument("--eval_batch_size",type=int, default=8)
    sp.add_argument("--max_new_tokens", type=int, default=256)
    sp.add_argument("--save_path",      type=str, default=None,
                    help="Path for result JSON (default: results/<run_id>.json)")
    sp.add_argument("--seed",           type=int, default=42)

    # ── all ───────────────────────────────────────────────────────────────────
    ap = sub.add_parser("all", help="Evaluate all RLVER variants")
    ap.add_argument("--results_dir",     type=str,
                    default=os.path.join(PROJECT_ROOT, "results"))
    ap.add_argument("--max_eval_samples",type=int, default=1319)
    ap.add_argument("--eval_batch_size", type=int, default=8)
    ap.add_argument("--seed",            type=int, default=42)

    # ── compare ───────────────────────────────────────────────────────────────
    cp = sub.add_parser("compare", help="Compare saved result JSON files")
    cp.add_argument("result_files", nargs="+", type=str)

    return parser


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    parser = build_parser()
    args   = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return

    # ── single ────────────────────────────────────────────────────────────────
    if args.command == "single":
        random.seed(args.seed)
        np.random.seed(args.seed)

        builder = RLVERDatasetBuilder(
            adversarial_ratio=0.4,
            cache_dir=os.path.join(PROJECT_ROOT, "cache", "hf"),
            seed=args.seed,
        )
        # Try cached eval first
        cache_eval = os.path.join(PROJECT_ROOT, "cache", "datasets", "rlver_eval.jsonl")
        if os.path.isfile(cache_eval):
            samples = builder.load_jsonl(cache_eval)
            if args.max_samples and len(samples) > args.max_samples:
                samples = samples[:args.max_samples]
        else:
            samples = builder.build(split="test", max_samples=args.max_samples)

        run_id  = f"eval_{time.strftime('%Y%m%d_%H%M%S')}"
        metrics = evaluate_model(
            model_path       = args.model_path,
            samples          = samples,
            thinking_enabled = args.thinking,
            algorithm        = args.algorithm,
            run_id           = run_id,
            eval_batch_size  = args.eval_batch_size,
            max_new_tokens   = args.max_new_tokens,
        )

        if args.save_path:
            save_path = args.save_path
        else:
            results_dir = os.path.join(PROJECT_ROOT, "results")
            os.makedirs(results_dir, exist_ok=True)
            save_path = os.path.join(results_dir, f"{run_id}.json")

        save_metrics(metrics, save_path)
        logger.info(f"Results saved → {save_path}")

    # ── all ───────────────────────────────────────────────────────────────────
    elif args.command == "all":
        all_metrics = evaluate_all_variants(
            results_dir      = args.results_dir,
            max_eval_samples = args.max_eval_samples,
            eval_batch_size  = args.eval_batch_size,
            seed             = args.seed,
        )
        print_comparison_table(all_metrics)

        # Pairwise comparison: baseline_7b vs each RL variant
        baseline_key = "baseline_7b"
        if baseline_key in all_metrics:
            for name in ["ppo_thinking", "ppo_non_thinking",
                         "grpo_thinking", "grpo_non_thinking"]:
                if name in all_metrics:
                    print(compare_metrics(
                        all_metrics[baseline_key],
                        all_metrics[name],
                        label_baseline="Baseline 7B",
                        label_trained=name,
                    ))

    # ── compare ───────────────────────────────────────────────────────────────
    elif args.command == "compare":
        loaded = {}
        for path in args.result_files:
            if not os.path.isfile(path):
                logger.warning(f"Result file not found: {path}")
                continue
            name = Path(path).stem
            loaded[name] = load_metrics(path)

        print_comparison_table(loaded)

        if len(loaded) == 2:
            names = list(loaded.keys())
            print(compare_metrics(
                loaded[names[0]], loaded[names[1]],
                label_baseline=names[0],
                label_trained=names[1],
            ))


if __name__ == "__main__":
    main()
