#!/bin/bash
# =============================================================================
# RLVER — Training Runner
# File   : scripts/02_run_training.sh
# Author : Dushyant (u23ai085)
#
# Runs all 4 RLVER training variants sequentially (or selectively).
# Machine: NVIDIA RTX PRO 4500 Blackwell, 33.7 GB VRAM
#
# Usage:
#   bash scripts/02_run_training.sh                    # all 4 variants
#   bash scripts/02_run_training.sh ppo thinking       # single variant
#   bash scripts/02_run_training.sh grpo non_thinking  # single variant
# =============================================================================

set -e

ALGO="${1:-all}"
THINK="${2:-all}"

PROJECT_ROOT="$HOME/Dushyant_u23ai085_9256777500"
PYTHON="$(conda run -n rlver_env which python)"
TRAIN_SCRIPT="$PROJECT_ROOT/rl_training/rlver_rl_train.py"
LOG_DIR="$PROJECT_ROOT/logs"
RESULTS_DIR="$PROJECT_ROOT/results"

mkdir -p "$LOG_DIR" "$RESULTS_DIR"

echo ""
echo "=================================================================="
echo "  RLVER Training Runner"
echo "  Project root : $PROJECT_ROOT"
echo "  Algorithm    : $ALGO"
echo "  Thinking     : $THINK"
echo "  Started      : $(date)"
echo "=================================================================="

# ── Helpers ───────────────────────────────────────────────────────────────────

run_variant() {
    local algo="$1"        # ppo | grpo
    local thinking="$2"   # thinking | non_thinking
    local config_flag=""
    local think_flag=""
    local log_name="${algo}_${thinking}"

    # Select config
    if [ "$algo" = "ppo" ]; then
        config_flag="--config $PROJECT_ROOT/configs/ppo_config.yaml"
    else
        config_flag="--config $PROJECT_ROOT/configs/grpo_config.yaml"
    fi

    # Thinking flag
    if [ "$thinking" = "thinking" ]; then
        think_flag="--thinking"
    fi

    echo ""
    echo "------------------------------------------------------------------"
    echo "  VARIANT: $log_name"
    echo "  Start  : $(date)"
    echo "------------------------------------------------------------------"

    conda run -n rlver_env python "$TRAIN_SCRIPT" \
        --algorithm "$algo" \
        $think_flag \
        $config_flag \
        --output_dir "$PROJECT_ROOT/rl_training/checkpoints" \
        --seed 42 \
        2>&1 | tee "$LOG_DIR/${log_name}.log"

    local exit_code=${PIPESTATUS[0]}
    if [ $exit_code -ne 0 ]; then
        echo "[ERROR] Variant $log_name failed with exit code $exit_code"
        echo "[INFO]  Check log: $LOG_DIR/${log_name}.log"
        return $exit_code
    fi

    echo ""
    echo "[OK] $log_name completed at $(date)"
    echo "------------------------------------------------------------------"
}

# ── Run logic ─────────────────────────────────────────────────────────────────

if [ "$ALGO" = "all" ]; then
    # Run all 4 variants
    echo ""
    echo "[INFO] Running all 4 RLVER training variants ..."
    echo "       Estimated time: 6–14 hours per variant on RTX PRO 4500"
    echo ""

    run_variant ppo  thinking     && echo "[DONE] PPO+thinking"
    run_variant ppo  non_thinking && echo "[DONE] PPO+non_thinking"
    run_variant grpo thinking     && echo "[DONE] GRPO+thinking"
    run_variant grpo non_thinking && echo "[DONE] GRPO+non_thinking"

elif [ "$ALGO" = "ppo" ] || [ "$ALGO" = "grpo" ]; then
    if [ "$THINK" = "all" ]; then
        run_variant "$ALGO" thinking
        run_variant "$ALGO" non_thinking
    else
        run_variant "$ALGO" "$THINK"
    fi

else
    echo "[ERROR] Unknown algorithm: $ALGO"
    echo "Usage: $0 [ppo|grpo|all] [thinking|non_thinking|all]"
    exit 1
fi

echo ""
echo "=================================================================="
echo "  All requested training runs COMPLETE"
echo "  Finished : $(date)"
echo "  Logs dir : $LOG_DIR"
echo "  Checkpts : $PROJECT_ROOT/rl_training/checkpoints/"
echo "=================================================================="
echo ""
echo "  Next step: run evaluation"
echo "  bash scripts/03_run_eval.sh"
