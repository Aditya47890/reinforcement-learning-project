"""
=============================================================================
RLVER — Ablation Study Configuration
File  : ablation/ablation_config.py
Author: Dushyant (u23ai085)

Defines all ablation experiment groups.  Each group isolates one variable
while holding everything else at the best known setting.

Ablation Groups
---------------
A  Reward Component Ablation    — what each reward term contributes
B  Algorithm Ablation           — PPO vs GRPO vs REINFORCE vs SFT vs Zero-shot
C  Thinking Mode Ablation       — CoT on/off + thinking token budget
D  Model Scale Ablation         — Qwen-1.5B vs Qwen-7B
E  GRPO Group Size  (G)         — G ∈ {2, 4, 8, 16}
F  LoRA Rank Ablation           — r ∈ {16, 32, 64, 128}
G  Adversarial Ratio Ablation   — ratio ∈ {0.0, 0.2, 0.4, 0.6}
H  KL Penalty β Ablation        — β ∈ {0.0, 0.01, 0.04, 0.10}
I  Training Steps Ablation      — convergence curve at 1k/3k/5k/10k steps

RLVER Best Config (reference):
  Algorithm  : GRPO
  Thinking   : True
  Model      : Qwen-7B
  G          : 8
  LoRA r     : 64
  Adv ratio  : 0.4
  β (KL)     : 0.04
  Steps      : 10,000
=============================================================================
"""

from __future__ import annotations

import os
import copy
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any

PROJECT_ROOT = os.path.expanduser("~/Dushyant_u23ai085_9256777500")

# ── Ablation-specific constants ───────────────────────────────────────────────
# Use shorter runs for ablation (compute budget).
# Full training uses 10,000 steps; ablation uses 3,000.
ABLATION_STEPS        = 3000
ABLATION_EVAL_SAMPLES = 500     # subset of 1319 test samples
ABLATION_SEED         = 42


# ─────────────────────────────────────────────────────────────────────────────
# AblationExperiment — one row in the ablation table
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AblationExperiment:
    """
    Fully self-contained specification for one ablation run.

    Fields map directly onto TrainConfig + RewardConfig fields,
    plus ablation-specific metadata.
    """
    # ── Identity ──────────────────────────────────────────────────────────────
    group_id:    str   = "A"          # ablation group letter
    exp_id:      str   = "A1"         # unique experiment id  (e.g. "A1", "B3")
    name:        str   = "full_rlver" # short human-readable label
    description: str   = ""           # one-line description for tables/plots
    is_ours:     bool  = False        # True = RLVER best config (the proposed method)
    is_baseline: bool  = False        # True = zero-shot or SFT baseline

    # ── Algorithm ─────────────────────────────────────────────────────────────
    algorithm:        str  = "grpo"   # "grpo" | "ppo" | "reinforce" | "sft" | "zero_shot"
    thinking_enabled: bool = True

    # ── Model ─────────────────────────────────────────────────────────────────
    model_name_or_path: str  = "Qwen/Qwen2.5-7B-Instruct"
    lora_r:             int  = 64
    lora_alpha:         int  = 128
    lora_dropout:       float = 0.05
    use_lora:           bool = True

    # ── Data ──────────────────────────────────────────────────────────────────
    adversarial_ratio:  float = 0.4

    # ── Training ──────────────────────────────────────────────────────────────
    max_steps:                    int   = ABLATION_STEPS
    ppo_learning_rate:            float = 1.0e-5
    ppo_batch_size:               int   = 8
    ppo_mini_batch_size:          int   = 4
    ppo_gradient_accumulation:    int   = 4
    ppo_num_epochs:               int   = 4
    ppo_cliprange:                float = 0.2
    ppo_vf_coef:                  float = 0.1
    ppo_ent_coef:                 float = 0.01
    ppo_init_kl_coef:             float = 0.05
    ppo_target_kl:                float = 6.0

    grpo_learning_rate:           float = 5.0e-6
    grpo_batch_size:              int   = 4
    grpo_gradient_accumulation:   int   = 8
    grpo_num_generations:         int   = 8
    grpo_beta:                    float = 0.04
    grpo_epsilon:                 float = 0.2

    # ── Reward ────────────────────────────────────────────────────────────────
    reward_correct:        float = 1.0
    reward_wrong:          float = -1.0
    reward_partial:        float = 0.3    # CoT reasoning bonus (ablated in Group A)
    reward_format:         float = 0.1   # format bonus        (ablated in Group A)
    reward_length_penalty: float = 0.001 # length penalty      (ablated in Group A)
    reward_max_length:     int   = 200

    # ── Generation ────────────────────────────────────────────────────────────
    max_new_tokens: int   = 256
    temperature:    float = 0.9
    top_p:          float = 0.95

    # ── Misc ──────────────────────────────────────────────────────────────────
    seed: int = ABLATION_SEED

    def to_dict(self) -> Dict:
        return asdict(self)

    def result_filename(self) -> str:
        return f"ablation_{self.exp_id}_{self.name}.json"


# ─────────────────────────────────────────────────────────────────────────────
# AblationGroup — collection of experiments that vary one dimension
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AblationGroup:
    group_id:    str
    title:       str
    description: str
    experiments: List[AblationExperiment] = field(default_factory=list)
    x_label:     str = ""    # axis label for plots (e.g. "Group Size G")
    x_ticks:     List[str] = field(default_factory=list)  # tick labels


# ─────────────────────────────────────────────────────────────────────────────
# Helper: our best RLVER config (used as baseline throughout)
# ─────────────────────────────────────────────────────────────────────────────

def _rlver_best(
    group_id: str,
    exp_id:   str,
    name:     str = "RLVER_ours",
    desc:     str = "RLVER best (GRPO + Thinking, G=8, r=64, adv=0.4, β=0.04)",
    steps:    int = ABLATION_STEPS,
) -> AblationExperiment:
    return AblationExperiment(
        group_id=group_id, exp_id=exp_id,
        name=name, description=desc,
        is_ours=True,
        algorithm="grpo",
        thinking_enabled=True,
        model_name_or_path="Qwen/Qwen2.5-7B-Instruct",
        lora_r=64, lora_alpha=128, use_lora=True,
        adversarial_ratio=0.4,
        max_steps=steps,
        grpo_num_generations=8,
        grpo_beta=0.04,
        reward_partial=0.3,
        reward_format=0.1,
        reward_length_penalty=0.001,
    )


# ─────────────────────────────────────────────────────────────────────────────
# GROUP A — Reward Component Ablation
# "What does each term in the reward function contribute?"
# ─────────────────────────────────────────────────────────────────────────────

def _build_group_a() -> AblationGroup:
    g = AblationGroup(
        group_id="A",
        title="Reward Component Ablation",
        description=(
            "Systematically removes one reward component at a time to "
            "quantify its contribution to verification accuracy."
        ),
        x_label="Reward Configuration",
        x_ticks=[
            "Full\n(Ours)", "No CoT\nBonus", "No Format\nBonus",
            "No Length\nPenalty", "Binary\nOnly",
        ],
    )
    # A1 — Full reward (our method)
    g.experiments.append(_rlver_best("A", "A1", "Full_Reward",
        "Full reward: R_verify + R_reasoning + R_format + R_length"))

    # A2 — Remove reasoning/CoT reward
    e = _rlver_best("A", "A2", "No_CoT_Reward",
        "Ablate R_reasoning: no partial reward for chain-of-thought")
    e.reward_partial = 0.0
    g.experiments.append(e)

    # A3 — Remove format bonus
    e = _rlver_best("A", "A3", "No_Format_Reward",
        "Ablate R_format: no bonus for VERDICT+CONFIDENCE compliance")
    e.reward_format = 0.0
    g.experiments.append(e)

    # A4 — Remove length penalty
    e = _rlver_best("A", "A4", "No_Length_Penalty",
        "Ablate R_length: no penalty for verbose outputs")
    e.reward_length_penalty = 0.0
    g.experiments.append(e)

    # A5 — Binary reward only (R_verify only, no shaping)
    e = _rlver_best("A", "A5", "Binary_Only",
        "Binary reward only: +1/-1 for correct/wrong, no shaping terms")
    e.reward_partial        = 0.0
    e.reward_format         = 0.0
    e.reward_length_penalty = 0.0
    g.experiments.append(e)

    return g


# ─────────────────────────────────────────────────────────────────────────────
# GROUP B — Algorithm Ablation
# "How does our RL algorithm compare to alternatives?"
# ─────────────────────────────────────────────────────────────────────────────

def _build_group_b() -> AblationGroup:
    g = AblationGroup(
        group_id="B",
        title="Algorithm Ablation",
        description=(
            "Compares RLVER's GRPO against Zero-shot, PPO, and a simplified "
            "REINFORCE baseline, with and without thinking."
        ),
        x_label="Training Algorithm",
        x_ticks=[
            "Zero-shot\n7B", "Zero-shot\n1.5B", "PPO\nThinking",
            "PPO\nNo-Think", "REINFORCE\nThinking",
            "GRPO\nNo-Think", "GRPO\nThinking\n(Ours)",
        ],
    )

    # B1 — Zero-shot Qwen-7B (no training)
    b1 = AblationExperiment(
        group_id="B", exp_id="B1",
        name="ZeroShot_7B",
        description="Zero-shot Qwen2.5-7B: no RL training, direct inference",
        is_baseline=True,
        algorithm="zero_shot",
        thinking_enabled=False,
        model_name_or_path="Qwen/Qwen2.5-7B-Instruct",
        use_lora=False, max_steps=0,
    )
    g.experiments.append(b1)

    # B2 — Zero-shot Qwen-1.5B
    b2 = AblationExperiment(
        group_id="B", exp_id="B2",
        name="ZeroShot_1p5B",
        description="Zero-shot Qwen2.5-1.5B: smaller model, no RL training",
        is_baseline=True,
        algorithm="zero_shot",
        thinking_enabled=False,
        model_name_or_path="Qwen/Qwen2.5-1.5B-Instruct",
        use_lora=False, max_steps=0,
    )
    g.experiments.append(b2)

    # B3 — PPO with thinking
    b3 = _rlver_best("B", "B3", "PPO_Thinking",
        "PPO with thinking mode: actor-critic, KL-controlled")
    b3.algorithm = "ppo"
    g.experiments.append(b3)

    # B4 — PPO without thinking
    b4 = _rlver_best("B", "B4", "PPO_NoThink",
        "PPO without thinking mode: direct verdict")
    b4.algorithm         = "ppo"
    b4.thinking_enabled  = False
    b4.reward_partial    = 0.0
    g.experiments.append(b4)

    # B5 — REINFORCE (GRPO with G=1, no group normalization)
    b5 = _rlver_best("B", "B5", "REINFORCE_Thinking",
        "REINFORCE: GRPO degenerated to G=1 (no group normalization)")
    b5.algorithm              = "reinforce"
    b5.grpo_num_generations   = 1
    g.experiments.append(b5)

    # B6 — GRPO without thinking
    b6 = _rlver_best("B", "B6", "GRPO_NoThink",
        "GRPO without thinking: group-relative, direct verdict")
    b6.thinking_enabled = False
    b6.reward_partial   = 0.0
    g.experiments.append(b6)

    # B7 — GRPO with thinking (our best method)
    g.experiments.append(_rlver_best("B", "B7", "GRPO_Thinking",
        "RLVER proposed: GRPO with chain-of-thought thinking"))

    return g


# ─────────────────────────────────────────────────────────────────────────────
# GROUP C — Thinking Mode Ablation
# "How much does thinking contribute, and how much token budget is needed?"
# ─────────────────────────────────────────────────────────────────────────────

def _build_group_c() -> AblationGroup:
    g = AblationGroup(
        group_id="C",
        title="Thinking Mode Ablation",
        description=(
            "Ablates thinking mode and thinking token budget to understand "
            "how chain-of-thought reasoning affects verification quality."
        ),
        x_label="Thinking Configuration",
        x_ticks=["No Think", "64 tok", "128 tok", "256 tok\n(Ours)", "512 tok"],
    )

    # C1 — No thinking
    c1 = _rlver_best("C", "C1", "No_Thinking",
        "Thinking disabled: model outputs VERDICT directly")
    c1.thinking_enabled = False
    c1.reward_partial   = 0.0
    c1.max_new_tokens   = 128
    g.experiments.append(c1)

    # C2-C5 — Varying token budget for thinking
    for tokens, label in [(64, "Think_64"), (128, "Think_128"),
                           (256, "Think_256"), (512, "Think_512")]:
        exp_id = f"C{['64','128','256','512'].index(str(tokens)) + 2}"
        e = _rlver_best("C", exp_id, label,
            f"Thinking with max {tokens} new tokens budget")
        e.max_new_tokens = tokens
        if tokens == 256:
            e.is_ours = True    # default = our setting
        g.experiments.append(e)

    return g


# ─────────────────────────────────────────────────────────────────────────────
# GROUP D — Model Scale Ablation
# "Does scale help, and how does our method scale?"
# ─────────────────────────────────────────────────────────────────────────────

def _build_group_d() -> AblationGroup:
    g = AblationGroup(
        group_id="D",
        title="Model Scale Ablation",
        description=(
            "Compares RLVER trained on Qwen-1.5B vs Qwen-7B to quantify "
            "how model scale interacts with RL fine-tuning."
        ),
        x_label="Model Size",
        x_ticks=["1.5B\nBaseline", "1.5B\nRLVER", "7B\nBaseline", "7B\nRLVER\n(Ours)"],
    )

    # D1 — Qwen-1.5B zero-shot
    d1 = AblationExperiment(
        group_id="D", exp_id="D1",
        name="1p5B_ZeroShot",
        description="Qwen-1.5B zero-shot, no RL training",
        is_baseline=True, algorithm="zero_shot",
        model_name_or_path="Qwen/Qwen2.5-1.5B-Instruct",
        thinking_enabled=False, use_lora=False, max_steps=0,
    )
    g.experiments.append(d1)

    # D2 — Qwen-1.5B + GRPO + thinking
    d2 = _rlver_best("D", "D2", "1p5B_GRPO_Think",
        "Qwen-1.5B fine-tuned with GRPO + thinking")
    d2.model_name_or_path = "Qwen/Qwen2.5-1.5B-Instruct"
    d2.is_ours = False
    g.experiments.append(d2)

    # D3 — Qwen-7B zero-shot
    d3 = AblationExperiment(
        group_id="D", exp_id="D3",
        name="7B_ZeroShot",
        description="Qwen-7B zero-shot, no RL training",
        is_baseline=True, algorithm="zero_shot",
        model_name_or_path="Qwen/Qwen2.5-7B-Instruct",
        thinking_enabled=False, use_lora=False, max_steps=0,
    )
    g.experiments.append(d3)

    # D4 — Qwen-7B + GRPO + thinking (our best)
    g.experiments.append(_rlver_best("D", "D4", "7B_GRPO_Think",
        "Qwen-7B RLVER proposed method"))

    return g


# ─────────────────────────────────────────────────────────────────────────────
# GROUP E — GRPO Group Size (G) Ablation
# "How many completions per prompt does GRPO need?"
# ─────────────────────────────────────────────────────────────────────────────

def _build_group_e() -> AblationGroup:
    g = AblationGroup(
        group_id="E",
        title="GRPO Group Size Ablation",
        description=(
            "Varies the number of completions G sampled per prompt in GRPO. "
            "G=1 degenerates to REINFORCE (no group normalization)."
        ),
        x_label="Group Size G",
        x_ticks=["G=1\n(REINFORCE)", "G=2", "G=4", "G=8\n(Ours)", "G=16"],
    )

    for i, G in enumerate([1, 2, 4, 8, 16]):
        exp_id = f"E{i+1}"
        label  = "REINFORCE" if G == 1 else f"G={G}"
        desc   = (
            f"GRPO with G={G} completions per prompt"
            + (" (degenerates to REINFORCE)" if G == 1 else "")
        )
        e = _rlver_best("E", exp_id, f"GRPO_G{G}", desc)
        e.grpo_num_generations = G
        # G=1: use reinforce algorithm tag
        if G == 1:
            e.algorithm = "reinforce"
            e.is_ours   = False
        elif G == 8:
            e.is_ours = True
        else:
            e.is_ours = False
        g.experiments.append(e)

    return g


# ─────────────────────────────────────────────────────────────────────────────
# GROUP F — LoRA Rank Ablation
# "How much adapter capacity is needed?"
# ─────────────────────────────────────────────────────────────────────────────

def _build_group_f() -> AblationGroup:
    g = AblationGroup(
        group_id="F",
        title="LoRA Rank Ablation",
        description=(
            "Varies the LoRA adapter rank r to understand the trade-off "
            "between parameter efficiency and model capacity."
        ),
        x_label="LoRA Rank r",
        x_ticks=["r=8", "r=16", "r=32", "r=64\n(Ours)", "r=128"],
    )

    for i, r in enumerate([8, 16, 32, 64, 128]):
        e = _rlver_best("F", f"F{i+1}", f"LoRA_r{r}",
            f"GRPO + Thinking with LoRA rank r={r}")
        e.lora_r     = r
        e.lora_alpha = r * 2       # standard: alpha = 2×rank
        e.is_ours    = (r == 64)
        g.experiments.append(e)

    return g


# ─────────────────────────────────────────────────────────────────────────────
# GROUP G — Adversarial Ratio Ablation
# "How much adversarial data should the training set contain?"
# ─────────────────────────────────────────────────────────────────────────────

def _build_group_g() -> AblationGroup:
    g = AblationGroup(
        group_id="G",
        title="Adversarial Data Ratio Ablation",
        description=(
            "Varies the proportion of adversarial (incorrect) solutions in "
            "the training set to find the optimal mix."
        ),
        x_label="Adversarial Ratio",
        x_ticks=["0.0\n(clean only)", "0.1", "0.2", "0.4\n(Ours)", "0.6", "0.8"],
    )

    for i, ratio in enumerate([0.0, 0.1, 0.2, 0.4, 0.6, 0.8]):
        e = _rlver_best("G", f"G{i+1}", f"AdvRatio_{str(ratio).replace('.','p')}",
            f"GRPO + Thinking with adversarial_ratio={ratio}")
        e.adversarial_ratio = ratio
        e.is_ours           = (ratio == 0.4)
        g.experiments.append(e)

    return g


# ─────────────────────────────────────────────────────────────────────────────
# GROUP H — KL Penalty β Ablation (GRPO)
# "How strongly should we penalise deviation from the reference policy?"
# ─────────────────────────────────────────────────────────────────────────────

def _build_group_h() -> AblationGroup:
    g = AblationGroup(
        group_id="H",
        title="KL Penalty β Ablation",
        description=(
            "Varies the KL penalty coefficient β in GRPO. "
            "β=0 disables KL regularisation; large β prevents policy drift."
        ),
        x_label="KL Coefficient β",
        x_ticks=["β=0.0\n(no KL)", "β=0.01", "β=0.04\n(Ours)", "β=0.10", "β=0.20"],
    )

    for i, beta in enumerate([0.0, 0.01, 0.04, 0.10, 0.20]):
        label = f"Beta_{str(beta).replace('.','p')}"
        e = _rlver_best("H", f"H{i+1}", label,
            f"GRPO + Thinking with KL penalty β={beta}")
        e.grpo_beta = beta
        e.is_ours   = (beta == 0.04)
        g.experiments.append(e)

    return g


# ─────────────────────────────────────────────────────────────────────────────
# GROUP I — Training Steps / Convergence Ablation
# "How many training steps are needed to converge?"
# ─────────────────────────────────────────────────────────────────────────────

def _build_group_i() -> AblationGroup:
    g = AblationGroup(
        group_id="I",
        title="Training Steps (Convergence) Ablation",
        description=(
            "Evaluates checkpoints at multiple training steps to show the "
            "learning curve and confirm that 10k steps is sufficient."
        ),
        x_label="Training Steps",
        x_ticks=["1k", "2k", "3k", "5k", "7.5k", "10k\n(Full)"],
    )

    for i, steps in enumerate([1000, 2000, 3000, 5000, 7500, 10000]):
        e = _rlver_best("I", f"I{i+1}", f"Steps_{steps}",
            f"GRPO + Thinking evaluated at {steps} training steps",
            steps=steps)
        e.is_ours = (steps == 10000)
        g.experiments.append(e)

    return g


# ─────────────────────────────────────────────────────────────────────────────
# Master list of all ablation groups
# ─────────────────────────────────────────────────────────────────────────────

def _build_all_groups() -> List[AblationGroup]:
    return [
        _build_group_a(),
        _build_group_b(),
        _build_group_c(),
        _build_group_d(),
        _build_group_e(),
        _build_group_f(),
        _build_group_g(),
        _build_group_h(),
        _build_group_i(),
    ]


ALL_ABLATION_GROUPS: List[AblationGroup] = _build_all_groups()

# Flat lookup: exp_id → AblationExperiment
_EXPERIMENT_MAP: Dict[str, AblationExperiment] = {
    exp.exp_id: exp
    for group in ALL_ABLATION_GROUPS
    for exp in group.experiments
}


def get_experiment_config(exp_id: str) -> AblationExperiment:
    """Look up an experiment by ID (e.g. 'A1', 'B7', 'E3')."""
    if exp_id not in _EXPERIMENT_MAP:
        available = sorted(_EXPERIMENT_MAP.keys())
        raise KeyError(f"Unknown exp_id '{exp_id}'. Available: {available}")
    return _EXPERIMENT_MAP[exp_id]


def list_all_experiments() -> List[AblationExperiment]:
    """Return flat list of all ablation experiments in group order."""
    return [exp for g in ALL_ABLATION_GROUPS for exp in g.experiments]


# ─────────────────────────────────────────────────────────────────────────────
# CLI: print experiment table
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    all_exps = list_all_experiments()
    print(f"\n{'='*90}")
    print(f"  RLVER Ablation Study — {len(all_exps)} Experiments across {len(ALL_ABLATION_GROUPS)} Groups")
    print(f"{'='*90}")
    print(f"  {'ID':<5} {'Name':<30} {'Algorithm':<10} {'Think':<6} {'Steps':<7} {'Ours':<5} {'Description'}")
    print(f"  {'-'*85}")
    for g in ALL_ABLATION_GROUPS:
        print(f"\n  ── Group {g.group_id}: {g.title}")
        for e in g.experiments:
            ours = "★" if e.is_ours else (" B" if e.is_baseline else "")
            print(
                f"  {e.exp_id:<5} {e.name:<30} {e.algorithm:<10} "
                f"{'Y' if e.thinking_enabled else 'N':<6} "
                f"{e.max_steps:<7} {ours:<5} {e.description[:50]}"
            )
    print(f"\n  ★ = RLVER proposed method  B = baseline/comparison")
    print(f"{'='*90}\n")
