"""
=============================================================================
RLVER — Results Analysis & Visualization
File  : scripts/04_analyze_results.py
Author: Dushyant (u23ai085)

Reads evaluation result JSON files from results/ and generates:
  1. Bar chart  — Verification Accuracy for all 6 variants
  2. Bar chart  — F1 Score for all 6 variants
  3. Grouped bar — Clean vs Adversarial accuracy
  4. Radar chart — Multi-metric comparison (Acc, F1, AdvAcc, TQS, 1-ECE)
  5. Heatmap    — All metrics × all variants
  6. Line chart — Training log (reward / accuracy vs step) per variant
  7. Summary table printed to terminal

Usage:
  conda activate rlver_env
  python scripts/04_analyze_results.py
  python scripts/04_analyze_results.py --results_dir results/ --out_dir results/plots/
  python scripts/04_analyze_results.py --training_logs   # also plot training curves
=============================================================================
"""

from __future__ import annotations

import os
import sys
import json
import glob
import argparse
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)

# ── Path setup ────────────────────────────────────────────────────────────────
PROJECT_ROOT = os.path.expanduser("~/Dushyant_u23ai085_9256777500")
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rlver_adversarial"))
sys.path.insert(0, os.path.join(PROJECT_ROOT, "rl_training"))


# ─────────────────────────────────────────────────────────────────────────────
# Matplotlib setup (non-interactive backend for server/headless use)
# ─────────────────────────────────────────────────────────────────────────────

def _setup_matplotlib():
    import matplotlib
    matplotlib.use("Agg")          # headless — saves files without display
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    plt.rcParams.update({
        "font.family":      "DejaVu Sans",
        "font.size":        11,
        "axes.titlesize":   13,
        "axes.labelsize":   11,
        "axes.spines.top":  False,
        "axes.spines.right":False,
        "axes.grid":        True,
        "grid.alpha":       0.3,
        "grid.linestyle":   "--",
        "figure.dpi":       150,
        "savefig.dpi":      150,
        "savefig.bbox_inches": "tight",
        "savefig.facecolor": "white",
    })
    return plt


# ─────────────────────────────────────────────────────────────────────────────
# Colour / label palette for the 6 variants
# ─────────────────────────────────────────────────────────────────────────────

VARIANT_META = {
    "baseline_1p5b":    {"label": "Baseline\n1.5B",    "color": "#9ecae1", "hatch": ""},
    "baseline_7b":      {"label": "Baseline\n7B",      "color": "#3182bd", "hatch": ""},
    "ppo_thinking":     {"label": "PPO\nThinking",     "color": "#74c476", "hatch": "//"},
    "ppo_non_thinking": {"label": "PPO\nNo-Think",     "color": "#31a354", "hatch": ""},
    "grpo_thinking":    {"label": "GRPO\nThinking",    "color": "#fd8d3c", "hatch": "//"},
    "grpo_non_thinking":{"label": "GRPO\nNo-Think",    "color": "#d94801", "hatch": ""},
}

DISPLAY_ORDER = [
    "baseline_1p5b", "baseline_7b",
    "ppo_non_thinking", "ppo_thinking",
    "grpo_non_thinking", "grpo_thinking",
]


# ─────────────────────────────────────────────────────────────────────────────
# Data loading
# ─────────────────────────────────────────────────────────────────────────────

def load_all_results(results_dir: str) -> Dict[str, Dict]:
    """
    Load all .json result files from results_dir.
    Returns dict: variant_name → metrics dict.
    """
    pattern = os.path.join(results_dir, "*.json")
    files   = glob.glob(pattern)

    if not files:
        logger.warning(f"No JSON result files found in: {results_dir}")
        return {}

    results = {}
    for path in sorted(files):
        name = Path(path).stem
        try:
            with open(path) as f:
                data = json.load(f)
            results[name] = data
            logger.info(f"  Loaded: {name}")
        except Exception as e:
            logger.warning(f"  Failed to load {path}: {e}")

    logger.info(f"Loaded {len(results)} result files.")
    return results


def _ordered(results: Dict[str, Dict]) -> Tuple[List[str], List[Dict]]:
    """Return (names, data) in DISPLAY_ORDER, skipping missing variants."""
    names = [n for n in DISPLAY_ORDER if n in results]
    # Append any extra variants not in DISPLAY_ORDER
    extra = [n for n in results if n not in DISPLAY_ORDER]
    names += extra
    return names, [results[n] for n in names]


# ─────────────────────────────────────────────────────────────────────────────
# Plot 1 — Verification Accuracy bar chart
# ─────────────────────────────────────────────────────────────────────────────

def plot_accuracy_bars(results: Dict[str, Dict], out_dir: str, plt) -> None:
    names, data = _ordered(results)
    labels  = [VARIANT_META.get(n, {"label": n})["label"] for n in names]
    colors  = [VARIANT_META.get(n, {"color": "#aaaaaa"})["color"] for n in names]
    hatches = [VARIANT_META.get(n, {"hatch": ""})["hatch"] for n in names]
    accs    = [d.get("verification_accuracy", 0) * 100 for d in data]

    fig, ax = plt.subplots(figsize=(10, 5))
    x = np.arange(len(names))
    bars = ax.bar(x, accs, color=colors, hatch=hatches, edgecolor="white",
                  linewidth=0.8, width=0.65)

    # Value labels on bars
    for bar, val in zip(bars, accs):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.5,
            f"{val:.2f}%",
            ha="center", va="bottom", fontsize=9, fontweight="bold",
        )

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_ylabel("Verification Accuracy (%)")
    ax.set_title("RLVER — Verification Accuracy by Variant", fontweight="bold", pad=12)
    ax.set_ylim(0, min(100, max(accs) + 10))
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{y:.0f}%"))

    # Baseline reference line (7B)
    if "baseline_7b" in results:
        baseline_acc = results["baseline_7b"].get("verification_accuracy", 0) * 100
        ax.axhline(baseline_acc, color="#3182bd", linestyle="--",
                   linewidth=1.2, alpha=0.7, label=f"Baseline 7B: {baseline_acc:.2f}%")
        ax.legend(fontsize=9)

    path = os.path.join(out_dir, "01_accuracy_bars.png")
    fig.savefig(path)
    plt.close(fig)
    logger.info(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Plot 2 — F1 Score bar chart
# ─────────────────────────────────────────────────────────────────────────────

def plot_f1_bars(results: Dict[str, Dict], out_dir: str, plt) -> None:
    names, data = _ordered(results)
    labels  = [VARIANT_META.get(n, {"label": n})["label"] for n in names]
    colors  = [VARIANT_META.get(n, {"color": "#aaaaaa"})["color"] for n in names]
    hatches = [VARIANT_META.get(n, {"hatch": ""})["hatch"] for n in names]
    f1s     = [d.get("f1_score", 0) * 100 for d in data]

    fig, ax = plt.subplots(figsize=(10, 5))
    x    = np.arange(len(names))
    bars = ax.bar(x, f1s, color=colors, hatch=hatches,
                  edgecolor="white", linewidth=0.8, width=0.65)

    for bar, val in zip(bars, f1s):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.5,
            f"{val:.2f}%",
            ha="center", va="bottom", fontsize=9, fontweight="bold",
        )

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_ylabel("F1 Score (%)")
    ax.set_title("RLVER — F1 Score by Variant", fontweight="bold", pad=12)
    ax.set_ylim(0, min(100, max(f1s) + 10))
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{y:.0f}%"))

    path = os.path.join(out_dir, "02_f1_bars.png")
    fig.savefig(path)
    plt.close(fig)
    logger.info(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Plot 3 — Grouped bar: Clean vs Adversarial accuracy
# ─────────────────────────────────────────────────────────────────────────────

def plot_clean_vs_adversarial(results: Dict[str, Dict], out_dir: str, plt) -> None:
    names, data = _ordered(results)
    labels = [VARIANT_META.get(n, {"label": n})["label"] for n in names]

    # Clean accuracy = overall accuracy (all labels 0/1)
    # Adversarial accuracy = subset where is_adversarial=True
    clean_accs = [d.get("verification_accuracy", 0) * 100 for d in data]
    adv_accs   = [d.get("adversarial_accuracy",   0) * 100 for d in data]

    x     = np.arange(len(names))
    width = 0.38
    fig, ax = plt.subplots(figsize=(11, 5))

    bars1 = ax.bar(x - width/2, clean_accs, width, label="Overall Accuracy",
                   color="#3182bd", edgecolor="white", linewidth=0.8)
    bars2 = ax.bar(x + width/2, adv_accs, width, label="Adversarial Accuracy",
                   color="#d94801", edgecolor="white", linewidth=0.8, hatch="//")

    for bar, val in zip(bars1, clean_accs):
        if val > 0:
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.4,
                    f"{val:.1f}%", ha="center", va="bottom", fontsize=8)
    for bar, val in zip(bars2, adv_accs):
        if val > 0:
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.4,
                    f"{val:.1f}%", ha="center", va="bottom", fontsize=8)

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("RLVER — Overall vs Adversarial Accuracy", fontweight="bold", pad=12)
    ax.set_ylim(0, 105)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{y:.0f}%"))
    ax.legend(fontsize=10)

    path = os.path.join(out_dir, "03_clean_vs_adversarial.png")
    fig.savefig(path)
    plt.close(fig)
    logger.info(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Plot 4 — Radar / Spider chart (multi-metric)
# ─────────────────────────────────────────────────────────────────────────────

def plot_radar(results: Dict[str, Dict], out_dir: str, plt) -> None:
    """
    5-axis radar chart comparing the 4 RL-trained variants
    (skip tiny 1.5B baseline to keep the chart readable).
    Metrics: Accuracy, F1, Adv.Accuracy, TQS×100, (1-ECE)×100
    """
    import matplotlib.patches as mpatches

    metrics_labels = ["Accuracy", "F1 Score", "Adv. Accuracy", "TQS×100", "(1-ECE)×100"]
    N = len(metrics_labels)
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]   # close the loop

    variants_to_plot = [
        ("baseline_7b",      "#3182bd", "-",  "Baseline 7B"),
        ("ppo_thinking",     "#31a354", "--", "PPO + Thinking"),
        ("ppo_non_thinking", "#74c476", "-.", "PPO No-Think"),
        ("grpo_thinking",    "#d94801", "--", "GRPO + Thinking"),
        ("grpo_non_thinking","#fd8d3c", "-.", "GRPO No-Think"),
    ]

    fig, ax = plt.subplots(figsize=(7, 7), subplot_kw={"polar": True})

    handles = []
    for key, color, ls, display_label in variants_to_plot:
        if key not in results:
            continue
        d  = results[key]
        vals = [
            d.get("verification_accuracy", 0) * 100,
            d.get("f1_score",              0) * 100,
            d.get("adversarial_accuracy",  0) * 100,
            d.get("thinking_quality_score",0) * 100,
            (1 - d.get("expected_calibration_error", 0)) * 100,
        ]
        vals += vals[:1]   # close

        ax.plot(angles, vals, ls, color=color, linewidth=1.8, label=display_label)
        ax.fill(angles, vals, color=color, alpha=0.07)
        handles.append(mpatches.Patch(color=color, label=display_label))

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(metrics_labels, fontsize=10)
    ax.set_ylim(0, 100)
    ax.set_yticks([20, 40, 60, 80, 100])
    ax.set_yticklabels(["20", "40", "60", "80", "100"], fontsize=7, color="grey")
    ax.set_title("RLVER — Multi-Metric Radar\n(higher = better on all axes)",
                 fontweight="bold", pad=20)
    ax.legend(handles=handles, loc="upper right",
              bbox_to_anchor=(1.35, 1.15), fontsize=9)

    path = os.path.join(out_dir, "04_radar_chart.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    logger.info(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Plot 5 — Heatmap: all metrics × all variants
# ─────────────────────────────────────────────────────────────────────────────

def plot_heatmap(results: Dict[str, Dict], out_dir: str, plt) -> None:
    names, data = _ordered(results)
    labels = [VARIANT_META.get(n, {"label": n})["label"] for n in names]

    metric_keys = [
        ("verification_accuracy",   "Acc%",      True,  100),
        ("f1_score",                "F1%",        True,  100),
        ("precision",               "Prec%",      True,  100),
        ("recall",                  "Recall%",    True,  100),
        ("adversarial_accuracy",    "AdvAcc%",    True,  100),
        ("adversarial_f1",          "AdvF1%",     True,  100),
        ("thinking_quality_score",  "TQS",        True,    1),
        ("expected_calibration_error","ECE",      False,   1),
        ("roc_auc",                 "ROC-AUC",    True,    1),
        ("easy_accuracy",           "EasyAcc%",   True,  100),
        ("medium_accuracy",         "MedAcc%",    True,  100),
        ("hard_accuracy",           "HardAcc%",   True,  100),
    ]

    n_rows = len(metric_keys)
    n_cols = len(names)
    matrix = np.zeros((n_rows, n_cols))

    for j, d in enumerate(data):
        for i, (key, _, higher_better, scale) in enumerate(metric_keys):
            raw = d.get(key, 0)
            val = raw * scale
            # For ECE: lower is better → invert for colour (100 = best)
            matrix[i, j] = (100 - val) if not higher_better else val

    row_labels = [m[1] for m in metric_keys]

    fig, ax = plt.subplots(figsize=(max(8, n_cols * 1.5), max(6, n_rows * 0.7)))
    im = ax.imshow(matrix, cmap="YlGn", aspect="auto", vmin=0, vmax=100)

    ax.set_xticks(np.arange(n_cols))
    ax.set_yticks(np.arange(n_rows))
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_yticklabels(row_labels, fontsize=9)
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")

    # Annotate with actual values
    for j, d in enumerate(data):
        for i, (key, _, _, scale) in enumerate(metric_keys):
            val = d.get(key, 0) * scale
            fmt = f"{val:.3f}" if scale == 1 else f"{val:.1f}"
            text_color = "black" if matrix[i, j] < 60 else "white"
            ax.text(j, i, fmt, ha="center", va="center",
                    fontsize=7.5, color=text_color, fontweight="bold")

    ax.set_title("RLVER — Full Metric Heatmap (green = better)",
                 fontweight="bold", pad=12)
    fig.colorbar(im, ax=ax, shrink=0.6, label="Score (higher=better, ECE inverted)")

    path = os.path.join(out_dir, "05_metric_heatmap.png")
    fig.savefig(path)
    plt.close(fig)
    logger.info(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Plot 6 — Per-difficulty accuracy
# ─────────────────────────────────────────────────────────────────────────────

def plot_difficulty_breakdown(results: Dict[str, Dict], out_dir: str, plt) -> None:
    names, data = _ordered(results)
    labels = [VARIANT_META.get(n, {"label": n})["label"] for n in names]

    easy   = [d.get("easy_accuracy",   0) * 100 for d in data]
    medium = [d.get("medium_accuracy", 0) * 100 for d in data]
    hard   = [d.get("hard_accuracy",   0) * 100 for d in data]

    x     = np.arange(len(names))
    width = 0.28
    fig, ax = plt.subplots(figsize=(11, 5))

    ax.bar(x - width,   easy,   width, label="Easy",   color="#a1d99b", edgecolor="white")
    ax.bar(x,           medium, width, label="Medium",  color="#41ab5d", edgecolor="white")
    ax.bar(x + width,   hard,   width, label="Hard",    color="#006d2c", edgecolor="white")

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("RLVER — Accuracy by Difficulty Level", fontweight="bold", pad=12)
    ax.set_ylim(0, 105)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{y:.0f}%"))
    ax.legend(fontsize=10)

    path = os.path.join(out_dir, "06_difficulty_breakdown.png")
    fig.savefig(path)
    plt.close(fig)
    logger.info(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Plot 7 — Training curves (reward + accuracy vs step)
# ─────────────────────────────────────────────────────────────────────────────

def plot_training_curves(ckpt_root: str, out_dir: str, plt) -> None:
    """
    Load training_log.json files from checkpoint directories and plot:
      - Mean reward vs training step
      - Verification accuracy vs training step
    """
    log_paths = glob.glob(
        os.path.join(ckpt_root, "**", "training_log.json"), recursive=True
    )

    if not log_paths:
        logger.info("No training_log.json files found. Skipping training curves.")
        return

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    ax_r, ax_a = axes

    for log_path in sorted(log_paths):
        try:
            with open(log_path) as f:
                log = json.load(f)
        except Exception as e:
            logger.warning(f"Failed to load {log_path}: {e}")
            continue

        if not log:
            continue

        # Determine variant name from path
        rel  = os.path.relpath(log_path, ckpt_root)
        parts = Path(rel).parts
        variant_label = " / ".join(parts[:2]) if len(parts) >= 2 else parts[0]

        steps   = [entry.get("step", i) for i, entry in enumerate(log)]
        rewards = [entry.get("reward/mean", entry.get("mean_reward", None)) for entry in log]
        accs    = [entry.get("accuracy/group_mean", entry.get("accuracy", None)) for entry in log]

        rewards = [r for r in rewards if r is not None]
        accs    = [a for a in accs    if a is not None]
        r_steps = steps[:len(rewards)]
        a_steps = steps[:len(accs)]

        if rewards:
            ax_r.plot(r_steps, rewards, linewidth=1.5, label=variant_label, alpha=0.85)
        if accs:
            ax_a.plot(a_steps, [a * 100 for a in accs],
                      linewidth=1.5, label=variant_label, alpha=0.85)

    ax_r.set_xlabel("Training Step")
    ax_r.set_ylabel("Mean Reward")
    ax_r.set_title("Mean Reward vs Step", fontweight="bold")
    ax_r.legend(fontsize=8)

    ax_a.set_xlabel("Training Step")
    ax_a.set_ylabel("Verification Accuracy (%)")
    ax_a.set_title("Accuracy vs Step", fontweight="bold")
    ax_a.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f"{y:.0f}%"))
    ax_a.legend(fontsize=8)

    fig.suptitle("RLVER — Training Curves", fontweight="bold", fontsize=13, y=1.02)

    path = os.path.join(out_dir, "07_training_curves.png")
    fig.savefig(path)
    plt.close(fig)
    logger.info(f"  Saved: {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Terminal summary table
# ─────────────────────────────────────────────────────────────────────────────

def print_summary_table(results: Dict[str, Dict]) -> None:
    """Print a compact multi-metric comparison table to terminal."""
    names, data = _ordered(results)

    cols = [
        ("Variant",          20, lambda d: ""),
        ("Acc%",              8, lambda d: f"{d.get('verification_accuracy',0)*100:.2f}"),
        ("F1%",               8, lambda d: f"{d.get('f1_score',0)*100:.2f}"),
        ("Prec%",             8, lambda d: f"{d.get('precision',0)*100:.2f}"),
        ("Recall%",           8, lambda d: f"{d.get('recall',0)*100:.2f}"),
        ("AdvAcc%",           9, lambda d: f"{d.get('adversarial_accuracy',0)*100:.2f}"),
        ("TQS",               7, lambda d: f"{d.get('thinking_quality_score',0):.4f}"),
        ("ECE",               7, lambda d: f"{d.get('expected_calibration_error',0):.4f}"),
        ("ROC-AUC",           9, lambda d: f"{d.get('roc_auc',0):.4f}"),
    ]

    header = "".join(f"{h:<{w}}" for h, w, _ in cols)
    sep    = "-" * len(header)

    print(f"\n{'='*len(header)}")
    print("  RLVER — Full Results Summary")
    print(f"{'='*len(header)}")
    print(header)
    print(sep)

    for name, d in zip(names, data):
        label  = VARIANT_META.get(name, {"label": name})["label"].replace("\n", " ")
        row    = f"{label:<20}"
        for _, width, fn in cols[1:]:
            row += f"{fn(d):<{width}}"
        print(row)

    print(f"{'='*len(header)}\n")

    # Delta vs baseline_7b
    if "baseline_7b" in results:
        base = results["baseline_7b"]
        print("  Δ vs Baseline 7B (percentage points):\n")
        delta_header = "".join(f"{h:<{w}}" for h, w, _ in cols[:6])
        print(delta_header)
        print("-" * len(delta_header))

        for name, d in zip(names, data):
            if name == "baseline_7b":
                continue
            label = VARIANT_META.get(name, {"label": name})["label"].replace("\n", " ")
            da    = (d.get("verification_accuracy",0) - base.get("verification_accuracy",0)) * 100
            df1   = (d.get("f1_score",0)             - base.get("f1_score",0))             * 100
            dp    = (d.get("precision",0)             - base.get("precision",0))            * 100
            dr    = (d.get("recall",0)                - base.get("recall",0))               * 100
            dadv  = (d.get("adversarial_accuracy",0)  - base.get("adversarial_accuracy",0)) * 100

            def fmt(v):
                return f"{'+'if v>=0 else ''}{v:.2f}"

            row = f"{label:<20}{fmt(da):<8}{fmt(df1):<8}{fmt(dp):<8}{fmt(dr):<8}{fmt(dadv):<9}"
            print(row)
        print()


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="RLVER Results Analysis & Visualization",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--results_dir", type=str,
        default=os.path.join(PROJECT_ROOT, "results"),
        help="Directory containing variant JSON result files",
    )
    parser.add_argument(
        "--out_dir", type=str,
        default=os.path.join(PROJECT_ROOT, "results", "plots"),
        help="Output directory for saved plot PNGs",
    )
    parser.add_argument(
        "--training_logs", action="store_true",
        help="Also plot training curves from checkpoint training_log.json files",
    )
    parser.add_argument(
        "--ckpt_root", type=str,
        default=os.path.join(PROJECT_ROOT, "rl_training", "checkpoints"),
        help="Root dir for training checkpoints (used with --training_logs)",
    )
    return parser


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(message)s",
        datefmt="%H:%M:%S",
    )

    args = build_parser().parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    print(f"\n{'='*60}")
    print("  RLVER Results Analysis")
    print(f"  Results dir : {args.results_dir}")
    print(f"  Output dir  : {args.out_dir}")
    print(f"{'='*60}\n")

    # ── Load data ─────────────────────────────────────────────────────────────
    results = load_all_results(args.results_dir)
    if not results:
        print("[ERROR] No result files found. Run evaluation first:")
        print("  bash scripts/03_run_eval.sh")
        return

    # ── Print terminal table ──────────────────────────────────────────────────
    print_summary_table(results)

    # ── Setup matplotlib ──────────────────────────────────────────────────────
    try:
        plt = _setup_matplotlib()
    except ImportError:
        print("[ERROR] matplotlib not installed. Run: pip install matplotlib")
        return

    # ── Generate all plots ────────────────────────────────────────────────────
    print(f"Generating plots → {args.out_dir}\n")

    plot_accuracy_bars(results,        args.out_dir, plt)
    plot_f1_bars(results,              args.out_dir, plt)
    plot_clean_vs_adversarial(results, args.out_dir, plt)
    plot_radar(results,                args.out_dir, plt)
    plot_heatmap(results,              args.out_dir, plt)
    plot_difficulty_breakdown(results, args.out_dir, plt)

    if args.training_logs:
        plot_training_curves(args.ckpt_root, args.out_dir, plt)

    # ── Summary ───────────────────────────────────────────────────────────────
    plots = sorted(glob.glob(os.path.join(args.out_dir, "*.png")))
    print(f"\n{'='*60}")
    print(f"  Analysis complete — {len(plots)} plots saved:")
    for p in plots:
        print(f"    {os.path.basename(p)}")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
